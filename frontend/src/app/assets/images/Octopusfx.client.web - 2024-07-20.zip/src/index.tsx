import React, { Suspense } from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import reportWebVitals from './reportWebVitals';
import { Provider } from 'react-redux'
import { store } from './app/store-management/store-creation';
import FxErrorBoundary  from './app/core/error-handling/error-boundary';
import { injectStore } from './inject-store';
import { router } from './App';
import { RouterProvider } from 'react-router-dom';
import registerUIComponentsLicence from './app/core/licences/ui-components-licence';
import AppPreloader from './app/components/shared/app-preloader';

injectStore(store);

registerUIComponentsLicence();

const root = ReactDOM.createRoot(
  document.getElementById('root') as HTMLElement
);

root.render(
  <Provider store={store}>
      <FxErrorBoundary>
        <Suspense fallback={<AppPreloader/>}>
            <RouterProvider router={router}/>
        </Suspense>
      </FxErrorBoundary>
    </Provider>
  );

reportWebVitals();
