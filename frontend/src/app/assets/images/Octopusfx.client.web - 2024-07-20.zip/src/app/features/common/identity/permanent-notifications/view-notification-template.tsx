
interface Props {
  id?: string;
  subject?: string;
  message?: string;
  creationDate?: string;
  creationDateWording?: string;
  readDate?: string;
  isRead?: boolean;
}
function ViewNotificationTemplate(props: Props) {

  return (
    <div className='view-notification-template flex flex-col gap-8 items-start w-full px-4 py-2 mx-auto'>

      <div className="w-full">
        <label>{props.subject}</label>
      </div>

      <div className="w-full">
        <div className="flex flex-col gap-2 items-start">
          <label className="">Contenu de la notification</label>
          <p>{props.message}</p>
        </div>
      </div>

      <div className="flex flex-row gap-4 items-start justify-between w-full">
        <span>Crée le</span> <i>{props.creationDateWording}</i>
      </div>

    </div>
  );
}

export default ViewNotificationTemplate;