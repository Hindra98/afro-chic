
export interface UpdateVehicleStoreShape {
  value: boolean,
  pending: boolean,
  errors: string[],
}
export let initialStateUpdateVehicle: UpdateVehicleStoreShape = {
  value: false,
  pending: false,
  errors: []
}
export interface UpdateVehicleModelShape {
  command: FormData,
}
export interface UpdateVehicleFailurePayload {
  errors: string[],
}
export interface UpdateVehicleSuccessPayload {
  value: boolean;
}
export interface UpdateVehicleFailure {
  type: string,
  payload: UpdateVehicleFailurePayload,
}
export interface UpdateVehicleSuccess {
  type: string,
  payload: UpdateVehicleSuccessPayload,
}
export interface UpdateVehiclePayload {
  command: FormData,
  value: UpdateVehicleSuccessPayload,
  errors: UpdateVehicleFailurePayload,
}
export interface UpdateVehicleAction {
  type: string,
  payload: UpdateVehiclePayload,
}

export interface DeleteVehicleStoreShape {
  value: boolean,
  pending: boolean,
  errors: string[],
}
export let initialStateDeleteVehicle: DeleteVehicleStoreShape = {
  value: false,
  pending: false,
  errors: []
}
export interface DeleteVehicleModelShape {
  command: DeleteVehicleCommand,
}
export interface DeleteVehicleFailurePayload {
  errors: string[],
}
export interface DeleteVehicleSuccessPayload {
  value: boolean;
}
export interface DeleteVehicleFailure {
  type: string,
  payload: DeleteVehicleFailurePayload,
}
export interface DeleteVehicleSuccess {
  type: string,
  payload: DeleteVehicleSuccessPayload,
}
export interface DeleteVehiclePayload {
  command: DeleteVehicleCommand,
  value: DeleteVehicleSuccessPayload,
  errors: DeleteVehicleFailurePayload,
}
export interface DeleteVehicleAction {
  type: string,
  payload: DeleteVehiclePayload,
}

export interface GetVehiclesStoreShape {
  value: GetVehicles,
  pending: boolean,
  errors: string[],
}
export let initialStateGetVehicles: GetVehiclesStoreShape = {
  value: {
    hasAlreadyCalled: false,
    isAdministrator: false,
    vehicles: [],
    brands: [],
  } as GetVehicles,
  pending: false,
  errors: []
}
export interface GetVehiclesModelShape {
  command: GetVehicles,
}
export interface GetVehiclesFailurePayload {
  errors: string[],
}
export interface GetVehiclesFailure {
  type: string,
  payload: GetVehiclesFailurePayload,
}
export interface GetVehiclesSuccess {
  type: string,
  payload: GetVehicles,
}
export interface GetVehiclesPayload {
  command: string,
  value: GetVehicles,
  errors: GetVehiclesFailurePayload,
}
export interface GetVehiclesAction {
  type: string,
  payload: GetVehiclesPayload,
}


export interface GetVehicleStoreShape {
  value: GetVehicle,
  pending: boolean,
  errors: string[],
}
export let initialStateGetVehicle: GetVehicleStoreShape = {
  value: {
    isAdministrator: false,
    vehicle: {
      id: "",
      vin: "",
      engineNumber: "",
      gearNumber: "",
      name: "",
      gearBoxType: "",
      gearBoxTypeWording: "",
      commissionStartingDate: "",
      commissionStartingDateWording: "",
      commissionEndDate: "",
      commissionEndDateWording: "",
      modelYear: 0,
      cO2Emissions: 0,
      description: "",
      brandId: "",
      modelId: "",
      status: "",
      statusWording: "",
      energyType: "",
      energyTypeWording: "",
      vehicleType: "",
      vehicleTypeWording: "",
      imageUrls: [],
      documentUrls: [],
    } as Vehicle,
    brands: [],
    vehicleTypes: [],
    gearBoxes: [],
    models: [],
    energyTypes: [],
    availabilityStatus: [],
  } as GetVehicle,
  pending: false,
  errors: []
}
export interface GetVehicleModelShape {
  command: GetVehicle,
}
export interface GetVehicleFailurePayload {
  errors: string[],
}
export interface GetVehicleFailure {
  type: string,
  payload: GetVehicleFailurePayload,
}
export interface GetVehicleSuccess {
  type: string,
  payload: GetVehicle,
}
export interface GetVehiclePayload {
  command: VehicleCommand,
  value: GetVehicle,
  errors: GetVehicleFailurePayload,
}
export interface GetVehicleAction {
  type: string,
  payload: GetVehiclePayload,
}
