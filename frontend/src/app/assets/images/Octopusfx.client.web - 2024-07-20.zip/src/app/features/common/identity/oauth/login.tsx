import { Link, Navigate } from "react-router-dom";
import Text from "../../../../components/form/Text";
import Button from "../../../../components/form/Button";
import "../../../../styles/login.scss";
import { useLocalizer } from "../../../../core/Localization/use-localizer";
import * as Yup from "yup";
import { useState } from "react";
import { authenticateUser } from "src/app/store-management/actions/oauth/oauth-actions";
import { useAppDispatch, useAppSelector } from "src/app/core/hooks/core-hooks";
import { getStorage } from "src/app/core/storage/storage";
import { MessageComponent } from "@syncfusion/ej2-react-notifications";
import { AuthenticationConstants } from "src/app/core/constants/authentication-contants";



const Authentication = () => {

  const commonLocalizer = useLocalizer("Common-ResCommon");
  
  const dispatch = useAppDispatch();
  const authResult = useAppSelector(state => state.authenticatedUser)

  const token = getStorage<string>(AuthenticationConstants.ACCESS_TOKEN);

  const schema = Yup.object().shape({
    subscriptionKey: Yup.string(),
    userName: Yup.string(),
    password: Yup.string(),
  });

  const [authenticationViewModel, setAuthenticationViewModel] = useState({
    subscriptionKey: "",
    userName: "",
    password: "",
  } as AuthenticateUserCommand);

  const [errors, setErrors] = useState({
    subscriptionKey: "",
    userName: "",
    password: "",
  });

  const handleChange = (event) => {
    const { name, value } = event.target;
    setErrors({subscriptionKey: "", userName: "", password: ""});

    setAuthenticationViewModel({
      ...authenticationViewModel,
      [name]: value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setErrors({subscriptionKey: "", userName: "", password: ""});

    const values = await schema.validate(authenticationViewModel);

    if (values.password === "" || values.userName === "" || values.subscriptionKey === "") {
      let password = "", subscriptionKey = "", userName = "";
      if (values.password === "") password = commonLocalizer("MODULES_Common_User_Validate_Command_Password_Required");
      if (values.subscriptionKey === "") subscriptionKey = commonLocalizer("MODULES_Common_User_Validate_Command_Tenant_Required");
      if (values.userName === "") userName = commonLocalizer("MODULES_Common_User_Validate_Command_UserName_Required");

      setErrors({subscriptionKey: subscriptionKey, userName: userName, password: password})

    } else {
      dispatch( await authenticateUser(authenticationViewModel));
    }
  };

  if(token) {
    return <Navigate to={"/dashboard"} replace />
  } else {
    if(authResult.value.token) {
      return <Navigate to={"/verify-identity"} replace />
    }
  }
  window.document.title = commonLocalizer("MODULE_COMMON_AUTHENTICATION_SCREEN_LOGIN");

 return (
   <>
     <div className="form-login bg-white rounded-xl py-4 h-full min-h-[300px] xl:w-1/4 lg:w-1/3 xl:px-12 xmd:w-2/5 xmd:px-8 md:w-1/2 sm:w-4/5 sm:px-5 xxs:w-5/6">
       <h1 className="text-3xl align-top text-center my-4">{commonLocalizer("MODULE_COMMON_AUTHENTICATION_SCREEN_LOGIN")}</h1>
       
       {authResult.Errors && authResult.Errors.length > 0 && (
        <div className="w-5/6 mx-auto mb-2">
          {authResult.Errors.map((message, key) => {
            return (<MessageComponent id="msg_error" className="errorServer" 
            content={ message.includes("404") ?
             commonLocalizer("MODULES_COMMON_Authentication_Tenant_Not_Found") : message } 
             key={key} severity="Error"></MessageComponent>);
          })}
        </div>
      )}

       <form
         onSubmit={handleSubmit}
         className="flex flex-col justify-center items-stretch gap-3 h-full w-5/6 mx-auto my-4"
       >
         <div className="tenant flex-auto mt-2">
           <Text
             type="text"
             id="tenant"
             name="subscriptionKey"
             icon={"keyicon-"}
             placeholder={commonLocalizer(
               "MODULE_COMMON_AUTHENTICATION_SCREEN_SUBSCRPTION_KEY"
             )}
             className="login-input w-full outline-none border-none"
             value={authenticationViewModel.subscriptionKey}
             eye={false}
             onChange={handleChange}
           />
           {errors.subscriptionKey && (
             <div className="error">{errors.subscriptionKey.toString()}</div>
           )}
         </div>
         <div className="flex-auto">
           <Text
             type="text"
             id="userName"
             name="userName"
             icon={"e-user"}
             placeholder={commonLocalizer("MODULE_COMMON_AUTHENTICATION_SCREEN_EMAIL_ADDRESS")}
             className="login-input w-full outline-none border-none"
             value={authenticationViewModel.userName}
             eye={false}
             onChange={handleChange}
           />
           {errors.userName && (
             <div className="error">{errors.userName.toString()}</div>
           )}
         </div>
         <div className="password flex-auto">
           <Text
             type="password"
             id="password"
             name="password"
             icon={"e-lock"}
             placeholder={commonLocalizer(
               "MODULE_COMMON_AUTHENTICATION_SCREEN_PASSWORD"
             )}
             className="login-input w-full outline-none border-none"
             value={authenticationViewModel.password}
             eye={true}
             onChange={handleChange}
           />
           {errors.password && (
             <div className="error">{errors.password.toString()}</div>
           )}
         </div>
         <div className="forgot text-center my-2">
           <Link to={"/forgot-password"}>
             {commonLocalizer(
               "MODULE_COMMON_AUTHENTICATION_SCREEN_I_FORGOT_MY_PASSWORD"
             )}
           </Link>
         </div>

         <Button param={{type: "submit", css: (authResult.pending? "disabled":"")+" px-5 py-3 rounded-md mx-auto w-full", name: commonLocalizer("MODULE_COMMON_AUTHENTICATION_SCREEN_SIGNIN"), disabled: authResult.pending}} />
       </form>
     </div>
   </>
 );
}

export default Authentication;
