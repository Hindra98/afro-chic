import {
  ColumnDirective,
  ColumnsDirective,
  Edit,
  ExcelExport,
  ExcelExportProperties,
  Filter,
  Sort,
  GridComponent,
  Inject,
  Page,
  PdfExport,
  PdfExportProperties,
  Resize,
  Selection,
  RecordClickEventArgs,
} from "@syncfusion/ej2-react-grids";
import { ReactElement, useRef, useState } from "react";
import Breadcrumb from "src/app/components/shared/breadcrumb";
import { useAppDispatch, useAppSelector } from "src/app/core/hooks/core-hooks";
import { useLocalizer } from "src/app/core/Localization";
import "src/app/styles/_notifications.scss";
import ToolsbarOptions from "src/app/components/shared/grid-components/toolsbar-options";
import emptyrecords from "src/app/components/shared/grid-components/empty-records";
import iconAgency from "src/app/assets/image-octopusfx/user.png";
import { GridConstants } from "src/app/core/constants/data-grid";
import { SidebarComponent } from "@syncfusion/ej2-react-navigations";
import CreateUpdateAgenciesSidebar from "./create-update-agencies-sidebar";
import { deleteAgency, getAgencies, getAgency } from "src/app/store-management/actions/agencies/agencies-actions";
import ConfirmActionsDialog from "src/app/components/shared/dialog-components/confirm-actions-dialog";


function statusTemplate(props) {
  return (
    <span className={`status rounded-xl text-center py-1 px-3 ${props.isHeadQuarter ? "active" : "inactive"} `}>
      {props.isHeadQuarter ? "Oui" : "Non"}
    </span>
  );
}
function nameTemplate(props) {
  return (
    <span className={`name-link cursor-pointer hover:text-blue-900 hover:underline hover:font-bold`}>
      {props.name}
    </span>
  );
}

const AgenciesDataGrid = () => {
  const commonLocalizer = useLocalizer("Common-ResCommon");
  const [isShowBackdrop, setShowBackdrop] = useState<boolean>(false);
  const [isEditing, setIsEditing] = useState<boolean>(false);
  let sidebarInstance = useRef<SidebarComponent>(null);
  let grid = useRef<GridComponent>(null);
  const dispatch = useAppDispatch();

  const getAllAgencies = useAppSelector((state) => state.getAgencies);

  const [getRefresh, setGetRefresh] = useState(false);
  const [checkRow, setCheckRow] = useState(false);
  const openDialog = useState(false);
  const [titleDialog, setTiltleDialog] = useState("");
  const [btnDialog, setBtnDialog] = useState([]);
  const [messageDialog, setMessageDialog] = useState<ReactElement>(null);

  const getAgenciesData = () => {
    dispatch(getAgencies());
  };
  const getAgencyInfos = (id: string) => {
    dispatch(getAgency({ SearchCriteria: id } as AgencyCommand));
  };

  if (
    !getRefresh &&
    !getAllAgencies?.pending &&
    getAllAgencies?.Errors?.length === 0
  ) {
    getAgenciesData();
    setGetRefresh(true);
  }

  const sidebarClose = () => {
    sidebarInstance.current.hide();
    setShowBackdrop(false);
  };

  const [tenantViewModel, setAgencyViewModel] = useState<any>({});

  const handleActionBegin = (args: any) => {
    if (args.requestType === "add" || args.requestType === "beginEdit") {
      sidebarInstance?.current?.toggle();
      setShowBackdrop(true);
      args.cancel = true;
    }
  };

  const handleAdd = () => {
    if (grid.current) {
      setIsEditing(false);
      getAgencyInfos("");
      grid.current.addRecord();
    }
  };
  const handleClickRecord = (e: RecordClickEventArgs) => {
    if (grid.current) {
      const index = e.cellIndex;
      let keyRecord = e.rowData as Branch;
      if (index > 0) {
        getAgencyInfos(keyRecord.id);
        setIsEditing(true);
        setAgencyViewModel({ ...tenantViewModel, id: keyRecord.id });
        grid.current.addRecord()
      } else {
        if (keyRecord.isDeletable) {
          const selectedRecordsLength = grid.current.getSelectedRecords() as Branch[];
          if (selectedRecordsLength.length > 1 || selectedRecordsLength.length === 0) setCheckRow(true);
          else {
            if (selectedRecordsLength[0].id === keyRecord.id) setCheckRow(false);
            else setCheckRow(true);
          }
        }
      }
    }
  };

  const handleDelete = () => {
    if (grid.current) {
      const selectedRecords = grid.current.getSelectedRecords() as Branch[];
      if (selectedRecords.length === 1) {
        dispatch(deleteAgency({ key: selectedRecords[0].id.toString() }))
        setTiltleDialog(`Suppression d'une agence: ${selectedRecords[0]?.name}`);
        setMessageDialog(
          <p>
            Voulez-vous vraiment supprimer cette agence : <b>{selectedRecords[0]?.name}</b> ?{" "}
          </p>
        );
        setBtnDialog([
          {
            type: "button",
            name: "Annuler",
            css: "cancelBtn",
            handleClick: () => openDialog[1](false),
          },
          {
            type: "button",
            name: "Confirmer",
            css: "okBtn",
            handleClick: () => { dispatch(deleteAgency({ key: selectedRecords[0].id.toString() })); openDialog[1](false) }
          },
        ]);
        openDialog[1](true);
      } else {
        setTiltleDialog(`Erreur!!!`);
        setMessageDialog(<p>Vous devez selectionner au moins une agence pour cette opération</p>);
        setBtnDialog([
          {
            type: "button",
            name: "Ok",
            css: "okBtn",
            handleClick: () => openDialog[1](false),
          }
        ]);
        openDialog[1](true);
      }
    }
  };

  const handleSave = () => {
    if (grid.current) {
      grid.current.addRecord();
      grid.current.endEdit();
    }
    setShowBackdrop(false);
    sidebarInstance.current.hide();
  };

  const editSettings: any = {
    allowEditing: true,
    allowAdding: true,
    allowDeleting: true,
    mode: "Normal",
    allowEditOnDblClick: false,
  };
  const exportFilename = "agency";
  const rowsPerPage = 5;
  const [currentPage, setCurrentPage] = useState(1);
  const handlePageChange = (page: number) => {
    grid.current.pageSettings.currentPage = page;
    setCurrentPage(page);
  };
  const handleSearch = (searchText: string) => {
    console.log("handle", searchText);
  };

  const select: any = {
    persistSelection: true,
    type: "Single",
    checkboxOnly: false,
    mode: "Both",
    checkboxMode: "ResetOnRowClick",
  };

  const gridFilter: any = { type: "Menu" };
  const pdfExportProperties: PdfExportProperties = {
    header: {
      fromTop: 0,
      height: 130,
      contents: [
        {
          type: "Line",
          style: { penColor: "#000080", penSize: 2, dashStyle: "Solid" },
          points: { x1: 0, y1: 4, x2: 685, y2: 4 },
        },
        {
          type: "Text",
          value: "Liste des agences ",
          position: { x: 200, y: 50 },
          style: { textBrushColor: "#000000", fontSize: 20 },
        },
      ],
    },
    footer: {
      fromBottom: 10,
      height: 60,
      contents: [
        {
          type: "Line",
          style: { penColor: "#000080", penSize: 2, dashStyle: "Dot" },
          points: { x1: 0, y1: 4, x2: 685, y2: 4 },
        },
        {
          type: "PageNumber",
          pageNumberType: "Arabic",
          format: "Page {$current} sur {$total}", //optional
          position: { x: 0, y: 25 },
          style: { textBrushColor: "#4169e1", fontSize: 15, hAlign: "Center" },
        },
      ],
    },
    exportType: "AllPages",
  };

  const ExportPdf = () => {
    (grid.current as GridComponent)?.pdfExport({
      ...pdfExportProperties,
      fileName: `${exportFilename}.pdf`,
    });
  };
  const ExportExcel = () => {
    const excelExportProperties: ExcelExportProperties = {
      exportType: "AllPages",
      fileName: `${exportFilename}.xlsx`,
    };
    (grid.current as GridComponent)?.excelExport({ ...excelExportProperties });
  };
  const ExportCsv = () => {
    const excelExportProperties: ExcelExportProperties = {
      exportType: "AllPages",
      fileName: `${exportFilename}.csv`,
    };
    (grid.current as GridComponent)?.csvExport({ ...excelExportProperties });
  };

  window.document.title = "Agencies";
  return (
    <div className="h-full flex flex-col justify-start mx-auto notifications-component">
      <div
        className={` text-3xl align-top flex flex-col justify-start ps-10 pt-4 flex-wrap my-2 gap-0 `}
      >
        <h1 className="">{"Agences"}</h1>
        <Breadcrumb
          items={[
            {
              title: commonLocalizer("MODULE_COMMON_SIDEBAR_DASHBOARD"),
              link: "/dashboard",
            },
            { title: "Agencies" },
          ]}
        />
      </div>

      <ToolsbarOptions
        ToolsbarActionItem={[
          {
            icon: "user-addicon-",
            name: "Ajouter",
            handleClick: () => handleAdd(),
          },
          {
            icon: "trash-emptyicon-",
            name: "Supprimer",
            handleClick: () => handleDelete(),
            disabled: !checkRow,
          },
          {
            icon: "ccwicon-",
            name: "Rafraichir",
            handleClick: () => dispatch(getAgencies()),
          },
        ]}
        allowExportPdf
        allowExportCsv
        allowExportExcel
        handleExportPdf={ExportPdf}
        handleExportExcel={ExportExcel}
        handleExportCsv={ExportCsv}
        enablePager
        pager={{ align: "right" }}
        enablePagination
        pagination={{
          currentPage: currentPage,
          rowsPerPage: rowsPerPage,
          totalPages: parseInt(getAllAgencies?.value?.branches?.length.toString()),
          handleChangePage: handlePageChange,
        }}
        enableSearch
        search={{ handleSearch: handleSearch }}
      />
      <GridComponent
        dataSource={getAllAgencies.value.branches}
        id="notifications-grid"
        cssClass="mx-2"
        loadingIndicator={{ indicatorType: "Shimmer" }}
        allowResizing={true}
        enableHover={true}
        allowSorting={false}
        allowFiltering={true}
        actionBegin={handleActionBegin}
        recordClick={handleClickRecord}
        emptyRecordTemplate={() =>
          emptyrecords(
            "Aucune agence trouvée",
            iconAgency,
            getAllAgencies.pending,
            "w-1/12"
          )
        }
        resizeSettings={{ mode: "Auto" }}
        rowHeight={38}
        height={GridConstants.HEIGHT}
        filterSettings={gridFilter}
        allowSelection={true}
        selectionSettings={select}
        enableHeaderFocus={true}
        allowPaging={true}
        autoFit={true}
        allowPdfExport={true}
        allowExcelExport={true}
        editSettings={editSettings}
        pageSettings={{ pageCount: 2, pageSize: rowsPerPage }}
        ref={grid}
      >
        <ColumnsDirective>
          <ColumnDirective
            type="checkbox"
            allowSorting={false}
            allowFiltering={false}
            width="40"
          ></ColumnDirective>
          <ColumnDirective
            field="id"
            visible={false}
            headerText="Angency Key"
            isPrimaryKey={true}
            width="auto"
          ></ColumnDirective>
          <ColumnDirective
            field="name"
            headerText="Nom"
            template={nameTemplate}
            clipMode="EllipsisWithTooltip"
            width="auto"
          />
          <ColumnDirective
            field="isHeadQuarter"
            headerText="Siège social de l'entreprise"
            template={statusTemplate}
            clipMode="EllipsisWithTooltip"
            width="auto"
          />
          <ColumnDirective
            field="latitude"
            headerText="Latitude"
            clipMode="EllipsisWithTooltip"
            width="auto"
          />
          <ColumnDirective
            field="longitude"
            headerText="Longitude"
            clipMode="EllipsisWithTooltip"
            width="auto"
          />
          <ColumnDirective
            field="radius"
            headerText="rayon"
            clipMode="EllipsisWithTooltip"
            width="auto"
          />
          <ColumnDirective
            field="order"
            headerText="Numéro d'ordre"
            clipMode="EllipsisWithTooltip"
            width="auto"
          />
        </ColumnsDirective>
        <Inject
          services={[
            Page,
            Filter,
            Sort,
            PdfExport,
            ExcelExport,
            Resize,
            Selection,
            Edit,
          ]}
        />
      </GridComponent>

      <CreateUpdateAgenciesSidebar
        isEditing={isEditing}
        func={{
          sidebarClose: sidebarClose.bind(this),
          isShowBackdrop: isShowBackdrop,
          sidebarInstance: sidebarInstance,
        }}
        handleSave={handleSave}
      />

      <ConfirmActionsDialog
        openDialog={openDialog}
        title={titleDialog}
        button={btnDialog}
      >
        {messageDialog}
      </ConfirmActionsDialog>
    </div>
  );
};

export default AgenciesDataGrid;
