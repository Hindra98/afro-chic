import { ActionTypes } from "../actions/constants/action-types";
import { produce } from "immer";
import { UpdateUserPreferencesStoreShape, initialStateUpdateUserPreferences, UpdateUserPreferencesAction, GetUserPreferencesStoreShape, getUserPreferencesInitialState, GetUserPreferencesAction } from "../actions/user-preferences";


export const updateUserPreferencesReducer = (state: UpdateUserPreferencesStoreShape = initialStateUpdateUserPreferences, args: UpdateUserPreferencesAction): UpdateUserPreferencesStoreShape => {

  switch (args.type) {

    case ActionTypes.UPDATE_USER_PREFERENCES_REQUEST:
      return produce(state, (draftState) => {
        draftState.value = false;
        draftState.pending = true;
        draftState.Errors = [];
      });

      case ActionTypes.UPDATE_USER_PREFERENCES_FAILURE:
        return produce(state, (draftState) => {
          draftState.Errors = args.payload?.errors.errors;
          draftState.value = false;
          draftState.pending = false;
        });

        case ActionTypes.UPDATE_USER_PREFERENCES_SUCCESS:
          return produce(state, (draftState) => {
            draftState.Errors = [];
            draftState.value = true;
            draftState.pending = false;
          });

    default:
      return state;
  }
};

export const getUserPreferencesReducer = (state: GetUserPreferencesStoreShape = getUserPreferencesInitialState, args: GetUserPreferencesAction): GetUserPreferencesStoreShape => {

    switch (args.type) {

      case ActionTypes.GET_USER_PREFERENCES_REQUEST:
        return produce(state, (draftState) => {
          draftState.pending = true;
          draftState.Errors = [];
        });
  
        case ActionTypes.GET_USER_PREFERENCES_FAILURE:
          return produce(state, (draftState) => {
            draftState.Errors = args.payload?.errors?.errors;
            draftState.pending = false;
            draftState.errServer.detail = args.payload?.errServer?.detail;
            draftState.errServer.instance = args.payload?.errServer?.instance;
            draftState.errServer.type = args.payload?.errServer?.type;
            draftState.errServer.status = args.payload?.errServer?.status;
            draftState.errServer.title = args.payload?.errServer?.title;
            draftState.errServer.message = args.payload?.errServer?.message;
          });
  
          case ActionTypes.GET_USER_PREFERENCES_SUCCESS:
            return produce(state, (draftState) => {
              draftState.Errors = [];
              
              draftState.value.payload.notificationChannel = args.payload?.user?.payload.notificationChannel
              draftState.value.payload.notificationChannelLabel = args.payload?.user?.payload.notificationChannelLabel
              draftState.value.payload.language = args.payload?.user?.payload.language
              draftState.value.payload.timeZone = args.payload?.user?.payload.timeZone
              draftState.value.payload.datePattern = args.payload?.user?.payload.datePattern
              draftState.value.payload.timePattern = args.payload?.user?.payload.timePattern
              draftState.value.payload.userId = args.payload?.user?.payload.userId
              draftState.value.payload.IsPhoneNumberSet = args.payload?.user?.payload.IsPhoneNumberSet
              draftState.value.payload.IsEmailAddressSet = args.payload?.user?.payload.IsEmailAddressSet

              draftState.value.timeZones = args.payload?.user?.timeZones
              draftState.value.languages = args.payload?.user?.languages
              draftState.value.datePatterns = args.payload?.user?.datePatterns
              draftState.pending = false;
            });
  
      default:
        return state;
    }
  };