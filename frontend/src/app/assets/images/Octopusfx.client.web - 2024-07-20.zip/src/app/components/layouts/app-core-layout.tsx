import { Navigate, useLocation, useNavigate, useOutlet } from "react-router-dom";
import { getStorage, setStorage } from "src/app/core/storage/storage";
import "../../styles/_app-core-layout.scss";
import { lazy, useCallback, useEffect, useState } from "react";
import { useAppDispatch } from "src/app/core/hooks/core-hooks";
import { useGlobalAppContext } from "src/app/core/hooks/use-app-context";
import { signOut } from "src/app/store-management/actions/oauth/oauth-actions";
import { SharedConstants } from "src/app/core/constants/common-constants";
import { AuthenticationConstants } from "src/app/core/constants/authentication-contants";
import { useAppSize } from "src/app/core/hooks";
import { L10n, setCulture } from "@syncfusion/ej2-base";
import { localesTranslations } from "src/app/core/Localization/locales";

const Sidebar = lazy(() => import("../shared/sidebar/sidebar"));
const NavBar = lazy(() => import("../shared/navbar/navbar"));

L10n.load(localesTranslations);

export const AppCoreLayout = () => {
  const size = useAppSize();
  const [open, setOpen] = useState((getStorage(SharedConstants.TOGGLE_SIDEBAR) === "true") && (size.width > 1000));
  const outlet = useOutlet();
  const { pathname } = useLocation();
  const dispatch = useAppDispatch();
  const token = getStorage<string>(AuthenticationConstants.ACCESS_TOKEN);

  const { accessToken, rExpires } = useGlobalAppContext();
  const navigate = useNavigate();

  const close = useCallback(() => {
    dispatch(signOut());
    setTimeout(() => navigate("/login", { replace: true }), 300);
  }, [dispatch, navigate]);

  const userLanguage = getStorage<string>(AuthenticationConstants.USER_LANGUAGE);
  useEffect(() => {
    setCulture((userLanguage === 'fr') ? 'fr-FR' : 'en-US');
  }, [userLanguage]);

  if (accessToken) {
    if ((rExpires !== null && rExpires !== undefined && rExpires * 1000 < Date.now()) ||
      rExpires === 0 || rExpires === undefined) {
      close();
    }
  } else {
    close();
  }
  const toggleSidebar = () => {
    if (open) { setStorage(SharedConstants.TOGGLE_SIDEBAR, "false"); setOpen(false);}
    else {setStorage(SharedConstants.TOGGLE_SIDEBAR, "true"); setOpen(true);}
  };

  if (!pathname.includes("change-password")) {
    getStorage<string>("is_verified", true);
  }
  if(token?.length===0) {
    return <Navigate to={"/login"} replace />
  }
  const classTarget = "main-menu-content";

  return (
    <>
      <div id="menu-wrapper" className="control-section h-screen">
        <NavBar clicked={toggleSidebar} />
        <div id="sidebarmenu" className="flex flex-row gap-0 mt-[50px]">
          <Sidebar open={open} />
          <div className={`w-full ${classTarget}`} id="maintext">
            <div className={`menu-content px-1 ${open?"open":"close"} `}>{outlet}</div>
          </div>
        </div>
      </div>
    </>
  );
};

export default AppCoreLayout;
