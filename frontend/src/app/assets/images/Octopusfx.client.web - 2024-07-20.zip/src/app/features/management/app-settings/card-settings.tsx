import React from 'react'

type Props = React.PropsWithChildren<{
  title?: string
}>

const CardSettings = (props: Props) => {
  return (
    <div className='flex flex-col gap-5 items-start ms-auto bg-white rounded-lg p-12 w-full h-full min-h-[calc(100vh-395px)]'>
      {props.children}
    </div>
  )
}

export default CardSettings