import { DeleteBrandAction, DeleteBrandStoreShape, GetBrandAction, GetBrandsAction, GetBrandsStoreShape, GetBrandStoreShape, initialStateDeleteBrand, initialStateGetBrand, initialStateGetBrands, initialStateUpdateBrand, UpdateBrandAction, UpdateBrandStoreShape } from "../actions/brands";
import { ActionTypes } from "../actions/constants/action-types";
import { produce } from "immer";


export const updateBrandReducer = (state: UpdateBrandStoreShape = initialStateUpdateBrand, args: UpdateBrandAction): UpdateBrandStoreShape => {
  switch (args.type) {

    case ActionTypes.UPDATE_BRAND_REQUEST:
      return produce(state, (draftState) => {
        draftState.pending = true;
        draftState.errors = []
        draftState.value = false;
      });

    case ActionTypes.UPDATE_BRAND_FAILURE:
      return produce(state, (draftState) => {
        draftState.pending = false;
        draftState.errors = args?.payload?.errors?.errors
        draftState.value = false;
      });

    case ActionTypes.UPDATE_BRAND_SUCCESS:
      return produce(state, (draftState) => {
        draftState.errors = []
        draftState.pending = false;
        draftState.value = args.payload?.value?.value
      });

    default:
      return state;
  }
};

export const deleteBrandReducer = (state: DeleteBrandStoreShape = initialStateDeleteBrand, args: DeleteBrandAction): DeleteBrandStoreShape => {
  switch (args.type) {

    case ActionTypes.DELETE_BRAND_REQUEST:
      return produce(state, (draftState) => {
        draftState.pending = true;
        draftState.errors = []
        draftState.value = false;
      });

    case ActionTypes.DELETE_BRAND_FAILURE:
      return produce(state, (draftState) => {
        draftState.pending = false;
        draftState.errors = args?.payload?.errors?.errors
        draftState.value = false;
      });

    case ActionTypes.DELETE_BRAND_SUCCESS:
      return produce(state, (draftState) => {
        draftState.errors = []
        draftState.pending = false;
        draftState.value = args.payload?.value?.value
      });

    default:
      return state;
  }
};

export const getBrandReducer = (state: GetBrandStoreShape = initialStateGetBrand, args: GetBrandAction): GetBrandStoreShape => {
  switch (args.type) {

    case ActionTypes.BRAND_REQUEST:
      return produce(state, (draftState) => {
        draftState.pending = true;
        draftState.errors = [];
      });

    case ActionTypes.BRAND_SUCCESS:
      return produce(state, (draftState) => {
        draftState.pending = false;
        draftState.errors = args?.payload?.errors?.errors
        draftState.value.brand.id = args?.payload?.value?.brand.id
        draftState.value.brand.title = args?.payload?.value?.brand.title
        draftState.value.brand.models = args?.payload?.value?.brand.models

      });

    case ActionTypes.BRAND_FAILURE:
      return produce(state, (draftState) => {
        draftState.errors = args.payload?.errors?.errors
        draftState.pending = false;
      });

    default:
      return state;
  }
};

export const getBrandsReducer = (state: GetBrandsStoreShape = initialStateGetBrands, args: GetBrandsAction): GetBrandsStoreShape => {
  switch (args.type) {

    case ActionTypes.BRANDS_REQUEST:
      return produce(state, (draftState) => {
        draftState.pending = true;
        draftState.value.hasAlreadyCalled = true;
        draftState.errors = []
      });

    case ActionTypes.BRANDS_FAILURE:
      return produce(state, (draftState) => {
        draftState.pending = false;
        draftState.value.hasAlreadyCalled = true;
        draftState.errors = args?.payload?.errors?.errors
      });

    case ActionTypes.BRANDS_SUCCESS:
      return produce(state, (draftState) => {
        draftState.errors = []
        draftState.pending = false;
        draftState.value.hasAlreadyCalled = true;
        draftState.value.isAdministrator = args.payload?.value?.isAdministrator
        draftState.value.brands = args.payload?.value?.brands
      });

    default:
      return state;
  }
};
