
interface GetBrands {
  hasAlreadyCalled?: boolean;
  isAdministrator: boolean;
  brands: Brand[]
}

interface GetBrand {
  brand: Brand
}


interface BrandCommand {
  SearchCriteria: string;
}
interface UpdateBrandCommand {
  key: string;
  title: string,
  models: Model[];
  createdOn: string;
  description: string;
  
}
interface UpdateBrandResult {
  hasSucceeded: boolean;
  errorMessages: ErrorMessageItem[];
}
interface DeleteBrandCommand {
  BrandId: string;
}
interface DeleteBrandResult {
  hasSucceeded: boolean;
  errorMessages: ErrorMessageItem[];
}

interface Brand {
  id: string;
  title: string;
  models: Model[];
}

interface Model {
  id: string;
  brandId: string;
  title: string;
  description: string;
}
