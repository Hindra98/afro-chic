import {
  ColumnDirective,
  ColumnsDirective,
  Edit,
  ExcelExport,
  ExcelExportProperties,
  Filter,
  Sort,
  GridComponent,
  Inject,
  Page,
  PdfExport,
  PdfExportProperties,
  Resize,
  Selection,
  RecordClickEventArgs,
} from "@syncfusion/ej2-react-grids";
import { ReactElement, useRef, useState } from "react";
import Breadcrumb from "src/app/components/shared/breadcrumb";
import { useAppDispatch, useAppSelector } from "src/app/core/hooks/core-hooks";
import { useLocalizer } from "src/app/core/Localization";
import "src/app/styles/_notifications.scss";
import ToolsbarOptions from "src/app/components/shared/grid-components/toolsbar-options";
import emptyrecords from "src/app/components/shared/grid-components/empty-records";
import iconTenant from "src/app/assets/image-octopusfx/user.png";
import { GridConstants } from "src/app/core/constants/data-grid";
import { SidebarComponent } from "@syncfusion/ej2-react-navigations";
import CreateUpdateTenantSidebar from "./create-update-tenant-sidebar";
import {
  deleteTenant,
  exportPdfTenants,
  getTenant,
  getTenants,
} from "src/app/store-management/actions/tenants/tenants-actions";
import ConfirmActionsDialog from "src/app/components/shared/dialog-components/confirm-actions-dialog";

function statusTemplate(props) {
  return (
    <span
      className={`status rounded-xl text-center py-1 px-3 ${props.isEnable ? "active" : "inactive"}`}>
      {props.statusWording}
    </span>
  );
}
function nameTemplate(props) {
  return (
    <span className={`name-link cursor-pointer hover:text-blue-900 hover:underline hover:font-bold`}>
      {props.name}
    </span>
  );
}

const TenantDataGrid = () => {
  const commonLocalizer = useLocalizer("Common-ResCommon");
  const [isShowBackdrop, setShowBackdrop] = useState<boolean>(false);
  const [isEditing, setIsEditing] = useState<boolean>(false);
  let sidebarInstance = useRef<SidebarComponent>(null);
  let grid = useRef<GridComponent>(null);
  const dispatch = useAppDispatch();

  const getAllTenants = useAppSelector((state) => state.getTenants);

  const [getRefresh, setGetRefresh] = useState(false);
  const [checkRow, setCheckRow] = useState(false);
  const openSidebar = useState(false);

  const openDialog = useState(false);
  const [titleDialog, setTiltleDialog] = useState("");
  const [btnDialog, setBtnDialog] = useState([]);
  const [messageDialog, setMessageDialog] = useState<ReactElement>(null);

  const getTenantsData = () => {
    dispatch(getTenants());
  };
  const getTenantInfos = (key: string) => {
    dispatch(getTenant({ SearchCriteria: key } as TenantCommand));
  };

  if (
    !getRefresh &&
    !getAllTenants?.pending &&
    getAllTenants?.Errors?.length === 0
  ) {
    getTenantsData();
    setGetRefresh(true);
  }

  const sidebarClose = () => {
    openSidebar[1](false);
    sidebarInstance.current.hide();
    setShowBackdrop(false);
  };

  const [tenantViewModel, setTenantViewModel] = useState<any>({});

  const handleActionBegin = (args: any) => {
    if (args.requestType === "add" || args.requestType === "beginEdit") {
      sidebarInstance?.current?.toggle();
      setShowBackdrop(true);
      args.cancel = true;
    }
  };

  const handleAdd = () => {
    if (grid.current) {
      setIsEditing(false);
      getTenantInfos("");
      grid.current.addRecord();
    }
  };
  const handleClickRecord = (e: RecordClickEventArgs) => {
    if (grid.current) {
      const index = e.cellIndex;
      let keyRecord = e.rowData as Tenant;
      if (index > 0) {
        getTenantInfos(keyRecord.key);
        setIsEditing(true);
        setTenantViewModel({ ...tenantViewModel, key: keyRecord.key });
        grid.current.addRecord();
      } else {
        if (keyRecord.isDeletable) {
          const selectedRecords = grid.current.getSelectedRecords() as Tenant[];
          if (selectedRecords.length > 1 || selectedRecords.length === 0)
            setCheckRow(true);
          else {
            if (selectedRecords[0].key === keyRecord.key) setCheckRow(false);
            else setCheckRow(true);
          }
        }
      }
    }
  };

  const handleDelete = () => {
    if (grid.current) {
      const selectedRecords = grid.current.getSelectedRecords() as Tenant[];
      if (selectedRecords.length === 1) {
        setTiltleDialog(
          `Suppression d'un locataire: ${selectedRecords[0]?.name}`
        );
        setMessageDialog(
          <p>
            Voulez-vous vraiment supprimer cet locataire :{" "}
            <b>{selectedRecords[0]?.name}</b> ?{" "}
          </p>
        );
        setBtnDialog([
          {
            type: "button",
            name: "Annuler",
            css: "cancelBtn",
            handleClick: () => openDialog[1](false),
          },
          {
            type: "button",
            name: "Confirmer",
            css: "okBtn",
            handleClick: () => {
              dispatch(
                deleteTenant({
                  key: selectedRecords[0].key.toString(),
                } as DeleteTenantCommand)
              );
              openDialog[1](false);
            },
          },
        ]);
        openDialog[1](true);
      } else {
        setTiltleDialog(`Erreur!!!`);
        setMessageDialog(
          <p>
            Vous devez selectionner au moins un locataire pour cette opération
          </p>
        );
        setBtnDialog([
          {
            type: "button",
            name: "Ok",
            css: "okBtn",
            handleClick: () => openDialog[1](false),
          },
        ]);
        openDialog[1](true);
      }
    }
  };

  const handleSave = () => {
    if (grid.current) {
      grid.current.addRecord();
      grid.current.endEdit();
    }
    setShowBackdrop(false);
    sidebarInstance.current.hide();
  };

  const editSettings: any = {
    allowEditing: true,
    allowAdding: true,
    allowDeleting: true,
    mode: "Normal",
    allowEditOnDblClick: false,
  };
  const exportFilename = "tenant";
  const rowsPerPage = 1;
  const [currentPage, setCurrentPage] = useState(1);
  const handlePageChange = (page: number) => {
    grid.current.pageSettings.currentPage = page;
    setCurrentPage(page);
  };
  const handleSearch = (searchText: string) => {
    console.log("handle", searchText);
  };

  const select: any = {
    persistSelection: true,
    type: "Single",
    checkboxOnly: false,
    mode: "Both",
    checkboxMode: "ResetOnRowClick",
  };

  const gridFilter: any = { type: "Menu" };
  const pdfExportProperties: PdfExportProperties = {
    header: {
      fromTop: 0,
      height: 130,
      contents: [
        {
          type: "Line",
          style: { penColor: "#000080", penSize: 2, dashStyle: "Solid" },
          points: { x1: 0, y1: 4, x2: 685, y2: 4 },
        },
        {
          type: "Text",
          value: "Liste des locataires ",
          position: { x: 200, y: 50 },
          style: { textBrushColor: "#000000", fontSize: 20 },
        },
      ],
    },
    footer: {
      fromBottom: 10,
      height: 60,
      contents: [
        {
          type: "Line",
          style: { penColor: "#000080", penSize: 2, dashStyle: "Dot" },
          points: { x1: 0, y1: 4, x2: 685, y2: 4 },
        },
        {
          type: "PageNumber",
          pageNumberType: "Arabic",
          format: "Page {$current} sur {$total}",
          position: { x: 0, y: 25 },
          style: { textBrushColor: "#4169e1", fontSize: 15, hAlign: "Center" },
        },
      ],
    },
    exportType: "AllPages",
  };

  const ExportPdf = () => {
    let url = "https://api.8pusfx.com/v1/tenants/export-pdf";

    // (grid.current as GridComponent)?.serverPdfExport(url);

    let gridModel = JSON.parse(
      (grid.current as GridComponent).getPersistData()
    );
    gridModel.columns.forEach((e) => {
      if (e.columns) {
        (grid.current as GridComponent).setHeaderText(e.columns, e.columns);
      }
    });
    let form: HTMLFormElement = (grid.current as GridComponent)?.createElement(
      "form",
      {
        id: "ExportForm",
        styles: "display:none;",
      }
    );
    let gridInput = (grid.current as GridComponent)?.createElement("input", {
      id: "gridInput",
      attrs: { name: "gridModel" },
    });
    gridInput.value = JSON.stringify(gridModel);
    form.method = "POST";
    form.action = url;
    form.appendChild(gridInput);
    document.body.appendChild(form);

    // form.submit();
    // form.remove();

    const formData = new FormData(form);
    dispatch(exportPdfTenants(formData));

    // (grid.current as GridComponent)?.pdfExport({
    //   ...pdfExportProperties,
    //   fileName: `${exportFilename}.pdf`,
    // });
  };
  const ExportExcel = () => {
    const excelExportProperties: ExcelExportProperties = {
      exportType: "AllPages",
      fileName: `${exportFilename}.xlsx`,
    };
    (grid.current as GridComponent)?.excelExport({ ...excelExportProperties });
  };
  const ExportCsv = () => {
    const excelExportProperties: ExcelExportProperties = {
      exportType: "AllPages",
      fileName: `${exportFilename}.csv`,
    };
    (grid.current as GridComponent)?.csvExport({ ...excelExportProperties });
  };

  window.document.title = "Tenants";
  return (
    <div className="h-full flex flex-col justify-start mx-auto notifications-component">
      <div
        className={` text-3xl align-top flex flex-col justify-start ps-10 pt-4 flex-wrap my-2 gap-0 `}
      >
        <h1 className="">{"Tenants"}</h1>
        <Breadcrumb
          items={[
            {
              title: commonLocalizer("MODULE_COMMON_SIDEBAR_DASHBOARD"),
              link: "/dashboard",
            },
            { title: "Tenants" },
          ]}
        />
      </div>

      <ToolsbarOptions
        ToolsbarActionItem={[
          {
            icon: "user-addicon-",
            name: "Ajouter",
            handleClick: () => handleAdd(),
          },
          {
            icon: "trash-emptyicon-",
            name: "Supprimer",
            handleClick: () => handleDelete(),
            disabled: !checkRow,
          },
          {
            icon: "ccwicon-",
            name: "Rafraichir",
            handleClick: () => dispatch(getTenants()),
          },
        ]}
        allowExportPdf
        allowExportCsv
        allowExportExcel
        handleExportPdf={ExportPdf}
        handleExportExcel={ExportExcel}
        handleExportCsv={ExportCsv}
        enablePager
        pager={{ align: "right" }}
        enablePagination
        pagination={{
          currentPage: currentPage,
          rowsPerPage: rowsPerPage,
          totalPages: parseInt(
            getAllTenants?.value?.tenants?.length?.toString()
          ),
          handleChangePage: handlePageChange,
        }}
        enableSearch
        search={{ handleSearch: handleSearch }}
      />
      <GridComponent
        dataSource={getAllTenants.value.tenants}
        id="notifications-grid"
        cssClass="mx-2"
        loadingIndicator={{ indicatorType: "Shimmer" }}
        allowResizing={true}
        enableHover={true}
        allowSorting={false}
        allowFiltering={true}
        actionBegin={handleActionBegin}
        recordClick={handleClickRecord}
        emptyRecordTemplate={() =>
          emptyrecords(
            "Aucun tenant trouvé",
            iconTenant,
            getAllTenants.pending,
            "w-1/12"
          )
        }
        resizeSettings={{ mode: "Auto" }}
        rowHeight={38}
        height={GridConstants.HEIGHT}
        filterSettings={gridFilter}
        allowSelection={true}
        selectionSettings={select}
        enableHeaderFocus={true}
        allowPaging={true}
        autoFit={true}
        allowPdfExport={true}
        allowExcelExport={true}
        editSettings={editSettings}
        pageSettings={{ pageCount: 2, pageSize: rowsPerPage }}
        ref={grid}
      >
        <ColumnsDirective>
          <ColumnDirective
            type="checkbox"
            allowSorting={false}
            allowFiltering={false}
            width="40"
          ></ColumnDirective>
          <ColumnDirective
            field="key"
            visible={false}
            headerText="Tenant Key"
            isPrimaryKey={true}
            width="auto"
          ></ColumnDirective>
          <ColumnDirective
            field="logo"
            headerText="Logo"
            width="90px"
          ></ColumnDirective>
          <ColumnDirective
            field="name"
            headerText="Name"
            template={nameTemplate}
            clipMode="EllipsisWithTooltip"
            width="auto"
          />
          <ColumnDirective
            field="subscriptionID"
            headerText="Identifiant de l'abonnement"
            clipMode="EllipsisWithTooltip"
            width="auto"
          />
          <ColumnDirective
            field="databaseName"
            headerText="Database name"
            clipMode="EllipsisWithTooltip"
            width="auto"
          />
          <ColumnDirective
            field="statusWording"
            headerText="Etat"
            template={statusTemplate}
            clipMode="EllipsisWithTooltip"
            width="110px"
          />
          <ColumnDirective
            field="language"
            headerText="Language"
            width="175px"
          />
          <ColumnDirective
            field="regionalFormatId"
            headerText="Format regional"
            width="175px"
          />
        </ColumnsDirective>
        <Inject
          services={[
            Page,
            Filter,
            Sort,
            PdfExport,
            ExcelExport,
            Resize,
            Selection,
            Edit,
          ]}
        />
      </GridComponent>

      <CreateUpdateTenantSidebar
        isEditing={isEditing}
        func={{
          sidebarClose: sidebarClose.bind(this),
          isShowBackdrop: isShowBackdrop,
          sidebarInstance: sidebarInstance,
        }}
        handleSave={handleSave}
      />

      <ConfirmActionsDialog
        openDialog={openDialog}
        title={titleDialog}
        button={btnDialog}
      >
        {messageDialog}
      </ConfirmActionsDialog>
    </div>
  );
};

export default TenantDataGrid;
