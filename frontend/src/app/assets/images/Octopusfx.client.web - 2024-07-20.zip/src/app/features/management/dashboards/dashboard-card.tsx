import React from 'react'
import Button from 'src/app/components/form/Button';
import Indicators from './indicator';

type Props = React.PropsWithChildren<{
  hasTitle: boolean;
  title?: string;
  header: {
    title: string;
    options?: Options[];
  };
  buttons?: ParamsButton[];
  activeIndicator?: Indicator
  inactiveIndicator?: Indicator
  deleteIndicator?: Indicator
  hr?: boolean;
}>

type Options = {
  label: string;
  action?: () => void;
  icon?: string;
  css?: string;
}

type Indicator = {
  label?: string;
  value?: number;
  color?: string;
}

const DashboardCard = (props: Props) => {
  return (
    <div className='flex flex-col justify-between h-[500px] w-[350px] card-component overflow-hidden pt-1 px-3'>
      <div className='mb-3'>
        <div className='header flex flex-row justify-between items-start'>
          {props?.header?.title && (
            <h2 className='text-base'>{props?.header?.title}</h2>
          )}

          {props?.header?.options && (
            <div className='flex flex-col items-start justify-start gap-2 group cursor-pointe relative'>
              <span className='icon dot-3icon- self-end text-gray-400'></span>
              {/* <ul className='absolute top-auto left-auto p-0 h-0 w-0 overflow-hidden group-hover:w-max group-hover:h-fit mt-5 group-hover:p-2 rounded-md bg-[rgba(255,255,255,1)] -ms-24'>
                {props?.header?.options?.map((option, index) => (
                  <li key={index}>
                    <span onClick={option?.action} className={`flex gap-2 items-center cursor-pointer ${option?.css ? option?.css : ''}`}>
                      {option?.icon && <span className={`icon ${option?.icon}`}></span>}
                      {option?.label}
                    </span>
                    {(index < props?.header?.options?.length - 1) && <hr />}
                  </li>
                ))}
              </ul> */}
            </div>
          )}
        </div>
        <hr className='mt-1 h-[1px] opacity-20' />
      </div>
      <div className="content mb-auto flex flex-col gap-4 pb-4">

        {props?.hasTitle && <h2 className='text-gray-700 text-2xl font-bold'>{props?.title}</h2>}

        <div className='indicators flex flex-row gap-8 py-4 flex-wrap mb-5'>

          {props?.activeIndicator && <Indicators label={props?.activeIndicator?.label} value={props?.activeIndicator?.value<10? '0'+props?.activeIndicator?.value.toString(): props?.activeIndicator?.value.toString()} color={props?.activeIndicator?.color} /> }
          {props?.inactiveIndicator && <Indicators label={props?.inactiveIndicator?.label} value={props?.inactiveIndicator?.value<10? '0'+props?.inactiveIndicator?.value.toString(): props?.inactiveIndicator?.value.toString()} color={props?.inactiveIndicator?.color} /> }
          {props?.deleteIndicator && <Indicators label={props?.deleteIndicator?.label} value={props?.deleteIndicator?.value<10? '0'+props?.deleteIndicator?.value.toString(): props?.deleteIndicator?.value.toString()} color={props?.deleteIndicator?.color} /> }

        </div>

        {props?.hr && <hr className='mb-7 mt-3 h-[2px] opacity-40' />}

        {props?.children}

      </div>

      {props?.buttons && (
        <div className='flex flex-row justify-end items-center gap-2'>
          {props?.buttons?.map((button, index) => (
            <div key={index} className={`button ${button?.css ?? ''}`}>
              <Button param={button} />
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

export default DashboardCard