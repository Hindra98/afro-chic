import { GetAuditsAction, GetAuditsFailurePayload } from ".";
import { ActionTypes } from "../constants/action-types";

export const getAudits = (): GetAuditsAction => {
  
  return {
      type: ActionTypes.GET_AUDITS_REQUEST,
      payload: {
          command: null,
          user: null,
          errors: null
      }
  } as GetAuditsAction
};

export const getAuditsFailure = (payload: GetAuditsFailurePayload): GetAuditsAction => {

  return {
      type: ActionTypes.GET_AUDITS_FAILURE,
      payload: {
          command: null,
          user: null,
          errors: payload
      }
  } as GetAuditsAction;
};

export const getAuditsSuccess = (payload: GetAudits): GetAuditsAction => {

  return {
      type: ActionTypes.GET_AUDITS_SUCCESS,
      payload: {
          command: null,
          user: payload,
          errors: null
      }
  } as GetAuditsAction;
};
