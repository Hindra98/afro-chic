import { SidebarComponent } from "@syncfusion/ej2-react-navigations";
import { MutableRefObject } from "react";
import Button from "src/app/components/form/Button";
import { ShimmerText } from "src/app/components/shared/shimmer";
import { useAppSelector } from "src/app/core/hooks/core-hooks";

type DataAudits = {
  title?: string;
  func: FuncAudits;
  audit: AuditItem;
};

type FuncAudits = {
  sidebarInstance: MutableRefObject<SidebarComponent>;
  sidebarClose: () => void;
  isShowBackdrop: boolean;
};
export default function ViewAuditSidebar(data: DataAudits) {
  const getAuditsData = useAppSelector((state) => state.getAudits);

  function formatJson(val: string, profondeur: number = 0) {
    if (val) {
      const payload = JSON.parse(val);
      const items = Object.keys(payload).map((key) => ({
        label: key,
        value: payload[key],
      }));

      return (
        <ul className={`w-full py-3 px-4 bg-gray-${profondeur} border-2 border-gray-400 border-dashed`}>
          {items.map((item, key) => {
            return (
              <li key={key}>
                {item.label}:{" "}
                {typeof item.value === "object" && item.value !== null
                  ? formatJson(JSON.stringify(item.value), profondeur + 100)
                  : typeof item.value === "boolean"
                    ? item.value.toString()
                    : typeof item.value === "number"
                      ? item.value.toString()
                      : item.value}
              </li>
            );
          })}
        </ul>
      );
    }
    return null;
  }

  function getPayloads(payloads: string) {
    if (payloads) {
      const payload = JSON.parse(payloads);
      const items = Object.keys(payload).map((key) => ({
        label: key,
        value: payload[key],
      }));

      return (
        <ul className="w-full border-2 border-gray-400 p-2 bg-gray-200">
          {items.map((item, key) => {
            return (
              <li key={key}>
                {item.label}:
                {typeof item.value === "object" && item.value !== null
                  ? formatJson(JSON.stringify(item.value), 300)
                  : typeof item.value === "boolean" ||
                    typeof item.value === "number"
                    ? item.value.toString()
                    : item.value}
              </li>
            );
          })}
        </ul>
      );
    }
    return null;
  }

  return (
    <SidebarComponent
      ref={data?.func?.sidebarInstance}
      closeOnDocumentClick={false}
      showBackdrop={data?.func?.isShowBackdrop}
      width="700px"
      target=".apimaincontent"
      id="apiSidebar"
      className="tenant-sidebar"
      type={"Over"}
      enableGestures={false}
      position={"Right"}
    >
      <div className="flex flex-col justify-start items-center h-full py-7 relative">
        <div className="flex flex-row justify-between w-full px-9 mt- mb-2">
          <h2 className="text-3xl title">Détails de la commande</h2>
          <span
            className="icon cursor-pointer cancelicon- text-2xl"
            onClick={data?.func?.sidebarClose?.bind(this)}
          ></span>
        </div>

        <div className="infos w-full px-8">
          {getAuditsData.pending ? (
            <div className="flex flex-col w-full h-full gap-0 mx-auto">
              <div className="w-full mx-auto">
                <ShimmerText />
              </div>
              <div className="w-full mx-auto">
                <ShimmerText />
              </div>
              <div className="w-full mx-auto">
                <ShimmerText />
              </div>
            </div>
          ) : (
            <div className="flex flex-col justify-between items-center gap-4 w-full my-8 px-4 text-lg break-words">
              <div className="flex flex-row items-center gap-3 nom w-full">
                <label htmlFor="name" className="font-bold">
                  Nom de la commande :
                </label>
                <p className="text-gray-800">{data?.audit?.name}</p>
              </div>

              <div className="flex flex-row items-center gap-3 nom w-full">
                <label htmlFor="name" className="font-bold">
                  Identifiant de la commande :
                </label>
                <p className="text-gray-800">{data?.audit?.externalId}</p>
              </div>

              <div className="flex flex-row items-center gap-3 nom w-full">
                <label htmlFor="name" className="font-bold">
                  Effectué par :
                </label>
                <p className="text-gray-800">{data?.audit?.createdBy}</p>
              </div>

              <div className="flex flex-row items-center gap-3 nom w-full">
                <label htmlFor="name" className="font-bold">
                  Adresse IP :
                </label>
                <p className="text-gray-800">{data?.audit?.sourceIP}</p>
              </div>

              <div className="flex flex-row items-center gap-3 nom w-full">
                <label htmlFor="name" className="font-bold">
                  Navigateur :
                </label>
                <p className="text-gray-800">{data?.audit?.browser}</p>
              </div>

              <div className="flex flex-row items-center gap-3 nom w-full">
                <label htmlFor="name" className="font-bold">
                  Système d'exploitation :
                </label>
                <p className="text-gray-800">{data?.audit?.operationSystem}</p>
              </div>

              <div className="flex flex-row items-center gap-3 nom w-full">
                <label htmlFor="name" className="font-bold">
                  Identifiant de corrélation :
                </label>
                <p className="text-gray-800">{data?.audit?.correlationId}</p>
              </div>

              <div className="flex flex-row items-center gap-3 nom w-full">
                <label htmlFor="name" className="font-bold">
                  Crée le :
                </label>
                <p className="text-gray-800">{data?.audit?.createdOnWording}</p>
              </div>

              <div className="flex flex-col items-start gap-3 nom w-full break-words">
                <label htmlFor="name" className="font-bold">
                  Charge utile :
                </label>
                {getPayloads(data?.audit?.payload)}
              </div>
            </div>
          )}
        </div>

        <div className="flex flex-row gap-4 justify-end footer p-8 ms-auto mt-auto">
          <Button
            param={{
              type: "button",
              name: "Ok",
              handleClick: data?.func?.sidebarClose?.bind(this),
              css: "okBtn w-full",
            }}
          />
        </div>
      </div>
    </SidebarComponent>
  );
}
