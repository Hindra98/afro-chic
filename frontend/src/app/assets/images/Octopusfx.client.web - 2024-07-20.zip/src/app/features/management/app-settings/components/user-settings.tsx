import React, { Dispatch, SetStateAction } from 'react'
import SwitchSettingsLine from '../switch-settings-line'
import CardSettings from '../card-settings'
import { useAppSelector } from 'src/app/core/hooks/core-hooks'
import { ChangeEventArgs } from "@syncfusion/ej2/dropdowns";
import { ShimmerText } from 'src/app/components/shared/shimmer'
import { DropDownListComponent } from '@syncfusion/ej2-react-dropdowns'
import { SwitchComponent } from '@syncfusion/ej2-react-buttons';
import { useLocalizer } from 'src/app/core/Localization';

type ItemFields = {
  text: string;
  value: string;
  iconCss: string;
};

type Props = {
  viewModel?: {
    acceptSMSNotifications: boolean;
    acceptEmailNotifications: boolean;
    twoFactorAuthentication: boolean;
    preferedNotificationChannel: string;
    preferedLanguage: string;
    vibrateMode: boolean;
  }
  setViewModel?: Dispatch<SetStateAction<{
    acceptSMSNotifications: boolean;
    acceptEmailNotifications: boolean;
    twoFactorAuthentication: boolean;
    preferedNotificationChannel: string;
    preferedLanguage: string;
    vibrateMode: boolean;
  }>>
  errorsAppSettings?
}
/**
 * `UserSettings` defines user settings like those in the profile.
 * ```tsx
 *   <UserSettings errorsAppSettings={errorsAppSettings} viewModel={userSettingsViewModel} setViewModel={setUserSettingsViewModel} />
 * ```
 */
const UserSettings = ({ errorsAppSettings = null, setViewModel, viewModel }: Props) => {
  const commonLocalizer = useLocalizer("Common-ResCommon");

  const getAppSettingsData = useAppSelector((state) => state.getAppSettings);

  const allLanguage = (): { [key: string]: Object }[] => {
    let newLang: { [key: string]: Object }[] = [];
    getAppSettingsData.value.languages.map((item) =>
      newLang.push({
        "value": item.twoLetterISOLanguageName,
        "langue": item.displayName,
        "iconLang": ""
      })
    );
    return newLang;
  }

  const language: { [key: string]: Object }[] = allLanguage();
  const languageFields: ItemFields = { text: 'langue', value: 'value', iconCss: 'iconLang' };

  const handleComboBoxChange = (args: ChangeEventArgs, item: string, itemFields: ItemFields) => {
    setViewModel({
      ...viewModel,
      [item]: (args.itemData === null) ? 'null' : args.itemData[itemFields.value].toString()
    });
  }
  const handleSwitchChange = (e, text: string) => {
    const value = e.checked;
    setViewModel({
      ...viewModel,
      [text]: value,
    });
  }

  return (
    <>
      {getAppSettingsData.pending ? (<div className="p-0 m-0 w-full mx-auto"><ShimmerText /><ShimmerText /><ShimmerText /></div>) : (
        <CardSettings title={commonLocalizer("MODULE_COMMON_WEB_SETTINGS_USER_PREFERENCES_TITLE")}>
          <div className="preferedNotificationChannel flex flex-col gap-2 justify-between w-full p-0 m-0">
            <div className="flex flex-row gap-5 justify-between w-full p-0 m-0">
              <label htmlFor="preferedNotificationChannel" className="w-1/3 label-disabled">{commonLocalizer("MODULE_COMMON_WEB_SETTINGS_USER_PREFERENCES_PREFERED_COMMUNICATION_CHANNEL")}</label>
              <div
                className="w-3/4 py-1 input-notif flex justify-start gap-5 md:flex-row xxs:flex-col"
                id="preferedNotificationChannel"
              >

                <label htmlFor="email" className="label-disabled">{commonLocalizer("MODULE_COMMON_WEB_SETTINGS_USER_PREFERENCES_EMAIL")}</label>
                <SwitchComponent
                  id={viewModel.preferedNotificationChannel}
                  checked={viewModel.preferedNotificationChannel === "SMS"}
                  value="false"
                  name={viewModel.preferedNotificationChannel}
                  cssClass={"label-disabled switcher"}
                  readOnly={true}
                  disabled={true}
                ></SwitchComponent>
                <label htmlFor="sms" className="label-disabled">{commonLocalizer("MODULE_COMMON_WEB_SETTINGS_USER_PREFERENCES_SMS")}</label>
              </div>
            </div>
            {errorsAppSettings.preferedNotificationChannel &&
              (<div className="error">{errorsAppSettings.preferedNotificationChannel.toString()}</div>)}
          </div>

          <div className="preferedLanguage flex flex-col gap-2 justify-between w-full p-0 m-0">
            <div className="flex flex-row gap-5 justify-between w-full p-0 m-0">
              <label htmlFor="preferedLanguage" className="w-1/3 label-disabled">{commonLocalizer("MODULE_COMMON_WEB_SETTINGS_USER_PREFERENCES_PREFERED_LANGUAGE")}</label>
              <div className="w-3/4">
                <DropDownListComponent
                  cssClass="px-2 py-1 input-notify label-disabled"
                  id="preferedLanguage"
                  dataSource={language}
                  fields={languageFields}
                  disabled={true}
                  readonly={true}
                  change={(args) => handleComboBoxChange(args, "preferedLanguage", languageFields)}
                  value={viewModel.preferedLanguage}
                  placeholder={commonLocalizer("MODULE_COMMON_WEB_SETTINGS_USER_PREFERENCES_PREFERED_LANGUAGE_HELP")}
                  popupHeight="220px"
                />
              </div>
            </div>
            {errorsAppSettings.preferedLanguage &&
              (<div className="error">{errorsAppSettings.preferedLanguage.toString()}</div>)}
          </div>
          <SwitchSettingsLine disabled={true} change={(e) => handleSwitchChange(e, "acceptSMSNotifications")} title={commonLocalizer("MODULE_COMMON_WEB_SETTINGS_USER_PREFERENCES_ACCEPT_SMS_NOTIFICATIONS")} name="acceptSMSNotifications" description={commonLocalizer("MODULE_COMMON_WEB_SETTINGS_USER_PREFERENCES_ACCEPT_SMS_NOTIFICATIONS_HELP")} checked={viewModel.acceptSMSNotifications} />
          <SwitchSettingsLine disabled={true} change={(e) => handleSwitchChange(e, "acceptEmailNotifications")} title={commonLocalizer("MODULE_COMMON_WEB_SETTINGS_USER_PREFERENCES_ACCEPT_EMAIL_NOTIFICATIONS")} name="acceptEmailNotifications" description={commonLocalizer("MODULE_COMMON_WEB_SETTINGS_USER_PREFERENCES_ACCEPT_EMAIL_NOTIFICATIONS_HELP")} checked={viewModel.acceptEmailNotifications} />
          <SwitchSettingsLine disabled={true} change={(e) => handleSwitchChange(e, "twoFactorAuthentication")} title={commonLocalizer("MODULE_COMMON_WEB_SETTINGS_USER_PREFERENCES_ENABLE_2FA")} name="twoFactorAuthentication" description={commonLocalizer("MODULE_COMMON_WEB_SETTINGS_USER_PREFERENCES_ENABLE_2FA_HELP")} checked={viewModel.twoFactorAuthentication} />
          <SwitchSettingsLine change={(e) => handleSwitchChange(e, "vibrateMode")} title={commonLocalizer("MODULE_COMMON_WEB_SETTINGS_USER_PREFERENCES_ENABLE_VIBRATE_MODE")} name="vibrateMode" description={commonLocalizer("MODULE_COMMON_WEB_SETTINGS_USER_PREFERENCES_ENABLE_VIBRATE_MODE_HELP")} checked={viewModel.vibrateMode} />
        </CardSettings>
      )}
    </>
  )
}

export default UserSettings