import { DropDownListComponent } from "@syncfusion/ej2-react-dropdowns";
import {
  SidebarComponent,
  TabAnimationSettingsModel,
  TabComponent,
  TabItemDirective,
  TabItemsDirective,
} from "@syncfusion/ej2-react-navigations";
import { MessageComponent } from "@syncfusion/ej2-react-notifications";
import { MutableRefObject, useRef, useState } from "react";
import Button from "src/app/components/form/Button";
import InputWithIcon from "src/app/components/form/Input";
import OperationResultComponent from "src/app/components/shared/operation-result-component";
import { ShimmerText } from "src/app/components/shared/shimmer";
import { useAppDispatch, useAppSelector } from "src/app/core/hooks/core-hooks";
import {
  validateFormData,
  ValidationType,
  Validator,
} from "src/app/core/text/regex";
import { updateVehicle } from "src/app/store-management/actions/vehicles/vehicles-actions";
import VehicleDocuments from "./vehicle-documents";
import { v4 as uuidv4 } from "uuid";
import TextArea from "src/app/components/form/TextArea";
import { DatePickerComponent } from "@syncfusion/ej2-react-calendars";

type DataVehicle = {
  isEditing?: boolean;
  func: FuncVehicle;
};

type FuncVehicle = {
  sidebarInstance: MutableRefObject<SidebarComponent>;
  sidebarClose: () => void;
  isShowBackdrop: boolean;
};
type ItemFields = {
  text: string;
  value: string;
  iconCss: string;
  index?: string;
};
export interface FieldVehicle {
  value?: string | boolean | number;
  error?: string;
}
export interface FormVehicle {
  VIN?: FieldVehicle;
  EngineNumber?: FieldVehicle;
  GearNumber?: FieldVehicle;
  RegistrationNumber?: FieldVehicle;
  Name?: FieldVehicle;
  GearBoxType?: FieldVehicle;
  CommissionStartingDate?: FieldVehicle;
  CommissionEndDate?: FieldVehicle;
  ModelYear?: FieldVehicle;
  CO2Emissions?: FieldVehicle;
  Description?: FieldVehicle;
  ModelId?: FieldVehicle;
  BrandId?: FieldVehicle;
  Status?: FieldVehicle;
  EnergyType?: FieldVehicle;
  VehicleType?: FieldVehicle;
  Summary?: FieldVehicle;
  CreatedOn?: FieldVehicle;

  Images?: FieldVehicle[];
  Documents?: FieldVehicle[];
}

export interface FormVehicleValidation {
  vin?: Validator;
  engineNumber?: Validator;
  registrationNumber?: Validator;
  gearNumber?: Validator;
  name?: Validator;
  gearBoxType?: Validator;
  commissionStartingDate?: Validator;
  commissionEndDate?: Validator;
  modelYear?: Validator;
  cO2Emissions?: Validator;
  modelId?: Validator;
  brandId?: Validator;
  status?: Validator;
  energyType?: Validator;
  vehicleType?: Validator;
}
type DocumentVehicle = {
  id: string;
  document: string;
};

export default function CreateUpdateVehicleSidebar(data: DataVehicle) {
  const getVehicleData = useAppSelector((state) => state.getVehicle);
  const updateVehicleData = useAppSelector((state) => state.updateVehicle);
  const dispatch = useAppDispatch();
  const [showServerErrorMessage, setShowServerErrorMessage] = useState(false);
  let vehicleTabInstance = useRef<TabComponent>(null);
  const [images, setImages] = useState<DocumentVehicle[]>([]);
  const [documents, setDocuments] = useState<DocumentVehicle[]>([]);
  const [models, setModels] = useState<Model[]>([]);

  let closefailedMsg = document
    ?.getElementById("msg_error")
    ?.getElementsByClassName("e-msg-close-icon");
  for (var i = 0; i < closefailedMsg?.length; i++) {
    closefailedMsg[i]?.addEventListener("click", () => {
      setShowServerErrorMessage(false);
      document.getElementById("msg_error")?.setAttribute("class", "h-0 hidden");
      document
        .getElementById("msg_server")
        ?.setAttribute("class", "h-0 hidden");
    });
  }

  const [vehicleModel, setVehicleModel] = useState<FormVehicle>({});

  const vehicleModelValidation: FormVehicleValidation = {
    name: {
      validatorType: ValidationType.REQUIRED,
      message: "Nom obligatoire",
    },
    vin: {
      validatorType: ValidationType.REQUIRED,
      message: "Numéro du châssis obligatoire",
    },
    engineNumber: {
      validatorType: ValidationType.REQUIRED,
      message: "Numéro de moteur obligatoire",
    },
    registrationNumber: {
      validatorType: ValidationType.REQUIRED,
      message: "Numéro d'immatriculation obligatoire",
    },
    gearNumber: {
      validatorType: ValidationType.REQUIRED,
      message: "Numéro d'engrenage obligatoire",
    },
    gearBoxType: {
      validatorType: ValidationType.REQUIRED,
      message: "Boite de vitesse obligatoire",
    },
    commissionStartingDate: {
      validatorType: ValidationType.REQUIRED,
      message: "Date de début de commission obligatoire",
    },
    commissionEndDate: {
      validatorType: ValidationType.REQUIRED,
      message: "Date de fin de commission obligatoire",
    },
    modelYear: {
      validatorType: ValidationType.REQUIRED,
      message: "Année de modèle obligatoire",
    },
    cO2Emissions: {
      validatorType: ValidationType.REQUIRED,
      message: "Emission du CO2 obligatoire",
    },
    brandId: {
      validatorType: ValidationType.REQUIRED,
      message: "Marque obligatoire",
    },
    modelId: {
      validatorType: ValidationType.REQUIRED,
      message: "Modèle obligatoire",
    },
    status: {
      validatorType: ValidationType.REQUIRED,
      message: "Statut obligatoire",
    },
    energyType: {
      validatorType: ValidationType.REQUIRED,
      message: "Type de carburant utilisé obligatoire",
    },
    vehicleType: {
      validatorType: ValidationType.REQUIRED,
      message: "Type de véhicule obligatoire",
    },
  };
  const [actu, setActu] = useState(false);
  const [showServerSuccessMessage, setShowServerSuccessMessage] =
    useState(false);

  const initialData = () => {
    setVehicleModel({});
    setImages([]);
    setDocuments([]);
    setShowServerSuccessMessage(false);
    setShowServerErrorMessage(false);
    setActu(false);
    vehicleTabInstance?.current?.select(0);
    vehicleTabInstance?.current?.select(3);
    vehicleTabInstance?.current?.select(2);
    vehicleTabInstance?.current?.select(1);
    vehicleTabInstance?.current?.select(0);
  };

  if (!actu && !getVehicleData?.pending) {
    setVehicleModel({
      VIN: {
        value: getVehicleData?.value?.vehicle?.vin?.toString(),
        error: "",
      },
      EngineNumber: {
        value: getVehicleData?.value?.vehicle?.engineNumber?.toString(),
        error: "",
      },
      RegistrationNumber: {
        value: getVehicleData?.value?.vehicle?.registrationNumber?.toString(),
        error: "",
      },
      GearNumber: {
        value: getVehicleData?.value?.vehicle?.gearNumber?.toString(),
        error: "",
      },
      Name: {
        value: getVehicleData?.value?.vehicle?.name?.toString(),
        error: "",
      },
      GearBoxType: {
        value: getVehicleData?.value?.vehicle?.gearBoxType?.toString(),
        error: "",
      },
      CommissionStartingDate: {
        value:
          getVehicleData?.value?.vehicle?.commissionStartingDate?.toString(),
        error: "",
      },
      CommissionEndDate: {
        value: getVehicleData?.value?.vehicle?.commissionEndDate?.toString(),
        error: "",
      },
      ModelYear: {
        value: getVehicleData?.value?.vehicle?.modelYear,
        error: "",
      },
      BrandId: {
        value: getVehicleData?.value?.vehicle?.brandId,
        error: "",
      },
      ModelId: {
        value: getVehicleData?.value?.vehicle?.modelId,
        error: "",
      },
      CO2Emissions: {
        value: getVehicleData?.value?.vehicle?.cO2Emissions,
        error: "",
      },
      Description: {
        value: getVehicleData?.value?.vehicle?.description?.toString(),
        error: "",
      },
      Status: {
        value: getVehicleData?.value?.vehicle?.status?.toString(),
        error: "",
      },
      EnergyType: {
        value: getVehicleData?.value?.vehicle?.energyType?.toString(),
        error: "",
      },
      VehicleType: {
        value: getVehicleData?.value?.vehicle?.vehicleType?.toString(),
        error: "",
      },
      Images: getVehicleData?.value?.vehicle?.imageUrls.map((imageUrl) => ({
        value: imageUrl?.toString(),
        error: "",
      })),
      Documents: getVehicleData?.value?.vehicle?.documentUrls.map(
        (documentUrl) => ({
          value: documentUrl?.toString(),
          error: "",
        })
      ),
    });

    getVehicleData?.value?.brands?.map(
      (brand, index) =>
        brand.id === getVehicleData?.value?.vehicle?.brandId?.toString() &&
        setModels(getVehicleData?.value?.brands[index]?.models)
    );

    getVehicleData?.value?.vehicle?.imageUrls?.length > 0 &&
      setImages(
        getVehicleData?.value?.vehicle?.imageUrls?.map((image, index) => ({
          id: "image_" + index,
          document: image,
        }))
      );
    getVehicleData?.value?.vehicle?.documentUrls?.length > 0 &&
      setDocuments(
        getVehicleData?.value?.vehicle?.documentUrls?.map(
          (document, index) => ({
            id: "document_" + index,
            document: document,
          })
        )
      );
    setActu(true);
  }
  const handleChangeImage = (
    id: string,
    data: string = "",
    add: boolean = true
  ) => {
    if (add) {
      setImages([
        ...images,
        {
          id: id,
          document: data,
        },
      ]);
    } else {
      const updatedImages = images.filter((image) => image.id !== id);
      setImages(updatedImages);
    }
  };
  const handleChangeDocument = (
    id: string,
    data: string = "",
    add: boolean = true
  ) => {
    if (add) {
      setDocuments([
        ...documents,
        {
          id: id,
          document: data,
        },
      ]);
    } else {
      const updateddocuments = documents.filter(
        (document) => document.id !== id
      );
      setDocuments(updateddocuments);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const vehicleForm = document.querySelector("form");
    const formData = new FormData(vehicleForm);

    const nameErr: Validator = validateFormData(
      formData.get("Name"),
      vehicleModelValidation?.name
    )?.errors;
    const vinErr: Validator = validateFormData(
      formData.get("VIN"),
      vehicleModelValidation?.vin
    )?.errors;
    const engineNumberErr: Validator = validateFormData(
      formData.get("EngineNumber"),
      vehicleModelValidation?.engineNumber
    )?.errors;
    const registrationNumberErr: Validator = validateFormData(
      formData.get("RegistrationNumber"),
      vehicleModelValidation?.registrationNumber
    )?.errors;
    const gearNumberErr: Validator = validateFormData(
      formData.get("GearNumber"),
      vehicleModelValidation?.gearNumber
    )?.errors;
    const gearBoxTypeErr: Validator = validateFormData(
      formData.get("GearBoxType"),
      vehicleModelValidation?.gearBoxType
    )?.errors;
    const commissionStartingDateErr: Validator = validateFormData(
      formData.get("CommissionStartingDate"),
      vehicleModelValidation?.commissionStartingDate
    )?.errors;
    const commissionEndDateErr: Validator = validateFormData(
      formData.get("CommissionEndDate"),
      vehicleModelValidation?.commissionEndDate
    )?.errors;
    const modelYearErr: Validator = validateFormData(
      formData.get("ModelYear"),
      vehicleModelValidation?.modelYear
    )?.errors;
    const cO2EmissionsErr: Validator = validateFormData(
      formData.get("CO2Emissions"),
      vehicleModelValidation?.cO2Emissions
    )?.errors;
    const brandIdErr: Validator = validateFormData(
      formData.get("BrandId"),
      vehicleModelValidation?.brandId
    )?.errors;
    const modelIdErr: Validator = validateFormData(
      formData.get("ModelId"),
      vehicleModelValidation?.modelId
    )?.errors;
    const statusErr: Validator = validateFormData(
      formData.get("Status"),
      vehicleModelValidation?.status
    )?.errors;
    const energyTypeErr: Validator = validateFormData(
      formData.get("EnergyType"),
      vehicleModelValidation?.energyType
    )?.errors;
    const vehicleTypeErr: Validator = validateFormData(
      formData.get("VehicleType"),
      vehicleModelValidation?.vehicleType
    )?.errors;

    setVehicleModel({
      ...vehicleModel,
      Name: {
        value: formData.get("Name")?.toString(),
        error: nameErr?.message ?? "",
      },
      VIN: {
        value: formData.get("VIN")?.toString(),
        error: vinErr?.message ?? "",
      },
      EngineNumber: {
        value: formData.get("EngineNumber")?.toString(),
        error: engineNumberErr?.message ?? "",
      },
      RegistrationNumber: {
        value: formData.get("RegistrationNumber")?.toString(),
        error: registrationNumberErr?.message ?? "",
      },
      GearNumber: {
        value: formData.get("GearNumber")?.toString(),
        error: gearNumberErr?.message ?? "",
      },
      GearBoxType: {
        value: formData.get("GearBoxType")?.toString(),
        error: gearBoxTypeErr?.message ?? "",
      },
      CommissionEndDate: {
        value: formData.get("CommissionEndDate")?.toString(),
        error: commissionEndDateErr?.message ?? "",
      },
      ModelYear: {
        value: formData.get("ModelYear")?.toString(),
        error: modelYearErr?.message ?? "",
      },
      CO2Emissions: {
        value: formData.get("CO2Emissions")?.toString(),
        error: cO2EmissionsErr?.message ?? "",
      },
      ModelId: {
        value: formData.get("ModelId")?.toString(),
        error: modelIdErr?.message ?? "",
      },
      BrandId: {
        value: formData.get("BrandId")?.toString(),
        error: brandIdErr?.message ?? "",
      },
      Status: {
        value: formData.get("Status")?.toString(),
        error: statusErr?.message ?? "",
      },
      EnergyType: {
        value: formData.get("EnergyType")?.toString(),
        error: energyTypeErr?.message ?? "",
      },
      VehicleType: {
        value: formData.get("VehicleType")?.toString(),
        error: vehicleTypeErr?.message ?? "",
      },
      Description: {
        value: formData.get("Description")?.toString(),
        error: "",
      },
    });

    if (
      !(
        nameErr?.message ||
        vinErr?.message ||
        gearNumberErr?.message ||
        registrationNumberErr?.message ||
        gearBoxTypeErr?.message ||
        statusErr?.message ||
        brandIdErr?.message ||
        modelIdErr?.message ||
        engineNumberErr?.message ||
        modelYearErr?.message ||
        cO2EmissionsErr?.message ||
        energyTypeErr?.message ||
        vehicleTypeErr?.message ||
        commissionStartingDateErr?.message ||
        commissionEndDateErr?.message
      )
    ) {
      // const img = formData.getAll("Images");
      // const doc = formData.getAll("Documents");
      // formData.delete("Images")
      // formData.delete("Documents")
      // formData.append("Images", JSON.stringify(img))
      // formData.append("Documents", JSON.stringify(doc))
      formData.append("key", getVehicleData?.value?.vehicle?.id?.toString());
      formData.append("Summary", "image");
      dispatch(updateVehicle(formData));

      console.log("vehicleModel: ", formData);
      setShowServerErrorMessage(true);
      setShowServerSuccessMessage(true);
    } else {
      if (
        !(
          nameErr?.message ||
          vinErr?.message ||
          registrationNumberErr?.message ||
          gearNumberErr?.message ||
          vehicleTypeErr?.message ||
          brandIdErr?.message ||
          modelIdErr?.message ||
          modelYearErr?.message ||
          statusErr?.message
        )
      ) {
        vehicleTabInstance?.current?.select(1);
      }
      if (
        !(
          engineNumberErr?.message ||
          gearBoxTypeErr?.message ||
          commissionStartingDateErr?.message ||
          commissionEndDateErr?.message ||
          cO2EmissionsErr?.message ||
          energyTypeErr?.message
        )
      ) {
        vehicleTabInstance?.current?.select(0);
      }
    }
  };

  const getModels = (e) => {
    const vehicleForm = document.querySelector("form");
    const formData = new FormData(vehicleForm);

    setVehicleModel({
      ...vehicleModel,
      Name: {
        value: formData.get("Name")?.toString(),
        error: "",
      },
      VIN: {
        value: formData.get("VIN")?.toString(),
      },
      EngineNumber: {
        value: formData.get("EngineNumber")?.toString(),
      },
      RegistrationNumber: {
        value: formData.get("RegistrationNumber")?.toString(),
      },
      GearNumber: {
        value: formData.get("GearNumber")?.toString(),
      },
      GearBoxType: {
        value: formData.get("GearBoxType")?.toString(),
      },
      CommissionEndDate: {
        value: formData.get("CommissionEndDate")?.toString(),
      },
      ModelYear: {
        value: formData.get("ModelYear")?.toString(),
      },
      CO2Emissions: {
        value: formData.get("CO2Emissions")?.toString(),
      },
      ModelId: {
        value: formData.get("ModelId")?.toString(),
      },
      BrandId: {
        value: formData.get("BrandId")?.toString(),
      },
      Status: {
        value: formData.get("Status")?.toString(),
      },
      EnergyType: {
        value: formData.get("EnergyType")?.toString(),
      },
      VehicleType: {
        value: formData.get("VehicleType")?.toString(),
      },
      Description: {
        value: formData.get("Description")?.toString(),
      },
    });

    setModels(
      getVehicleData?.value?.brands[e?.target?.itemData?.index]?.models
    );
  };
  const handleChangeCombo = () => {
    const vehicleForm = document.querySelector("form");
    const formData = new FormData(vehicleForm);

    setVehicleModel({
      ...vehicleModel,
      Name: {
        value: formData.get("Name")?.toString(),
        error: "",
      },
      VIN: {
        value: formData.get("VIN")?.toString(),
      },
      EngineNumber: {
        value: formData.get("EngineNumber")?.toString(),
      },
      RegistrationNumber: {
        value: formData.get("RegistrationNumber")?.toString(),
      },
      GearNumber: {
        value: formData.get("GearNumber")?.toString(),
      },
      GearBoxType: {
        value: formData.get("GearBoxType")?.toString(),
      },
      CommissionEndDate: {
        value: formData.get("CommissionEndDate")?.toString(),
      },
      ModelYear: {
        value: formData.get("ModelYear")?.toString(),
      },
      CO2Emissions: {
        value: formData.get("CO2Emissions")?.toString(),
      },
      ModelId: {
        value: formData.get("ModelId")?.toString(),
      },
      BrandId: {
        value: formData.get("BrandId")?.toString(),
      },
      Status: {
        value: formData.get("Status")?.toString(),
      },
      EnergyType: {
        value: formData.get("EnergyType")?.toString(),
      },
      VehicleType: {
        value: formData.get("VehicleType")?.toString(),
      },
      Description: {
        value: formData.get("Description")?.toString(),
      },
    });
  };

  const handleChangeDate = (e) => {
    const vehicleForm = document.querySelector("form");
    const formData = new FormData(vehicleForm);

    setVehicleModel({
      ...vehicleModel,
      Name: {
        value: formData.get("Name")?.toString(),
        error: "",
      },
      VIN: {
        value: formData.get("VIN")?.toString(),
      },
      EngineNumber: {
        value: formData.get("EngineNumber")?.toString(),
      },
      RegistrationNumber: {
        value: formData.get("RegistrationNumber")?.toString(),
      },
      GearNumber: {
        value: formData.get("GearNumber")?.toString(),
      },
      GearBoxType: {
        value: formData.get("GearBoxType")?.toString(),
      },
      CommissionStartingDate: {
        value: e?.target?.value?.toString(),
      },
      CommissionEndDate: {
        value: formData.get("CommissionEndDate")?.toString(),
      },
      ModelYear: {
        value: formData.get("ModelYear")?.toString(),
      },
      CO2Emissions: {
        value: formData.get("CO2Emissions")?.toString(),
      },
      ModelId: {
        value: formData.get("ModelId")?.toString(),
      },
      BrandId: {
        value: formData.get("BrandId")?.toString(),
      },
      Status: {
        value: formData.get("Status")?.toString(),
      },
      EnergyType: {
        value: formData.get("EnergyType")?.toString(),
      },
      VehicleType: {
        value: formData.get("VehicleType")?.toString(),
      },
      Description: {
        value: formData.get("Description")?.toString(),
      },
    });
  };

  const allBrands = (): { [key: string]: Object }[] => {
    let newBrand: { [key: string]: Object }[] = [];
    getVehicleData.value.brands.map((item, index) =>
      newBrand.push({
        value: item.id,
        brand: item.title,
        iconBranch: "",
        index: index,
      })
    );
    return newBrand;
  };
  const allModels = (): { [key: string]: Object }[] => {
    let newBrand: { [key: string]: Object }[] = [];
    models?.map((item) =>
      newBrand.push({
        value: item.id,
        model: item.title,
        iconBranch: "",
      })
    );
    return newBrand;
  };

  const allVehicleTypes = (): { [key: string]: Object }[] => {
    let newVehicleTypes: { [key: string]: Object }[] = [];
    getVehicleData.value.vehicleTypes.map((item) =>
      newVehicleTypes.push({
        value: item.id,
        idvehicletype: item.displayName,
        icontype: "",
      })
    );
    return newVehicleTypes;
  };

  const allGearBoxes = (): { [key: string]: Object }[] => {
    let newGearBoxes: { [key: string]: Object }[] = [];
    getVehicleData.value.gearBoxes.map((item) =>
      newGearBoxes.push({
        value: item.id,
        idgearboxe: item.displayName,
        icontype: "",
      })
    );
    return newGearBoxes;
  };

  const allEnergyTypes = (): { [key: string]: Object }[] => {
    let newEnergyTypes: { [key: string]: Object }[] = [];
    getVehicleData.value.energyTypes.map((item) =>
      newEnergyTypes.push({
        value: item.id,
        idvehicletype: item.displayName,
        icontype: "",
      })
    );
    return newEnergyTypes;
  };

  const allAvailabilityStatus = (): { [key: string]: Object }[] => {
    let newAvailabilityStatus: { [key: string]: Object }[] = [];
    getVehicleData.value.availabilityStatus.map((item) =>
      newAvailabilityStatus.push({
        value: item.id,
        idgearboxe: item.displayName,
        icontype: "",
      })
    );
    return newAvailabilityStatus;
  };

  const brand: { [key: string]: Object }[] = allBrands();
  const brandFields: ItemFields = {
    text: "brand",
    value: "value",
    iconCss: "iconBranch",
    index: "index",
  };

  const model: { [key: string]: Object }[] = allModels();
  const modelFields: ItemFields = {
    text: "model",
    value: "value",
    iconCss: "iconBranch",
  };

  const vehicleType: { [key: string]: Object }[] = allVehicleTypes();
  const vehicleTypeFields: ItemFields = {
    text: "idvehicletype",
    value: "value",
    iconCss: "icontype",
  };

  const gearBoxe: { [key: string]: Object }[] = allGearBoxes();
  const gearBoxeFields: ItemFields = {
    text: "idgearboxe",
    value: "value",
    iconCss: "icontype",
  };
  const energyType: { [key: string]: Object }[] = allEnergyTypes();
  const energyTypeFields: ItemFields = {
    text: "idvehicletype",
    value: "value",
    iconCss: "icontype",
  };

  const availabilityStatus: { [key: string]: Object }[] =
    allAvailabilityStatus();
  const availabilityStatusFields: ItemFields = {
    text: "idgearboxe",
    value: "value",
    iconCss: "icontype",
  };

  const animateSidebar: TabAnimationSettingsModel = {
    previous: { effect: "None", duration: 600, easing: "ease" },
    next: { effect: "None", duration: 600, easing: "ease" },
  };

  let headertext: any = [
    { text: "Général", iconCss: "icon" },
    { text: "Détails techniques", iconCss: "icon" },
    { text: "Images", iconCss: "icon" },
    { text: "Documents", iconCss: "icon" },
  ];

  const GeneralTab = () => {
    return getVehicleData.pending ? (
      <div className="flex flex-col w-full h-full gap-0 mx-auto">
        <div className="username w-full mx-auto">
          <ShimmerText />
        </div>
        <div className="username w-full mx-auto">
          <ShimmerText />
        </div>
        <div className="username w-full mx-auto">
          <ShimmerText />
        </div>
      </div>
    ) : (
      <div className="flex flex-col justify-between items-center gap-4 w-full my-4 px-4 form">
        <div className="flex flex-row gap-3 items-start justify-between names w-full">
          <div className="flex flex-col gap-3 name w-full">
            <label htmlFor="nameVehicle" className="text-base">
              Nom du véhicule
            </label>
            <InputWithIcon
              type={"text"}
              name={"Name"}
              id={"nameVehicle"}
              placeholder={"Nom du véhicule"}
              icon=""
              defaultValue={vehicleModel?.Name?.value?.toString()}
              className={`w-full `}
            />
            {vehicleModel?.Name?.error && (
              <div className="error">{vehicleModel?.Name?.error}</div>
            )}
          </div>

          <div className="flex flex-col gap-3 registrationNumber w-full">
            <label htmlFor="registrationNumberVehicle" className="text-base">
              Numéro d'immatriculation
            </label>
            <InputWithIcon
              type={"text"}
              name={"RegistrationNumber"}
              id={"registrationNumberVehicle"}
              placeholder={"Numéro d'immatriculation"}
              icon=""
              defaultValue={vehicleModel?.RegistrationNumber?.value?.toString()}
              className={`w-full `}
            />
            {vehicleModel?.RegistrationNumber?.error && (
              <div className="error">
                {vehicleModel?.RegistrationNumber?.error}
              </div>
            )}
          </div>
        </div>
        <div className="flex flex-row gap-3 items-start justify-between names w-full">
          <div className="flex flex-col gap-3 vin w-full">
            <label htmlFor="vinVehicle" className="text-base">
              Numéro du châssis
            </label>
            <InputWithIcon
              type={"text"}
              name={"VIN"}
              id={"vinVehicle"}
              placeholder={"Numéro du châssis"}
              icon=""
              defaultValue={vehicleModel?.VIN?.value?.toString()}
              className={`w-full `}
            />
            {vehicleModel?.VIN?.error && (
              <div className="error">{vehicleModel?.VIN?.error}</div>
            )}
          </div>

          <div className="flex flex-col gap-3 gearNumber w-full">
            <label htmlFor="gearNumberVehicle" className="text-base">
              Numéro de la boite de vitesse
            </label>
            <InputWithIcon
              type={"text"}
              name={"GearNumber"}
              id={"gearNumberVehicle"}
              placeholder={"Numéro de la boite de vitesse"}
              icon=""
              defaultValue={vehicleModel?.GearNumber?.value?.toString()}
              className={`w-full `}
            />
            {vehicleModel?.GearNumber?.error && (
              <div className="error">{vehicleModel?.GearNumber?.error}</div>
            )}
          </div>
        </div>

        <div className="flex flex-col gap-3 vehicleType w-full">
          <label htmlFor="vehicleType">Type de véhicule</label>
          <DropDownListComponent
            cssClass="w-full border px-2 py-1 input-notify bg-white disabled"
            id="vehicleType"
            dataSource={vehicleType}
            fields={vehicleTypeFields}
            value={parseInt(vehicleModel?.VehicleType?.value?.toString())}
            name="VehicleType"
            placeholder={"Choisissez votre type de véhicule"}
            popupHeight="220px"
            onChange={handleChangeCombo}
          />
          {vehicleModel?.VehicleType?.error && (
            <div className="error">{vehicleModel?.VehicleType?.error}</div>
          )}
        </div>

        <div className="flex flex-col gap-3 brandVehicle w-full">
          <label htmlFor="brandVehicle">Marque du véhicule</label>
          <DropDownListComponent
            cssClass="w-full border px-2 py-1 input-notify bg-white disabled"
            id="brandVehicle"
            dataSource={brand}
            fields={brandFields}
            value={vehicleModel?.BrandId?.value?.toString()}
            name="BrandId"
            placeholder={"Choisissez la marque de votre véhicule"}
            popupHeight="220px"
            onChange={getModels}
          />
          {vehicleModel?.BrandId?.error && (
            <div className="error">{vehicleModel?.BrandId?.error}</div>
          )}
        </div>

        <div className="flex flex-row gap-3 items-start justify-between names w-full">
          <div className="flex flex-col gap-3 modelIdVehicle w-full">
            <label htmlFor="modelIdVehicle">Modèle du véhicule</label>
            <DropDownListComponent
              cssClass="w-full border px-2 py-1 input-notify bg-white disabled"
              id="modelIdVehicle"
              dataSource={model}
              fields={modelFields}
              value={vehicleModel?.ModelId?.value?.toString()}
              name="ModelId"
              placeholder={"Choisissez le modèle de votre véhicule"}
              popupHeight="220px"
              onChange={handleChangeCombo}
            />
            {vehicleModel?.ModelId?.error && (
              <div className="error">{vehicleModel?.ModelId?.error}</div>
            )}
          </div>

          <div className="flex flex-col gap-3 modelYear w-full">
            <label htmlFor="modelYearVehicle" className="text-base">
              Année de modèle
            </label>
            <InputWithIcon
              type={"number"}
              name={"ModelYear"}
              id={"modelYearVehicle"}
              placeholder={"Année de modèle"}
              icon=""
              defaultValue={vehicleModel?.ModelYear?.value?.toString()}
              className={`w-full `}
            />
            {vehicleModel?.ModelYear?.error && (
              <div className="error">{vehicleModel?.ModelYear?.error}</div>
            )}
          </div>
        </div>

        <div className="flex flex-col gap-3 statusVehicle w-full">
          <label htmlFor="statusVehicle">Etat du véhicule</label>
          <DropDownListComponent
            cssClass="w-full border px-2 py-1 input-notify bg-white disabled"
            id="statusVehicle"
            dataSource={availabilityStatus}
            fields={availabilityStatusFields}
            value={parseInt(vehicleModel?.Status?.value?.toString())}
            name="Status"
            placeholder={"Choisissez l'état de votre véhicule"}
            popupHeight="220px"
            onChange={handleChangeCombo}
          />
          {vehicleModel?.Status?.error && (
            <div className="error">{vehicleModel?.Status?.error}</div>
          )}
        </div>

        <div className="flex flex-col gap-3 description w-full">
          <label htmlFor="descriptionVehicle" className="text-base">
            Description du véhicule
          </label>
          <TextArea
            name="Description"
            id="descriptionVehicle"
            defaultValue={vehicleModel?.Description?.value?.toString()}
            placeholder={"Description du véhicule"}
            cols={30}
            rows={5}
            className="w-full border px-2 py-1 input-sidebar bg-white"
          ></TextArea>
        </div>
      </div>
    );
  };

  const TechnicalTab = () => {
    return getVehicleData.pending ? (
      <div className="flex flex-col w-full h-full gap-0 mx-auto">
        <div className="username w-full mx-auto">
          <ShimmerText />
        </div>
        <div className="username w-full mx-auto">
          <ShimmerText />
        </div>
        <div className="username w-full mx-auto">
          <ShimmerText />
        </div>
      </div>
    ) : (
      <div className="flex flex-col justify-between items-center gap-4 w-full my-4 px-4 form">
        <div className="flex flex-col gap-3 engineNumber w-full">
          <label htmlFor="engineNumberVehicle" className="text-base">
            Numéro du moteur
          </label>
          <InputWithIcon
            type={"text"}
            name={"EngineNumber"}
            id={"engineNumberVehicle"}
            placeholder={"Numéro du moteur"}
            icon=""
            defaultValue={vehicleModel?.EngineNumber?.value?.toString()}
            className={`w-full`}
          />
          {vehicleModel?.EngineNumber?.error && (
            <div className="error">{vehicleModel?.EngineNumber?.error}</div>
          )}
        </div>

        <div className="flex flex-col gap-3 gearBoxType w-full">
          <label htmlFor="gearBoxType">Boite de vitesse</label>
          <DropDownListComponent
            cssClass="w-full border px-2 py-1 input-notify bg-white disabled"
            id="gearBoxType"
            dataSource={gearBoxe}
            fields={gearBoxeFields}
            value={parseInt(vehicleModel?.GearBoxType?.value?.toString())}
            name="GearBoxType"
            placeholder={"Choisissez votre boite de vitesse"}
            popupHeight="220px"
            onChange={handleChangeCombo}
          />
          {vehicleModel?.GearBoxType?.error && (
            <div className="error">{vehicleModel?.GearBoxType?.error}</div>
          )}
        </div>

        <div className="flex flex-row gap-3 items-start justify-between names w-full">
          <div className="flex flex-col gap-3 commissionStartingDate w-full">
            <label
              htmlFor="commissionStartingDateVehicle"
              className="text-base"
            >
              Date de début de commission
            </label>
            <DatePickerComponent
              name={"CommissionStartingDate"}
              id={"commissionStartingDateVehicle"}
              placeholder={"Date de début de commission"}
              value={
                new Date(
                  vehicleModel?.CommissionStartingDate?.value?.toString()
                )
              }
              className={`w-full px-2 py-1 input-notify-date bg-white disabled`}
              onChange={handleChangeDate}
            ></DatePickerComponent>
            {vehicleModel?.CommissionStartingDate?.error && (
              <div className="error">
                {vehicleModel?.CommissionStartingDate?.error}
              </div>
            )}
          </div>

          <div className="flex flex-col gap-3 commissionEndDate w-full">
            <label htmlFor="commissionEndDateVehicle" className="text-base">
              Date de fin de commission
            </label>

            <DatePickerComponent
              name={"CommissionEndDate"}
              id={"commissionEndDateVehicle"}
              placeholder={"Date de fin de commission"}
              value={
                new Date(vehicleModel?.CommissionEndDate?.value?.toString())
              }
              className={`w-full px-2 py-1 input-notify-date bg-white disabled`}
              onChange={handleChangeDate}
            ></DatePickerComponent>
            {vehicleModel?.CommissionEndDate?.error && (
              <div className="error">
                {vehicleModel?.CommissionEndDate?.error}
              </div>
            )}
          </div>
        </div>

        <div className="flex flex-col gap-3 cO2Emissions w-full">
          <label htmlFor="cO2EmissionsVehicle" className="text-base">
            Emission de CO2
          </label>
          <InputWithIcon
            type={"number"}
            name={"CO2Emissions"}
            id={"cO2EmissionsVehicle"}
            placeholder={"Emission de CO2"}
            icon=""
            defaultValue={vehicleModel?.CO2Emissions?.value?.toString()}
            className={`w-full `}
          />
          {vehicleModel?.CO2Emissions?.error && (
            <div className="error">{vehicleModel?.CO2Emissions?.error}</div>
          )}
        </div>

        <div className="flex flex-col gap-3 energyType w-full">
          <label htmlFor="energyType">Type de carburant utilisé</label>
          <DropDownListComponent
            cssClass="w-full border px-2 py-1 input-notify bg-white disabled"
            id="energyType"
            dataSource={energyType}
            fields={energyTypeFields}
            value={parseInt(vehicleModel?.EnergyType?.value?.toString())}
            name="EnergyType"
            placeholder={"Choisissez votre type de carburant"}
            popupHeight="220px"
            onChange={handleChangeCombo}
          />
          {vehicleModel?.EnergyType?.error && (
            <div className="error">{vehicleModel?.EnergyType?.error}</div>
          )}
        </div>
      </div>
    );
  };

  return (
    <SidebarComponent
      ref={data?.func?.sidebarInstance}
      closeOnDocumentClick={false}
      showBackdrop={data?.func?.isShowBackdrop}
      width="700px"
      target=".apimaincontent"
      id="apiSidebar"
      className="tenant-sidebar"
      type={"Over"}
      enableGestures={false}
      position={"Right"}
      open={() => initialData()}
    >
      <div className="flex flex-col justify-start items-center h-full py-7 relative sidebar-grid">
        <div className="flex flex-row justify-between w-full px-9 mt- mb-2">
          <h2 className="text-3xl title">
            {data?.isEditing
              ? "Modification d'un véhicule"
              : "Ajouter un véhicule"}
          </h2>
          <span
            className="icon cursor-pointer cancelicon- text-2xl"
            onClick={data?.func?.sidebarClose?.bind(this)}
          ></span>
        </div>

        {getVehicleData.errors &&
          showServerErrorMessage &&
          getVehicleData.errors.length > 0 &&
          !getVehicleData.pending &&
          getVehicleData.errors.map((message, key) => {
            return (
              <div className="w-full px-2" id="msg_server" key={key}>
                <MessageComponent
                  showCloseIcon
                  id="msg_error"
                  className="errorServer p-1"
                  content={message}
                  key={key}
                  severity="Error"
                ></MessageComponent>
              </div>
            );
          })}

        {updateVehicleData.errors &&
          showServerErrorMessage &&
          updateVehicleData.errors.length > 0 &&
          !updateVehicleData.pending &&
          updateVehicleData.errors.map((message, key) => {
            return (
              <div className="w-full px-2" id="msg_server" key={key}>
                <MessageComponent
                  showCloseIcon
                  id="msg_error"
                  className="errorServer p-1"
                  content={message}
                  key={key}
                  severity="Error"
                ></MessageComponent>
              </div>
            );
          })}
        {updateVehicleData.value &&
        showServerSuccessMessage &&
        !updateVehicleData.pending ? (
          <div className="absolut mt-[25vh] h-[30vh] w-3/4 mx-auto">
            <OperationResultComponent
              message={
                data?.isEditing
                  ? "Vous avez modifié avec success ce véhicule"
                  : "Vous avez ajouté un nouveau véhicule"
              }
              title={
                data?.isEditing
                  ? "Modification de véhicule"
                  : "Ajout de véhicule"
              }
              titleButton={"Fermez cette page et consultez la liste"}
            />
          </div>
        ) : (
          <form
            className="flex flex-col justify-start items-center content py-4 px-8 w-full h-full"
            onSubmit={handleSubmit}
            encType="multipart/form-data"
          >
            <TabComponent
              id="tenantSidebarTab"
              cssClass="border-0 border-transparent h-full"
              animation={animateSidebar}
              ref={vehicleTabInstance}
            >
              <TabItemsDirective>
                <TabItemDirective
                  header={headertext[0]}
                  content={() => GeneralTab()}
                />
                <TabItemDirective
                  header={headertext[1]}
                  content={() => TechnicalTab()}
                />
                <TabItemDirective
                  header={headertext[2]}
                  content={() =>
                    VehicleDocuments({
                      label: "Images du véhicule",
                      id: "imageUrlsVehicle",
                      name: "Images",
                      accept: "image/*",
                      data: images,
                      updateImages: handleChangeImage,
                      className: "",
                    })
                  }
                />
                <TabItemDirective
                  header={headertext[3]}
                  content={() =>
                    VehicleDocuments({
                      label: "Papiers du véhicule",
                      id: "documentUrlsVehicle",
                      name: "Documents",
                      accept: "image/*,.pdf,.doc,.docx,.txt,.xlxs,.csv",
                      data: documents,
                      updateImages: handleChangeDocument,
                      className: "",
                    })
                  }
                />
              </TabItemsDirective>
            </TabComponent>

            <div className="flex flex-row gap-4 justify-end footer px-4 py-4 ms-auto mt-auto">
              <Button
                param={{
                  type: "button",
                  name: "Annuler",
                  handleClick: data?.func?.sidebarClose?.bind(this),
                  css:
                    (updateVehicleData?.pending ? "disabled" : "") +
                    " cancelBtn w-full",
                  disabled: updateVehicleData.pending,
                }}
              />
              <Button
                param={{
                  type: "submit",
                  name: "Valider",
                  handleClick: handleSubmit,
                  css:
                    (updateVehicleData?.pending ? "disabled" : "") +
                    " okBtn w-full",
                  disabled: updateVehicleData.pending,
                }}
              />
            </div>
          </form>
        )}
      </div>
    </SidebarComponent>
  );
}
