import { Dispatch, SetStateAction } from "react";
import RangeSettingsLine from "../range-settings-line";
import SwitchSettingsLine from "../switch-settings-line";
import CardSettings from "../card-settings";
import { useAppSelector } from "src/app/core/hooks/core-hooks";
import { ShimmerText } from "src/app/components/shared/shimmer";
import { useLocalizer } from "src/app/core/Localization";

type Props = {
  viewModel?: {
    isEnablePasswordPolicy: boolean;
    durationPasswordPolicy: number;
    minimumLength: number;
    alertUserToChangeFrom: number;
    enforcePasswordHistory: boolean;
    passwordComplexityIsEnable: boolean;
    mustContainsAtLeastOneUppercase: boolean;
    mustContainsAtLeastOneLowercase: boolean;
    mustContainsAtLeastOneSpecialChar: boolean;
    mustContainsAtLeastOneDigit: boolean;
  };
  setViewModel?: Dispatch<
    SetStateAction<{
      isEnablePasswordPolicy: boolean;
      durationPasswordPolicy: number;
      minimumLength: number;
      alertUserToChangeFrom: number;
      enforcePasswordHistory: boolean;
      passwordComplexityIsEnable: boolean;
      mustContainsAtLeastOneUppercase: boolean;
      mustContainsAtLeastOneLowercase: boolean;
      mustContainsAtLeastOneSpecialChar: boolean;
      mustContainsAtLeastOneDigit: boolean;
    }>
  >;
  errorsAppSettings?;
};

const PasswordPolicySettings = ({
  errorsAppSettings = null,
  setViewModel,
  viewModel,
}: Props) => {
  const commonLocalizer = useLocalizer("Common-ResCommon");

  const getAppSettingsData = useAppSelector((state) => state.getAppSettings);

  const handleChangeSwitch = (e, text: string) => {
    const value = e.checked;
    setViewModel({
      ...viewModel,
      [text]: value,
    });
  };

  const handleChangeRange = (e, text: string): void => {
    // With number input option
    const { name, value } = e.target;
    setViewModel({
      ...viewModel,
      [name]: value,
    });
  };

  return (
    <>
      {getAppSettingsData.pending ? (<div className="p-0 m-0 w-full mx-auto"><ShimmerText /><ShimmerText /><ShimmerText /></div>) : (
        <CardSettings title={commonLocalizer("MODULE_COMMON_WEB_SETTINGS_PASSWORD_POLICY_TITLE")}>
          <div className="flex flex-row justify-between gap-10 w-full">
            <div className="flex flex-col gap-5 items-start justify-start w-full">
              <SwitchSettingsLine
                change={(e) => handleChangeSwitch(e, "isEnablePasswordPolicy")}
                title={commonLocalizer(
                  "MODULE_COMMON_WEB_SETTINGS_PASSWORD_POLICY_ENABLE"
                )}
                name="isEnablePasswordPolicy"
                description={commonLocalizer(
                  "MODULE_COMMON_WEB_SETTINGS_PASSWORD_POLICY_ENABLE_HELP"
                )}
                checked={viewModel.isEnablePasswordPolicy}
              />

              <SwitchSettingsLine
                disabled={!viewModel.isEnablePasswordPolicy}
                change={(e) => handleChangeSwitch(e, "enforcePasswordHistory")}
                title={commonLocalizer(
                  "MODULE_COMMON_WEB_SETTINGS_PASSWORD_POLICY_ENABLE_HISTORY"
                )}
                name="enforcePasswordHistory"
                description={commonLocalizer(
                  "MODULE_COMMON_WEB_SETTINGS_PASSWORD_POLICY_ENABLE_HISTORY_HELP"
                )}
                checked={viewModel.enforcePasswordHistory}
              />

              <SwitchSettingsLine
                disabled={!viewModel.isEnablePasswordPolicy}
                change={(e) =>
                  handleChangeSwitch(e, "passwordComplexityIsEnable")
                }
                title={commonLocalizer(
                  "MODULE_COMMON_WEB_SETTINGS_PASSWORD_POLICY_ENABLE_COMPLEXITY"
                )}
                name="passwordComplexityIsEnable"
                description={commonLocalizer(
                  "MODULE_COMMON_WEB_SETTINGS_PASSWORD_POLICY_ENABLE_COMPLEXITY_HELP"
                )}
                checked={viewModel.passwordComplexityIsEnable}
              />

              <SwitchSettingsLine
                disabled={!viewModel.isEnablePasswordPolicy}
                change={(e) =>
                  handleChangeSwitch(e, "mustContainsAtLeastOneUppercase")
                }
                title={commonLocalizer(
                  "MODULE_COMMON_WEB_SETTINGS_PASSWORD_POLICY_MUST_CONTAINS_UPPER"
                )}
                name="mustContainsAtLeastOneUppercase"
                description={commonLocalizer(
                  "MODULE_COMMON_WEB_SETTINGS_PASSWORD_POLICY_MUST_CONTAINS_UPPER_HELP"
                )}
                checked={viewModel.mustContainsAtLeastOneUppercase}
              />

              <SwitchSettingsLine
                disabled={!viewModel.isEnablePasswordPolicy}
                change={(e) =>
                  handleChangeSwitch(e, "mustContainsAtLeastOneLowercase")
                }
                title={commonLocalizer(
                  "MODULE_COMMON_WEB_SETTINGS_PASSWORD_POLICY_MUST_CONTAINS_LOWER"
                )}
                name="mustContainsAtLeastOneLowercase"
                description={commonLocalizer(
                  "MODULE_COMMON_WEB_SETTINGS_PASSWORD_POLICY_MUST_CONTAINS_LOWER_HELP"
                )}
                checked={viewModel.mustContainsAtLeastOneLowercase}
              />
            </div>

            <div className="flex flex-col gap-5 items-start justify-start w-full">
              <SwitchSettingsLine
                disabled={!viewModel.isEnablePasswordPolicy}
                change={(e) =>
                  handleChangeSwitch(e, "mustContainsAtLeastOneSpecialChar")
                }
                title={commonLocalizer(
                  "MODULE_COMMON_WEB_SETTINGS_PASSWORD_POLICY_MUST_CONTAINS_SPECIAL_CHAR"
                )}
                name="mustContainsAtLeastOneSpecialChar"
                description={commonLocalizer(
                  "MODULE_COMMON_WEB_SETTINGS_PASSWORD_POLICY_MUST_CONTAINS_SPECIAL_CHAR_HELP"
                )}
                checked={viewModel.mustContainsAtLeastOneSpecialChar}
              />

              <SwitchSettingsLine
                disabled={!viewModel.isEnablePasswordPolicy}
                change={(e) =>
                  handleChangeSwitch(e, "mustContainsAtLeastOneDigit")
                }
                title={commonLocalizer(
                  "MODULE_COMMON_WEB_SETTINGS_PASSWORD_POLICY_MUST_CONTAINS_DIGIT"
                )}
                name="mustContainsAtLeastOneDigit"
                description={commonLocalizer(
                  "MODULE_COMMON_WEB_SETTINGS_PASSWORD_POLICY_MUST_CONTAINS_DIGIT_HELP"
                )}
                checked={viewModel.mustContainsAtLeastOneDigit}
              />

              <RangeSettingsLine
                disabled={!viewModel.isEnablePasswordPolicy}
                value={viewModel.durationPasswordPolicy}
                min={1}
                max={9}
                change={(e) => handleChangeRange(e, "durationPasswordPolicy")}
                css="mt-4"
                title={commonLocalizer(
                  "MODULE_COMMON_WEB_SETTINGS_PASSWORD_POLICY_PASSWORD_EXPIRES"
                )}
                name="durationPasswordPolicy"
              />

              <RangeSettingsLine
                disabled={!viewModel.isEnablePasswordPolicy}
                value={viewModel.minimumLength}
                min={4}
                max={16}
                change={(e) => handleChangeRange(e, "minimumLength")}
                title={commonLocalizer(
                  "MODULE_COMMON_WEB_SETTINGS_PASSWORD_POLICY_MINIMUM_LENGTH"
                )}
                name="minimumLength"
              />

              <RangeSettingsLine
                disabled={!viewModel.isEnablePasswordPolicy}
                value={viewModel.alertUserToChangeFrom}
                min={1}
                max={31}
                change={(e) => handleChangeRange(e, "alertUserToChangeFrom")}
                title={
                  commonLocalizer(
                    "MODULE_COMMON_WEB_SETTINGS_PASSWORD_POLICY_PASSWORD_EXPIRES_ALERT_FROM"
                  ).slice(0, 31) + " ..."
                }
                description={commonLocalizer(
                  "MODULE_COMMON_WEB_SETTINGS_PASSWORD_POLICY_PASSWORD_EXPIRES_ALERT_FROM"
                )}
                name="alertUserToChangeFrom"
              />
            </div>
          </div>
        </CardSettings>
      )}
    </>
  );
};

export default PasswordPolicySettings;
