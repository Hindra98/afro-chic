import { AddAgencyAction, AddAgencyStoreShape, AgencyAction, DeleteAgencyAction, DeleteAgencyStoreShape, GetAgenciesAction, getAgenciesInitialState, GetAgenciesStoreShape, getAgencyInitialState, GetAgencyStoreShape, initialStateAddAgency, initialStateDeleteAgency, initialStateUpdateAgency, UpdateAgencyAction, UpdateAgencyStoreShape } from '../actions/agencies';
import { ActionTypes } from '../actions/constants/action-types';
import { produce } from "immer";


export const addAgencyReducer = (state: AddAgencyStoreShape = initialStateAddAgency, args: AddAgencyAction): AddAgencyStoreShape => {

  switch (args.type) {

    case ActionTypes.ADD_AGENCY_REQUEST:
      return produce(state, (draftState) => {
        draftState.value = false;
        draftState.pending = true;
        draftState.Errors = [];
      });

      case ActionTypes.ADD_AGENCY_FAILURE:
        return produce(state, (draftState) => {
          draftState.Errors = args.payload?.errors.errors;
          draftState.value = false;
          draftState.pending = false;
        });

        case ActionTypes.ADD_AGENCY_SUCCESS:
          return produce(state, (draftState) => {
            draftState.Errors = [];
            draftState.value = true;
            draftState.pending = false;
          });

    default:
      return state;
  }
};


export const updateAgencyReducer = (state: UpdateAgencyStoreShape = initialStateUpdateAgency, args: UpdateAgencyAction): UpdateAgencyStoreShape => {

  switch (args.type) {

    case ActionTypes.UPDATE_AGENCY_REQUEST:
      return produce(state, (draftState) => {
        draftState.value = false;
        draftState.pending = true;
        draftState.Errors = [];
      });

      case ActionTypes.UPDATE_AGENCY_FAILURE:
        return produce(state, (draftState) => {
          draftState.Errors = args.payload?.errors.errors;
          draftState.value = false;
          draftState.pending = false;
        });

        case ActionTypes.UPDATE_AGENCY_SUCCESS:
          return produce(state, (draftState) => {
            draftState.Errors = [];
            draftState.value = true;
            draftState.pending = false;
          });

    default:
      return state;
  }
};

export const deleteAgencyReducer = (state: DeleteAgencyStoreShape = initialStateDeleteAgency, args: DeleteAgencyAction): DeleteAgencyStoreShape => {

  switch (args.type) {

    case ActionTypes.DELETE_AGENCIES_REQUEST:
      return produce(state, (draftState) => {
        draftState.value = false;
        draftState.pending = true;
        draftState.Errors = [];
      });

      case ActionTypes.DELETE_AGENCIES_FAILURE:
        return produce(state, (draftState) => {
          draftState.Errors = args.payload?.errors.errors;
          draftState.value = false;
          draftState.pending = false;
        });

        case ActionTypes.DELETE_AGENCIES_SUCCESS:
          return produce(state, (draftState) => {
            draftState.Errors = [];
            draftState.value = true;
            draftState.pending = false;
          });

    default:
      return state;
  }
};

export const getAgenciesReducer = (state: GetAgenciesStoreShape = getAgenciesInitialState, args: GetAgenciesAction): GetAgenciesStoreShape => {

  switch (args.type) {

    case ActionTypes.GET_AGENCIES_REQUEST:
      return produce(state, (draftState) => {
        draftState.pending = true;
        draftState.Errors = [];
      });

    case ActionTypes.GET_AGENCIES_FAILURE:
      return produce(state, (draftState) => {
        draftState.Errors = args.payload?.errors?.errors;
        draftState.pending = false;
      });

    case ActionTypes.GET_AGENCIES_SUCCESS:
      return produce(state, (draftState) => {
        draftState.Errors = [];
        draftState.value.branches = args?.payload?.user?.branches

        draftState.pending = false;
      });

    default:
      return state;
  }
};

export const getAgencyReducer = (state: GetAgencyStoreShape = getAgencyInitialState, args: AgencyAction): GetAgencyStoreShape => {

  switch (args.type) {

    case ActionTypes.GET_AGENCY_REQUEST:
      return produce(state, (draftState) => {
        draftState.pending = true;
        draftState.Errors = [];
      });

    case ActionTypes.GET_AGENCY_FAILURE:
      return produce(state, (draftState) => {
        draftState.Errors = args.payload?.errors?.errors;
        draftState.pending = false;
      });

    case ActionTypes.GET_AGENCY_SUCCESS:
      return produce(state, (draftState) => {
        draftState.Errors = [];
        draftState.value.branch.id = args?.payload?.user?.branch.id
        draftState.value.branch.description = args?.payload?.user?.branch.description
        draftState.value.branch.name = args?.payload?.user?.branch.name
        draftState.value.branch.isHeadQuarter = args?.payload?.user?.branch.isHeadQuarter
        draftState.value.branch.isDeletable = args?.payload?.user?.branch.isDeletable

        draftState.value.branch.latitude = args?.payload?.user?.branch.latitude
        draftState.value.branch.longitude = args?.payload?.user?.branch.longitude
        draftState.value.branch.radius = args?.payload?.user?.branch.radius
        draftState.value.branch.order = args?.payload?.user?.branch.order

        draftState.value.branch.settings.regionalFormat = args?.payload?.user?.branch.settings.regionalFormat
        draftState.value.branch.settings.language = args?.payload?.user?.branch?.settings?.language
        draftState.value.branch.settings.timeZone = args?.payload?.user?.branch?.settings?.timeZone
        draftState.value.branch.settings.currencyPosition = args?.payload?.user?.branch?.settings?.currencyPosition
        
        draftState.value.languages = args?.payload?.user?.languages
        draftState.value.regionalFormats = args?.payload?.user?.regionalFormats
        draftState.value.timeZones = args?.payload?.user?.timeZones

        draftState.pending = false;
      });

    default:
      return state;
  }
};