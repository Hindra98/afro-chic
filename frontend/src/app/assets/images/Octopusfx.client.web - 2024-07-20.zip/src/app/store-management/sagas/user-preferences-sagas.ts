import { call, put, takeLatest } from "redux-saga/effects";
import { ActionTypes } from "../actions/constants/action-types";
import { updateUserPreferencesFailure, getUserPreferencesFailure, getUserPreferencesSuccess, updateUserPreferencesSuccess } from "../actions/user-preferences/user-preferences-actions";
import { UpdateUserPreferencesAction, UpdateUserPreferencesFailurePayload, GetUserPreferencesAction, GetUserPreferencesFailurePayload, UpdateUserPreferencesSuccessPayload } from "../actions/user-preferences";
import { ControllerApi } from "src/app/features/common/identity/user-preferences/locale/controller-api";
import { setStorage } from "src/app/core/storage/storage";
import { AuthenticationConstants } from "src/app/core/constants/authentication-contants";


const controllerApi = new ControllerApi();

const callApiToUpdateUserPreferences = async (command: UpdateUserPreferencesCommand) => controllerApi.updateUserPreferences(command);
const callApiToGetUserPreferences = async (command: string) => controllerApi.getUserPreferences(command);


function* updateUserPreferencesSaga(action: UpdateUserPreferencesAction) {
  try {
    const response = yield call(callApiToUpdateUserPreferences, action.payload.command);
    if (response) {
      if (response?.hasSucceeded) {
        const languageCode: string = action.payload.command.language.split('-')[0];
        setStorage(AuthenticationConstants.USER_LANGUAGE, languageCode)
        yield put(updateUserPreferencesSuccess({ value: true } as UpdateUserPreferencesSuccessPayload));
      } else {
        let messages: string[] = [];
        response.errorMessages.map((item) => {
          return messages.push(item.errorMessage);
        });
        yield put(updateUserPreferencesFailure({ errors: messages } as UpdateUserPreferencesFailurePayload));
      }
    } else {
      let messages: string[] = [];
      messages.push("Erreur lors de la connexion au serveur");
      yield put(updateUserPreferencesFailure({ errors: messages } as UpdateUserPreferencesFailurePayload));
    }
  } catch (e) {
    let messages: string[] = [];
    messages.push(e.message);
    yield put(updateUserPreferencesFailure({ errors: messages } as UpdateUserPreferencesFailurePayload));
  }
}


function* getUserPreferencesSaga(action: GetUserPreferencesAction) {
  try {
    const response = yield call(callApiToGetUserPreferences, action.payload.command);
    if (response) {
      yield put(getUserPreferencesSuccess(response as GetUserPreferences));
    } else {
      let messages: string[] = [];
      response?.errorMessages.map((item) => {
        return messages.push(item.errorMessage);
      });
      yield put(getUserPreferencesFailure({ errors: messages } as GetUserPreferencesFailurePayload, null));
    }

  } catch (e) {
    let messages: string[] = [];
    messages.push(e.message);
    yield put(getUserPreferencesFailure({ errors: messages } as GetUserPreferencesFailurePayload, e.response.data));
  }
}

export function* watchUserPreferencesSaga() {
  yield takeLatest(ActionTypes.UPDATE_USER_PREFERENCES_REQUEST, updateUserPreferencesSaga);
  yield takeLatest(ActionTypes.GET_USER_PREFERENCES_REQUEST, getUserPreferencesSaga);
}
