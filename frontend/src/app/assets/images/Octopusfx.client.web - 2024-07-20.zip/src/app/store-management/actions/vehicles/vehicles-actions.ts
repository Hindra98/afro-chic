import { DeleteVehicleAction, DeleteVehicleFailurePayload, DeleteVehicleSuccessPayload, GetVehicleAction, GetVehicleFailurePayload, GetVehiclesAction, GetVehiclesFailurePayload, UpdateVehicleAction, UpdateVehicleFailurePayload, UpdateVehicleSuccessPayload } from ".";
import { ActionTypes } from "../constants/action-types";



export const getVehicles = (): GetVehiclesAction => {
  return {
      type: ActionTypes.VEHICLES_REQUEST,
      payload : {
          command: null,
          value: null,
          errors: null
      }
  } as GetVehiclesAction
};
export const getVehiclesFailure = (payload: GetVehiclesFailurePayload): GetVehiclesAction => {
  return {
      type: ActionTypes.VEHICLES_FAILURE,
      payload : {
          command: null,
          value: null,
          errors: payload
      }
  } as GetVehiclesAction
};
export const getVehiclesSuccess = (payload: GetVehicles): GetVehiclesAction => {
  return {
      type: ActionTypes.VEHICLES_SUCCESS,
      payload : {
          command: null,
          value: payload,
          errors: null
      }
  } as GetVehiclesAction
};


export const getVehicle = (command: VehicleCommand): GetVehicleAction => {
  return {
      type: ActionTypes.VEHICLE_REQUEST,
      payload : {
          command: command,
          value: null,
          errors: null
      }
  } as GetVehicleAction
};
export const getVehicleFailure = (payload: GetVehicleFailurePayload): GetVehicleAction => {
  return {
      type: ActionTypes.VEHICLE_FAILURE,
      payload : {
          command: null,
          value: null,
          errors: payload
      }
  } as GetVehicleAction
};
export const getVehicleSuccess = (payload: GetVehicle): GetVehicleAction => {
  return {
      type: ActionTypes.VEHICLE_SUCCESS,
      payload : {
          command: null,
          value: payload,
          errors: null
      }
  } as GetVehicleAction
};


export const updateVehicle = (command: FormData): UpdateVehicleAction => {
  return {
      type: ActionTypes.UPDATE_VEHICLE_REQUEST,
      payload : {
          command: command,
          value: null,
          errors: null
      }
  } as UpdateVehicleAction
};
export const updateVehicleFailure = (payload: UpdateVehicleFailurePayload): UpdateVehicleAction => {
  return {
      type: ActionTypes.UPDATE_VEHICLE_FAILURE,
      payload : {
          command: null,
          value: null,
          errors: payload
      }
  } as UpdateVehicleAction
};
export const updateVehicleSuccess = (payload: UpdateVehicleSuccessPayload): UpdateVehicleAction => {
  return {
      type: ActionTypes.UPDATE_VEHICLE_SUCCESS,
      payload : {
          command: null,
          value: payload,
          errors: null
      }
  } as UpdateVehicleAction
};


export const deleteVehicle = (command: DeleteVehicleCommand): DeleteVehicleAction => {
  return {
      type: ActionTypes.DELETE_VEHICLE_REQUEST,
      payload : {
          command: command,
          value: null,
          errors: null
      }
  } as DeleteVehicleAction
};
export const deleteVehicleFailure = (payload: DeleteVehicleFailurePayload): DeleteVehicleAction => {
  return {
      type: ActionTypes.DELETE_VEHICLE_FAILURE,
      payload : {
          command: null,
          value: null,
          errors: payload
      }
  } as DeleteVehicleAction
};
export const deleteVehicleSuccess = (payload: DeleteVehicleSuccessPayload): DeleteVehicleAction => {
  return {
      type: ActionTypes.DELETE_VEHICLE_SUCCESS,
      payload : {
          command: null,
          value: payload,
          errors: null
      }
  } as DeleteVehicleAction
};
