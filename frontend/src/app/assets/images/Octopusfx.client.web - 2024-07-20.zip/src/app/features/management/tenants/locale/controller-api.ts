import { useDebounced } from "src/app/core/hooks";
import { HttpClient } from "../../../../http/http-client";

const addTenant = (http: HttpClient) => async (payload: object) => {
  const response = await http.post("/v1/tenants/save", payload);
  const result: AddTenant = response.data;
  
  return response !== undefined ? (result as AddTenant) : undefined;
};

const updateTenant = (http: HttpClient) => async (payload: object) => {
  const response = await http.post("/v1/tenants/save", payload);
  const result: UpdateTenant = response.data;
  
  return response !== undefined ? (result as UpdateTenant) : undefined;
};

const deleteTenant = (http: HttpClient) => async (payload: object) => {
  const response = await http.delete("/v1/tenants/delete", payload);
  const result: DeleteTenant = response.data;
  
  return response !== undefined ? (result as DeleteTenant) : undefined;
};

const getTenants = (http: HttpClient) => async () => {
  const response = await http.get("/v1/tenants/get-all");
  const result: GetTenants = response.data;

  return response !== undefined ? (result as GetTenants) : undefined;
};

const getTenant = (http: HttpClient) => async (payload: object) => {
  const response = await http.get("/v1/tenants/get", payload);
  const result: GetTenant = response.data;

  return response !== undefined ? (result as GetTenant) : undefined;
};

const exportTenantDataInPdfFile = (http: HttpClient) => async (payload: object) => {
  const response = await http.get("/v1/tenants/export-pdf", payload);
  const result = response.data;

  return response !== undefined ? result : undefined;
};

export class ControllerApi {
  private readonly http = new HttpClient();

  public readonly addTenant = Object.assign(addTenant(this.http), {
    useResponse: (
      handler: (result: AddTenant) => unknown,
      args: Parameters<ReturnType<typeof addTenant>>[0]
    ) => useDebounced(() => this.addTenant(args).then(handler), Object.values(args), 500),
  });

  public readonly updateTenant = Object.assign(updateTenant(this.http), {
    useResponse: (
      handler: (result: UpdateTenant) => unknown,
      args: Parameters<ReturnType<typeof updateTenant>>[0]
    ) => useDebounced(() => this.updateTenant(args).then(handler), Object.values(args), 500),
  });
  

  public readonly deleteTenant = Object.assign(deleteTenant(this.http), {
    useResponse: (
      handler: (result: DeleteTenant) => unknown,
      args: Parameters<ReturnType<typeof deleteTenant>>[0]
    ) => useDebounced(() => this.deleteTenant(args).then(handler), Object.values(args), 500),
  });
  
  public readonly getTenants = Object.assign(getTenants(this.http), {
    useResponse: (
      handler: (result: GetTenants) => unknown,
      args: Parameters<ReturnType<typeof getTenants>>[]
    ) => useDebounced(() => this.getTenants().then(handler), Object.values(args), 500),
  });
  
  public readonly getTenant = Object.assign(getTenant(this.http), {
    useResponse: (
      handler: (result: GetTenant) => unknown,
      args: Parameters<ReturnType<typeof getTenant>>[0]
    ) => useDebounced(() => this.getTenant(args).then(handler), Object.values(args), 500),
  });
  
  public readonly exportTenantDataInPdfFile = Object.assign(exportTenantDataInPdfFile(this.http), {
    useResponse: (
      handler: (result) => unknown,
      args: Parameters<ReturnType<typeof exportTenantDataInPdfFile>>[0]
    ) => useDebounced(() => this.exportTenantDataInPdfFile(args).then(handler), Object.values(args), 500),
  });

}