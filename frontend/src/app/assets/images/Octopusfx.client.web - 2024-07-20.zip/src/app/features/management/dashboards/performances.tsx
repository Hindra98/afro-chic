
type Props = {
  performances?: Perf[]
  title?: string
}
type Perf = {
  label?: string;
  value?: string;
  color?: string;
}

const Performances = (props: Props) => {
  return (
    <div className="flex flex-col gap-2">
      <h2 className="text-lg mb-2 font-bold">{props?.title}</h2>
      {props?.performances?.map((perf, key) => (
        <div className="flex flex-row items-start gap-1" key={key}>
          <p className=" bg-[#aaa] w-1 h-5"></p> <span>{perf?.label} :</span><span className={perf?.color ?? "text-slate-500"}> {perf?.value} </span>
        </div>
      ))}
    </div>
  )
}

export default Performances