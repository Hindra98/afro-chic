export interface UpdateAppSettingsStoreShape {
  pending: boolean;
  Errors: string[];
  value: boolean;
}
export let initialStateUpdateAppSettings: UpdateAppSettingsStoreShape =
{
  value: false,
  pending: false,
  Errors: [],
};

export interface UpdateAppSettingsModelShape {
  command: UpdateAppSettingsCommand;
}
export interface UpdateAppSettingsFailurePayload {
  errors: string[];
}
export interface UpdateAppSettingsSuccessPayload {
  value: boolean;
}
export interface UpdateAppSettingsRequest {
  type: string;
  payload: UpdateAppSettingsCommand;
}
export interface UpdateAppSettingsFailure {
  type: string;
  payload: UpdateAppSettingsFailurePayload;
}
export interface UpdateAppSettingsSuccess {
  type: string;
  payload: UpdateAppSettingsSuccessPayload;
}
export interface UpdateAppSettingsPayload {
  command: UpdateAppSettingsCommand;
  value: UpdateAppSettingsSuccessPayload;
  errors: UpdateAppSettingsFailurePayload;
}
export interface UpdateAppSettingsAction {
  type: string;
  payload: UpdateAppSettingsPayload;
}


export interface GetAppSettingsStoreShape {
  pending: boolean;
  Errors: string[];
  value: GetAppSettings;
}
export let getAppSettingsInitialState: GetAppSettingsStoreShape = {
  value: {
    key: "",
    isAdministrator: false,
    isSuperAdmin: false,

    userSettings: {
      acceptSMSNotifications: false,
      acceptEmailNotifications: false,
      twoFactorAuthentication: false,
      preferedNotificationChannel: "email",
      preferedLanguage: "string",
      vibrateMode: true
    } as GetAppSettingsUserSettings,

    timeAndLocaleSettings: {
      language: "",
      timeZoneId: "",
      datePattern: "",
      timePattern: ""
    } as TimeAndLocaleSettings,
    multiFactorAuthenticationSettings: {
      isEnable: true,
      pinLength: 0,
      pinTTL: 0
    } as MultiFactorAuthenticationSettings,
    passwordPolicySettings: {
      isEnable: true,
      duration: 0,
      minimumLength: 0,
      alertUserToChangeFrom: 0,
      enforcePasswordHistory: false,
      passwordComplexityIsEnable: false,
      mustContainsAtLeastOneUppercase: false,
      mustContainsAtLeastOneLowercase: false,
      mustContainsAtLeastOneSpecialChar: false,
      mustContainsAtLeastOneDigit: false
    } as PasswordPolicySettings,

    cookiesSettings: {
      cookieConsentTimeFrame: 0,
      domain: "",
      httpOnly: false
    } as CookiesSettings,
    keyVaultSettings: {
      isEnable: true,
      url: "",
      tenantId: "",
      clientId: "",
      clientSecret: ""
    } as KeyVaultSettings,
    jwtSettings: {
      secret: "",
      issuer: "",
      audience: "",
      subject: "",
      expiration: 0,
      refreshTokenTTL: 0,
      validateIssuer: false,
      validateAudience: false,
      validateLifetime: false,
      validateIssuerSigningKey: false,
      resetTokenTTL: 0,
      cookiesTTL: 0
    } as JwtSettings,

    timeZones: [
      {
        id: "",
        displayName: "",
        daylightName: "",
      } as GetAppSettingsResultTimezone
    ],
    languages: [
      {
        id: "",
        displayName: "",
        threeLetterISOLanguageName: "",
        twoLetterISOLanguageName: "",
      } as GetAppSettingsResultLanguages
    ],
    datePatterns: [
      {
        id: "",
        displayName: "",
        description: "",
        template: "",
      } as GetAppSettingsResultDatePatterns
    ],
  },
  pending: false,
  Errors: [],
};

export interface GetAppSettingsModelShape {
  command: string;
}
export interface GetAppSettingsFailurePayload {
  errors: string[];
}

export interface GetAppSettingsSuccess {
  type: string;
  payload: GetAppSettings;
}
export interface GetAppSettingsFailure {
  type: string;
  payload: GetAppSettingsFailurePayload;
}
export interface GetAppSettingsPayload {
  command: string;
  user: GetAppSettings;
  errors: GetAppSettingsFailurePayload;
}
export interface GetAppSettingsAction {
  type: string;
  payload: GetAppSettingsPayload;
}
