
import { call, put, takeLatest } from "redux-saga/effects";
import { ActionTypes } from "../actions/constants/action-types";
import { DeleteBrandAction, DeleteBrandFailurePayload, DeleteBrandSuccessPayload, GetBrandAction, GetBrandFailurePayload, GetBrandsFailurePayload, UpdateBrandAction, UpdateBrandFailurePayload, UpdateBrandSuccessPayload } from "../actions/brands";
import { deleteBrandFailure, deleteBrandSuccess, getBrandFailure, getBrandsFailure, getBrandsSuccess, getBrandSuccess, updateBrandFailure, updateBrandSuccess } from "../actions/brands/brands-actions";
import { ControllerApi } from "src/app/features/management/vehicles/locale/controller-api";

const controllerApi = new ControllerApi();

const callApiToUpdateBrands = async (command: UpdateBrandCommand) => controllerApi.updateBrand(command);
const callApiToDeleteBrands = async (command: DeleteBrandCommand) => controllerApi.deleteBrand(command);
const callApiToGetBrands = async () => controllerApi.getBrands();
const callApiToGetBrand = async (command: BrandCommand) => controllerApi.getBrand(command);

function* updateBrandSaga(action: UpdateBrandAction) {
  try {
    const response = yield call(callApiToUpdateBrands, action.payload.command);
    if (response) {
      if (response?.hasSucceeded) {
        yield put(updateBrandSuccess({ value: true } as UpdateBrandSuccessPayload));
        const responseGetBrand = yield call(callApiToGetBrands);
        if (responseGetBrand) {
          yield put(getBrandsSuccess(responseGetBrand as GetBrands));
        } else {
          let messages: string[] = [];
          responseGetBrand?.errorMessages.map((item) => {
            return messages.push(item.errorMessage);
          });
          yield put(getBrandsFailure({ errors: messages } as GetBrandsFailurePayload));
        }
      } else {
        let messages: string[] = [];
        response.errorMessages.map((item) => {
          return messages.push(item.errorMessage);
        });
        yield put(updateBrandFailure({ errors: messages } as UpdateBrandFailurePayload));
      }
    } else {
      let messages: string[] = [];
      messages.push("Erreur lors de la connexion au serveur");
      yield put(updateBrandFailure({ errors: messages } as UpdateBrandFailurePayload));
    }
  } catch (e) {
    let messages: string[] = [];
    messages.push(e.message);
    yield put(updateBrandFailure({ errors: messages } as UpdateBrandFailurePayload));
  }
}

function* deleteBrandSaga(action: DeleteBrandAction) {
  try {
    const response = yield call(callApiToDeleteBrands, action.payload.command);
    if (response) {
      if (response?.hasSucceeded) {
        yield put(deleteBrandSuccess({ value: true } as DeleteBrandSuccessPayload));
        const responseGetBrand = yield call(callApiToGetBrands);
        if (responseGetBrand) {
          yield put(getBrandsSuccess(responseGetBrand as GetBrands));
        } else {
          let messages: string[] = [];
          responseGetBrand?.errorMessages.map((item) => {
            return messages.push(item.errorMessage);
          });
          yield put(getBrandsFailure({ errors: messages } as GetBrandsFailurePayload));
        }
      } else {
        let messages: string[] = [];
        response.errorMessages.map((item) => {
          return messages.push(item.errorMessage);
        });
        yield put(deleteBrandFailure({ errors: messages } as DeleteBrandFailurePayload));
      }
    } else {
      let messages: string[] = [];
      messages.push("Erreur lors de la connexion au serveur");
      yield put(deleteBrandFailure({ errors: messages } as DeleteBrandFailurePayload));
    }
  } catch (e) {
    let messages: string[] = [];
    messages.push(e.message);
    yield put(deleteBrandFailure({ errors: messages } as DeleteBrandFailurePayload));
  }
}

function* getBrandsSaga() {
  try {
    const response = yield call(callApiToGetBrands);
    if (response) {
      yield put(getBrandsSuccess(response as GetBrands));
    } else {
      let messages: string[] = [];
      response?.errorMessages.map((item) => {
        return messages.push(item.errorMessage);
      });
      yield put(getBrandsFailure({ errors: messages } as GetBrandsFailurePayload));
    }

  } catch (e) {
    let messages: string[] = [];
    messages.push(e.message);
    yield put(getBrandsFailure({ errors: messages } as GetBrandsFailurePayload));
  }
}

function* getBrandSaga(action: GetBrandAction) {
  try {
    const response = yield call(callApiToGetBrand, action.payload.command);
    if (response) {
      yield put(getBrandSuccess(response as GetBrand));
    } else {
      let messages: string[] = [];
      response?.errorMessages.map((item) => {
        return messages.push(item.errorMessage);
      });
      yield put(getBrandFailure({ errors: messages } as GetBrandFailurePayload));
    }

  } catch (e) {
    let messages: string[] = [];
    messages.push(e.message);
    yield put(getBrandFailure({ errors: messages } as GetBrandFailurePayload));
  }
}

export function* watchBrandsSaga(){
  yield takeLatest(ActionTypes.BRANDS_REQUEST, getBrandsSaga);
  yield takeLatest(ActionTypes.BRAND_REQUEST, getBrandSaga);
  yield takeLatest(ActionTypes.UPDATE_BRAND_REQUEST, updateBrandSaga);
  yield takeLatest(ActionTypes.DELETE_BRAND_REQUEST, deleteBrandSaga);
}