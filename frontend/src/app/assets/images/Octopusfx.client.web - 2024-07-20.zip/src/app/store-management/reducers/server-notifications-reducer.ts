import { ActionTypes } from "../actions/constants/action-types";
import { produce } from "immer";
import { StoreShape, initialState } from "../actions/server-notifications";

export const setServerNotificationsReducer = (
  state: StoreShape = initialState,
  args: SetServerNotificationAction
): StoreShape => {
  switch (args.type) {
    case ActionTypes.SET_SERVER_NOTIFICATIONS:
      const newState = produce(state, (draftState) => {
        draftState.value.push(args.payload);
      });

      return newState;

    case ActionTypes.REMOVE_SERVER_NOTIFICATION:
      const notificationToRemove = state.value.find(
        (notification) => notification.time === args.payload.time
      );

      if (!notificationToRemove) return state;

      const newStateAfterNotificationRemoved = produce(state, (draftState) => {
        draftState.value = draftState.value.filter(
          (notification) => notification.time !== notificationToRemove.time
        );
      });

      return newStateAfterNotificationRemoved;

    default:
      return state;
  }
};
