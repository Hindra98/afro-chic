
import {
  ColumnDirective,
  ColumnsDirective,
  Edit,
  ExcelExport,
  ExcelExportProperties,
  Filter,
  Sort,
  GridComponent,
  Inject,
  Page,
  PdfExport,
  PdfExportProperties,
  Resize,
  Selection,
  RecordClickEventArgs,
} from "@syncfusion/ej2-react-grids";
import { useRef, useState } from "react";
import Breadcrumb from "src/app/components/shared/breadcrumb";
import { useAppDispatch, useAppSelector } from "src/app/core/hooks/core-hooks";
import { useLocalizer } from "src/app/core/Localization";
import "src/app/styles/_notifications.scss";
import ToolsbarOptions from "src/app/components/shared/grid-components/toolsbar-options";
import emptyrecords from "src/app/components/shared/grid-components/empty-records";
import iconAgency from "src/app/assets/image-octopusfx/user.png";
import { GridConstants } from "src/app/core/constants/data-grid";
import { getAudits } from "src/app/store-management/actions/audits/audits-actions";
import ViewAuditSidebar from "./view-audit-sidebar";
import { SidebarComponent } from "@syncfusion/ej2-react-navigations";


function nameTemplate(props) {
  return (
    <span className={`name-link cursor-pointer hover:text-blue-900 hover:underline hover:font-bold`}>
      {props.name}
    </span>
  );
}

const AuditDataGrid = () => {

  const commonLocalizer = useLocalizer("Common-ResCommon");
  
  const [isShowBackdrop, setShowBackdrop] = useState<boolean>(false);
  const [getAuditToView, setAuditToView] = useState<AuditItem>(null);
  let sidebarInstance = useRef<SidebarComponent>(null);
  let grid = useRef<GridComponent>(null);
  const dispatch = useAppDispatch();

  const getAllAudits = useAppSelector((state) => state.getAudits);

  const [getRefresh, setGetRefresh] = useState(false);

  const getAuditsData = () => {
    dispatch(getAudits());
  };

  if (
    !getRefresh &&
    !getAllAudits?.pending &&
    getAllAudits?.Errors?.length === 0
  ) {
    getAuditsData();
    setGetRefresh(true);
  }

  const sidebarClose = () => {
    sidebarInstance.current.hide();
    setShowBackdrop(false);
  };

  const handleActionBegin = (args: any) => {
    if (args.requestType === "add" || args.requestType === "beginEdit") {
      sidebarInstance?.current?.toggle();
      setShowBackdrop(true);
      args.cancel = true;
    }
  };
  const handleClickRecord = (e: RecordClickEventArgs) => {
    if (grid.current) {
      let keyRecord = e.rowData as AuditItem;
      setAuditToView(keyRecord);
      sidebarInstance?.current?.toggle();
      setShowBackdrop(true);
    }
  };

  const editSettings: any = {
    allowEditing: true,
    allowAdding: true,
    allowDeleting: true,
    mode: "Normal",
    allowEditOnDblClick: false,
  };
  const exportFilename = "audit des actions de l'utilisateur";
  const rowsPerPage = 15;
  const [currentPage, setCurrentPage] = useState(1);
  const handlePageChange = (page: number) => {
    grid.current.pageSettings.currentPage = page;
    setCurrentPage(page);
  };
  const handleSearch = (searchText: string) => {
    console.log("handle", searchText);
  };

  const select: any = {
    persistSelection: true,
    type: "Single",
    checkboxOnly: false,
    mode: "Both",
    checkboxMode: "ResetOnRowClick",
  };

  const gridFilter: any = { type: "Menu" };
  const pdfExportProperties: PdfExportProperties = {
    header: {
      fromTop: 0,
      height: 130,
      contents: [
        {
          type: "Line",
          style: { penColor: "#000080", penSize: 2, dashStyle: "Solid" },
          points: { x1: 0, y1: 4, x2: 685, y2: 4 },
        },
        {
          type: "Text",
          value: "Audit des actions de l'utilisateur",
          position: { x: 200, y: 50 },
          style: { textBrushColor: "#000000", fontSize: 20 },
        },
      ],
    },
    footer: {
      fromBottom: 10,
      height: 60,
      contents: [
        {
          type: "Line",
          style: { penColor: "#000080", penSize: 2, dashStyle: "Dot" },
          points: { x1: 0, y1: 4, x2: 685, y2: 4 },
        },
        {
          type: "PageNumber",
          pageNumberType: "Arabic",
          format: "Page {$current} sur {$total}", //optional
          position: { x: 0, y: 25 },
          style: { textBrushColor: "#4169e1", fontSize: 15, hAlign: "Center" },
        },
      ],
    },
    exportType: "AllPages",
  };

  const ExportPdf = () => {
    (grid.current as GridComponent)?.pdfExport({
      ...pdfExportProperties,
      fileName: `${exportFilename}.pdf`,
    });
  };
  const ExportExcel = () => {
    const excelExportProperties: ExcelExportProperties = {
      exportType: "AllPages",
      fileName: `${exportFilename}.xlsx`,
    };
    (grid.current as GridComponent)?.excelExport({ ...excelExportProperties });
  };
  const ExportCsv = () => {
    const excelExportProperties: ExcelExportProperties = {
      exportType: "AllPages",
      fileName: `${exportFilename}.csv`,
    };
    (grid.current as GridComponent)?.csvExport({ ...excelExportProperties });
  };

  window.document.title = "Audit des actions des utilisateurs";

  return (
    <div className="h-full flex flex-col justify-start mx-auto notifications-component">
      <div className={` text-3xl align-top flex flex-col justify-start ps-10 pt-4 flex-wrap my-2 gap-0 `}>
        <h1 className="">{"Audit des actions des utilisateurs"}</h1>
        <Breadcrumb
          items={[
            {
              title: commonLocalizer("MODULE_COMMON_SIDEBAR_DASHBOARD"),
              link: "/dashboard",
            },
            { title: "Audit des actions des utilisateurs" },
          ]}
        />
      </div>

      <ToolsbarOptions
        ToolsbarActionItem={[
          {
            icon: "ccwicon-",
            name: "Rafraichir",
            handleClick: () => dispatch(getAudits()),
          },
        ]}
        allowExportPdf
        allowExportCsv
        allowExportExcel
        handleExportPdf={ExportPdf}
        handleExportExcel={ExportExcel}
        handleExportCsv={ExportCsv}
        enablePager
        pager={{ align: "right" }}
        enablePagination
        pagination={{
          currentPage: currentPage,
          rowsPerPage: rowsPerPage,
          totalPages: parseInt(getAllAudits?.value?.auditItems?.length.toString()),
          handleChangePage: handlePageChange,
        }}
        enableSearch
        search={{ handleSearch: handleSearch }}
      />
      <GridComponent
        dataSource={getAllAudits.value.auditItems}
        id="notifications-grid"
        cssClass="mx-2"
        loadingIndicator={{ indicatorType: "Shimmer" }}
        allowResizing={true}
        enableHover={true}
        allowSorting={false}
        allowFiltering={true}
        actionBegin={handleActionBegin}
        recordClick={handleClickRecord}
        emptyRecordTemplate={() =>
          emptyrecords(
            "Audit vide pour le moment",
            iconAgency,
            getAllAudits.pending,
            "w-1/12"
          )
        }
        resizeSettings={{ mode: "Auto" }}
        rowHeight={38}
        height={GridConstants.HEIGHT}
        filterSettings={gridFilter}
        allowSelection={true}
        selectionSettings={select}
        enableHeaderFocus={true}
        allowPaging={true}
        autoFit={true}
        allowPdfExport={true}
        allowExcelExport={true}
        editSettings={editSettings}
        pageSettings={{ pageCount: 2, pageSize: rowsPerPage }}
        ref={grid}
      >
        <ColumnsDirective>
          <ColumnDirective
            type="checkbox"
            allowSorting={false}
            allowFiltering={false}
            width="40"
          ></ColumnDirective>
          <ColumnDirective
            field="externalId"
            visible={false}
            headerText="Angency Key"
            isPrimaryKey={true}
            width="auto"
          ></ColumnDirective>
          <ColumnDirective
            field="name"
            headerText="Commande"
            template={nameTemplate}
            clipMode="EllipsisWithTooltip"
            width="auto"
          />
          <ColumnDirective
            field="payload"
            headerText="Charge utile"
            clipMode="EllipsisWithTooltip"
            width="auto"
          />
          <ColumnDirective
            field="createdOnWording"
            headerText="Date de création"
            clipMode="EllipsisWithTooltip"
            width="auto"
          />
          <ColumnDirective
            field="createdBy"
            headerText="Crée par"
            clipMode="EllipsisWithTooltip"
            width="auto"
          />
          <ColumnDirective
            field="sourceIP"
            headerText="Adresse Ip"
            clipMode="EllipsisWithTooltip"
            width="150"
          />
          <ColumnDirective
            field="browser"
            headerText="Navigateur"
            clipMode="EllipsisWithTooltip"
            width="120"
          />
          <ColumnDirective
            field="operationSystem"
            headerText="Système d'exploitation"
            clipMode="EllipsisWithTooltip"
            width="175"
          />
        </ColumnsDirective>
        <Inject
          services={[
            Page,
            Filter,
            Sort,
            PdfExport,
            ExcelExport,
            Resize,
            Selection,
            Edit,
          ]}
        />
      </GridComponent>

      <ViewAuditSidebar audit={getAuditToView} func={{
          sidebarClose: sidebarClose.bind(this),
          isShowBackdrop: isShowBackdrop,
          sidebarInstance: sidebarInstance,}}  />

    </div>
  )
}

export default AuditDataGrid