import { ActionTypes } from "../actions/constants/action-types";
import { produce } from "immer";
import { DeleteVehicleAction, DeleteVehicleStoreShape, GetVehicleAction, GetVehiclesAction, GetVehiclesStoreShape, GetVehicleStoreShape, initialStateDeleteVehicle, initialStateGetVehicle, initialStateGetVehicles, initialStateUpdateVehicle, UpdateVehicleAction, UpdateVehicleStoreShape } from "../actions/vehicles";


export const updateVehicleReducer = (state: UpdateVehicleStoreShape = initialStateUpdateVehicle, args: UpdateVehicleAction): UpdateVehicleStoreShape => {
  switch (args.type) {

    case ActionTypes.UPDATE_VEHICLE_REQUEST:
      return produce(state, (draftState) => {
        draftState.pending = true;
        draftState.errors = []
        draftState.value = false;
      });

    case ActionTypes.UPDATE_VEHICLE_FAILURE:
      return produce(state, (draftState) => {
        draftState.pending = false;
        draftState.errors = args?.payload?.errors?.errors
        draftState.value = false;
      });

    case ActionTypes.UPDATE_VEHICLE_SUCCESS:
      return produce(state, (draftState) => {
        draftState.errors = []
        draftState.pending = false;
        draftState.value = args.payload?.value?.value
      });

    default:
      return state;
  }
};

export const deleteVehicleReducer = (state: DeleteVehicleStoreShape = initialStateDeleteVehicle, args: DeleteVehicleAction): DeleteVehicleStoreShape => {
  switch (args.type) {

    case ActionTypes.DELETE_VEHICLE_REQUEST:
      return produce(state, (draftState) => {
        draftState.pending = true;
        draftState.errors = []
        draftState.value = false;
      });

    case ActionTypes.DELETE_VEHICLE_FAILURE:
      return produce(state, (draftState) => {
        draftState.pending = false;
        draftState.errors = args?.payload?.errors?.errors
        draftState.value = false;
      });

    case ActionTypes.DELETE_VEHICLE_SUCCESS:
      return produce(state, (draftState) => {
        draftState.errors = []
        draftState.pending = false;
        draftState.value = args.payload?.value?.value
      });

    default:
      return state;
  }
};

export const getVehicleReducer = (state: GetVehicleStoreShape = initialStateGetVehicle, args: GetVehicleAction): GetVehicleStoreShape => {
  switch (args.type) {

    case ActionTypes.VEHICLE_REQUEST:
      return produce(state, (draftState) => {
        draftState.pending = true;
        draftState.errors = [];
      });

    case ActionTypes.VEHICLE_SUCCESS:
      return produce(state, (draftState) => {
        draftState.pending = false;
        draftState.errors = args?.payload?.errors?.errors
        draftState.value.isAdministrator = args?.payload?.value?.isAdministrator
        draftState.value.vehicle.id = args?.payload?.value?.vehicle?.id
        draftState.value.vehicle.vin = args?.payload?.value?.vehicle?.vin
        draftState.value.vehicle.engineNumber = args?.payload?.value?.vehicle?.engineNumber
        draftState.value.vehicle.registrationNumber = args?.payload?.value?.vehicle?.registrationNumber
        draftState.value.vehicle.gearNumber = args?.payload?.value?.vehicle?.gearNumber
        draftState.value.vehicle.name = args?.payload?.value?.vehicle?.name
        draftState.value.vehicle.gearBoxType = args?.payload?.value?.vehicle?.gearBoxType
        draftState.value.vehicle.gearBoxTypeWording = args?.payload?.value?.vehicle?.gearBoxTypeWording
        draftState.value.vehicle.commissionStartingDate = args?.payload?.value?.vehicle?.commissionStartingDate
        draftState.value.vehicle.commissionStartingDateWording = args?.payload?.value?.vehicle?.commissionStartingDateWording
        draftState.value.vehicle.commissionEndDate = args?.payload?.value?.vehicle?.commissionEndDate
        draftState.value.vehicle.commissionEndDateWording = args?.payload?.value?.vehicle?.commissionEndDateWording
        draftState.value.vehicle.modelYear = args?.payload?.value?.vehicle?.modelYear
        draftState.value.vehicle.cO2Emissions = args?.payload?.value?.vehicle?.cO2Emissions
        draftState.value.vehicle.description = args?.payload?.value?.vehicle?.description
        draftState.value.vehicle.brandId = args?.payload?.value?.vehicle?.brandId
        draftState.value.vehicle.modelId = args?.payload?.value?.vehicle?.modelId
        draftState.value.vehicle.status = args?.payload?.value?.vehicle?.status
        draftState.value.vehicle.statusWording = args?.payload?.value?.vehicle?.statusWording
        draftState.value.vehicle.energyType = args?.payload?.value?.vehicle?.energyType
        draftState.value.vehicle.energyTypeWording = args?.payload?.value?.vehicle?.energyTypeWording
        draftState.value.vehicle.statusWording = args?.payload?.value?.vehicle?.statusWording
        draftState.value.vehicle.vehicleType = args?.payload?.value?.vehicle?.vehicleType
        draftState.value.vehicle.vehicleTypeWording = args?.payload?.value?.vehicle?.vehicleTypeWording
        draftState.value.vehicle.imageUrls = args?.payload?.value?.vehicle?.imageUrls
        draftState.value.vehicle.documentUrls = args?.payload?.value?.vehicle?.documentUrls

        draftState.value.brands = args?.payload?.value?.brands
        draftState.value.vehicleTypes = args?.payload?.value?.vehicleTypes
        draftState.value.gearBoxes = args?.payload?.value?.gearBoxes
        draftState.value.models = args?.payload?.value?.models
        draftState.value.energyTypes = args?.payload?.value?.energyTypes
        draftState.value.availabilityStatus = args?.payload?.value?.availabilityStatus
      });

    case ActionTypes.VEHICLE_FAILURE:
      return produce(state, (draftState) => {
        draftState.errors = args.payload?.errors?.errors
        draftState.pending = false;
      });

    default:
      return state;
  }
};

export const getVehiclesReducer = (state: GetVehiclesStoreShape = initialStateGetVehicles, args: GetVehiclesAction): GetVehiclesStoreShape => {
  switch (args.type) {

    case ActionTypes.VEHICLES_REQUEST:
      return produce(state, (draftState) => {
        draftState.pending = true;
        draftState.value.hasAlreadyCalled = true;
        draftState.errors = []
      });

    case ActionTypes.VEHICLES_FAILURE:
      return produce(state, (draftState) => {
        draftState.pending = false;
        draftState.value.hasAlreadyCalled = true;
        draftState.value.hasAlreadyCalled = true;
        draftState.errors = args?.payload?.errors?.errors
      });

    case ActionTypes.VEHICLES_SUCCESS:
      return produce(state, (draftState) => {
        draftState.errors = []
        draftState.pending = false;
        draftState.value.hasAlreadyCalled = true;
        draftState.value.isAdministrator = args?.payload?.value?.isAdministrator
        draftState.value.vehicles = args?.payload?.value?.vehicles
        draftState.value.brands = args?.payload?.value?.brands
      });

    default:
      return state;
  }
};
