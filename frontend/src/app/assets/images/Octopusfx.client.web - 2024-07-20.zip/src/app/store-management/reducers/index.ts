import { combineReducers } from "@reduxjs/toolkit";
import { changeLanguageReducer, setLanguagesReducer } from "./languages-reducers";
import { authenticatedUserReducer, signOutReducer, verifyPinCodeReducer } from "./oauth-reducers";
import { setServerNotificationsReducer } from "./server-notifications-reducer";
import { changeEmailReducer, changePasswordReducer, changePhoneNumberReducer, forgotPasswordReducer, sendPinCodeReducer, resetPasswordReducer, verifyNewContactMediaReducer } from "./accounts-reducers";
import { addUserReducer, deleteUserReducer, getUserReducer, getUsersReducer, lockUserReducer, resetPasswordUserReducer, updateUserReducer, whoIAmReducer } from "./users-reducers";
import { myProfileGetDataReducer, myProfileReducer } from "./my-profile-reducers";
import { getUserPreferencesReducer, updateUserPreferencesReducer } from "./user-preferences-reducer";
import { checkNotificationReducer, countPermanentNotificationReducer, deletePermanentNotificationReducer, markReadPermanentNotificationReducer, permanentNotificationReducer, sortPermanentNotificationReducer } from "./permanent-notification-reducer";
import { getAppSettingsReducer, updateAppSettingsReducer } from "./app-settings-reducer";
import { addTenantReducer, deleteTenantReducer, exportPdfTenantReducer, getTenantReducer, getTenantsReducer, updateTenantReducer } from "./tenants-reducer";
import { addAgencyReducer, deleteAgencyReducer, getAgenciesReducer, getAgencyReducer, updateAgencyReducer } from "./agencies-reducer";
import { getAuditsReducer } from "./audits-reducers";
import { deleteVehicleReducer, getVehicleReducer, getVehiclesReducer, updateVehicleReducer } from "./vehicles-reducer";
import { deleteBrandReducer, getBrandReducer, getBrandsReducer, updateBrandReducer } from "./brands-reducers";

const rootReducer = combineReducers({
    authenticatedUser: authenticatedUserReducer,
    verifyPinCode: verifyPinCodeReducer,
    signOut: signOutReducer,
    sendPinCode: sendPinCodeReducer,
    forgotPassword: forgotPasswordReducer,
    resetPassword: resetPasswordReducer,
    changePassword: changePasswordReducer,
    verifyNewContactMedia: verifyNewContactMediaReducer,
    changeEmail: changeEmailReducer,
    changePhoneNumber: changePhoneNumberReducer,
    myProfile: myProfileReducer,
    myProfileGetData: myProfileGetDataReducer,
    getUserPreferences: getUserPreferencesReducer,
    updateUserPreferences: updateUserPreferencesReducer,
    getTenants: getTenantsReducer,
    addTenant: addTenantReducer,
    updateTenant: updateTenantReducer,
    deleteTenant: deleteTenantReducer,
    getTenant: getTenantReducer,
    exportPdfTenant: exportPdfTenantReducer,
    getAgencies: getAgenciesReducer,
    getAgency: getAgencyReducer,
    deleteAgency: deleteAgencyReducer,
    updateAgency: updateAgencyReducer,
    addAgency: addAgencyReducer,
    getUsers: getUsersReducer,
    getUser: getUserReducer,
    deleteUser: deleteUserReducer,
    updateUser: updateUserReducer,
    addUser: addUserReducer,
    getAudits: getAuditsReducer,
    lockUser: lockUserReducer,
    resetPasswordUser: resetPasswordUserReducer,
    getAppSettings: getAppSettingsReducer,
    updateAppSettings: updateAppSettingsReducer,
    whoIAm: whoIAmReducer,
    notification: checkNotificationReducer,
    
    updateVehicle: updateVehicleReducer,
    deleteVehicle: deleteVehicleReducer,
    getVehicle: getVehicleReducer,
    getVehicles: getVehiclesReducer,
    updateBrand: updateBrandReducer,
    deleteBrand: deleteBrandReducer,
    getBrand: getBrandReducer,
    getBrands: getBrandsReducer,

    countPermanentNotification: countPermanentNotificationReducer,
    permanentNotification: permanentNotificationReducer,
    markReadNotification: markReadPermanentNotificationReducer,
    deleteNotification: deletePermanentNotificationReducer,
    sortNotification: sortPermanentNotificationReducer,

    serverNotifications: setServerNotificationsReducer,
    appLanguages: setLanguagesReducer,
    currentLanguage: changeLanguageReducer,
});

export default rootReducer;