
import { AddAgencyAction, AddAgencyFailurePayload, AddAgencySuccessPayload, DeleteAgencyAction, DeleteAgencyFailurePayload, DeleteAgencySuccessPayload, GetAgenciesAction, GetAgenciesFailurePayload, AgencyAction, AgencyFailurePayload, UpdateAgencyAction, UpdateAgencyFailurePayload, UpdateAgencySuccessPayload } from ".";
import { ActionTypes } from "../constants/action-types";

  export const getAgencies = (): GetAgenciesAction => {
  
      return {
          type: ActionTypes.GET_AGENCIES_REQUEST,
          payload: {
              command: null,
              user: null,
              errors: null
          }
      } as GetAgenciesAction
    };
    
    export const getAgenciesFailure = (payload: GetAgenciesFailurePayload, errServer:ServerErrorMessageItem): GetAgenciesAction => {
  
      return {
          type: ActionTypes.GET_AGENCIES_FAILURE,
          payload: {
              command: null,
              user: null,
              errors: payload,
              errServer: errServer
          }
      } as GetAgenciesAction;
    };
    
    export const getAgenciesSuccess = (payload: GetAgencies): GetAgenciesAction => {
  
      return {
          type: ActionTypes.GET_AGENCIES_SUCCESS,
          payload: {
              command: null,
              user: payload,
              errors: null
          }
      } as GetAgenciesAction;
    };

  export const getAgency = (command: AgencyCommand): AgencyAction => {
  
    return {
        type: ActionTypes.GET_AGENCY_REQUEST,
        payload: {
            command: command,
            user: null,
            errors: null
        }
    } as AgencyAction
  };
  
  export const getAgencyFailure = (payload: AgencyFailurePayload, errServer:ServerErrorMessageItem): AgencyAction => {

    return {
        type: ActionTypes.GET_AGENCY_FAILURE,
        payload: {
            command: null,
            user: null,
            errors: payload
        }
    } as AgencyAction;
  };
  
  export const getAgencySuccess = (payload: GetAgency): AgencyAction => {

    return {
        type: ActionTypes.GET_AGENCY_SUCCESS,
        payload: {
            command: null,
            user: payload,
            errors: null
        }
    } as AgencyAction;
  };

  export const addAgency = (command: BranchCommand): AddAgencyAction => {

    return {
        type: ActionTypes.ADD_AGENCY_REQUEST,
        payload: {
            command: command,
            value: {value: false},
            errors: null
        }
    } as AddAgencyAction
  };

  export const addAgencySuccess = (payload: AddAgencySuccessPayload): AddAgencyAction => {

    return {
        type: ActionTypes.ADD_AGENCY_SUCCESS,
        payload: {
            command: null,
            value: payload,
            errors: null
        }
    } as AddAgencyAction
  };

  export const addAgencyFailure = (payload: AddAgencyFailurePayload): AddAgencyAction => {

    return {
        type: ActionTypes.ADD_AGENCY_FAILURE,
        payload: {
            command: null,
            value: null,
            errors: payload
        }
    } as AddAgencyAction
  };

  export const updateAgency = (command: BranchCommand): UpdateAgencyAction => {

    return {
        type: ActionTypes.UPDATE_AGENCY_REQUEST,
        payload: {
            command: command,
            value: {value: false},
            errors: null
        }
    } as UpdateAgencyAction
  };

  export const updateAgencySuccess = (payload: UpdateAgencySuccessPayload): UpdateAgencyAction => {

    return {
        type: ActionTypes.UPDATE_AGENCY_SUCCESS,
        payload: {
            command: null,
            value: payload,
            errors: null
        }
    } as UpdateAgencyAction
  };

  export const updateAgencyFailure = (payload: UpdateAgencyFailurePayload): UpdateAgencyAction => {

    return {
        type: ActionTypes.UPDATE_AGENCY_FAILURE,
        payload: {
            command: null,
            value: null,
            errors: payload
        }
    } as UpdateAgencyAction
  };

  
  export const deleteAgency = (command: DeleteAgencyCommand): DeleteAgencyAction => {

    return {
        type: ActionTypes.DELETE_AGENCIES_REQUEST,
        payload: {
            command: command,
            value: {value: false},
            errors: null
        }
    } as DeleteAgencyAction
  };

  export const deleteAgencySuccess = (payload: DeleteAgencySuccessPayload): DeleteAgencyAction => {

    return {
        type: ActionTypes.DELETE_AGENCIES_SUCCESS,
        payload: {
            command: null,
            value: payload,
            errors: null
        }
    } as DeleteAgencyAction
  };

  export const deleteAgencyFailure = (payload: DeleteAgencyFailurePayload): DeleteAgencyAction => {

    return {
        type: ActionTypes.DELETE_AGENCIES_FAILURE,
        payload: {
            command: null,
            value: null,
            errors: payload
        }
    } as DeleteAgencyAction
  };

  