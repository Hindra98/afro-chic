import { useRef, useState } from "react";
import * as Yup from "yup";
import Button from "src/app/components/form/Button";
import { useAppDispatch, useAppSelector } from "src/app/core/hooks/core-hooks";
import { getAppSettings, updateAppSettings } from '../../../store-management/actions/app-settings/app-settings-actions';
import "../../../styles/_app-settings.scss";
import { useGlobalAppContext } from "src/app/core/hooks/use-app-context";
import { MessageComponent } from "@syncfusion/ej2-react-notifications";
import OperationResultComponent from "src/app/components/shared/operation-result-component";
import UserSettings from "./components/user-settings";
import TimeAndLocaleSettings from "./components/time-and-locale-settings";
import MultiFactorAuthSettings from "./components/multi-factor-authentication-settings";
import PasswordPolicySettings from "./components/password-policy-settings";
import CookiesSettings from "./components/cookies-settings";
import KeyVaultSettings from "./components/key-vault-settings";
import JwtSettings from "./components/jwt-settings";
import { useLocalizer } from "src/app/core/Localization";
import Breadcrumb from "src/app/components/shared/breadcrumb";
import { TabAnimationSettingsModel, TabComponent, TabItemDirective, TabItemsDirective } from "@syncfusion/ej2-react-navigations";
import { ClasseName } from "src/app/core/constants/class-name";

const AppSettings = () => {

  const dispatch = useAppDispatch();
  const commonLocalizer = useLocalizer("Common-ResCommon");
  const updateAppSettingsData = useAppSelector((state) => state.updateAppSettings);
  const getAppSettingsData = useAppSelector((state) => state.getAppSettings);
  let tabInstance = useRef<TabComponent>(null);

  const { claims } = useGlobalAppContext();
  const role = claims?.get("role"); // SuperAdmin || Administrator || Others users

  const [getUne, setGetUne] = useState(false);
  const [actu, setActu] = useState(false);

  const getAppData = () => {
    dispatch(getAppSettings(""));
  };
  if (!getUne && !getAppSettingsData.pending && getAppSettingsData.Errors.length === 0) {
    getAppData();
    setGetUne(true);
  }

  const animateSidebar: TabAnimationSettingsModel = {
    previous: { effect: "None", duration: 600, easing: "ease" },
    next: { effect: "None", duration: 600, easing: "ease" },
  };
  let headertext: any = [
    { text: commonLocalizer("MODULE_COMMON_WEB_SETTINGS_USER_PREFERENCES_TITLE"), iconCss: "icon" },
    { text: commonLocalizer("MODULE_COMMON_WEB_SETTINGS_TIMES_AND_LOCALES_TITLE"), iconCss: "icon" },
    { text: commonLocalizer("MODULE_COMMON_WEB_SETTINGS_2FA_TITLE"), iconCss: "icon" },
    { text: commonLocalizer("MODULE_COMMON_WEB_SETTINGS_PASSWORD_POLICY_TITLE"), iconCss: "icon" },
    { text: commonLocalizer("MODULE_COMMON_WEB_SETTINGS_SUBGROUP_COOKIES_TITLE"), iconCss: "icon" },
    { text: commonLocalizer("MODULE_COMMON_WEB_SETTINGS_AZURE_KEY_VAULT_TITLE"), iconCss: "icon" },
    { text: commonLocalizer("MODULE_COMMON_WEB_SETTINGS_JWT_TITLE"), iconCss: "icon" },
  ];


  const schemaTimeLocale = Yup.object().shape({
    language: Yup.string(),
    timeZoneId: Yup.string(),
    datePattern: Yup.string(),
    timePattern: Yup.string(),
  });

  const schemaMultiFact = Yup.object().shape({
    isEnableMulltiFactAuth: Yup.boolean(),
    pinLength: Yup.number(),
    pinTTL: Yup.number(),
  });

  const schemaPasswordPolicy = Yup.object().shape({
    isEnablePasswordPolicy: Yup.boolean(),
    durationPasswordPolicy: Yup.number(),
    minimumLength: Yup.number(),
    alertUserToChangeFrom: Yup.number(),
    enforcePasswordHistory: Yup.boolean(),
    passwordComplexityIsEnable: Yup.boolean(),
    mustContainsAtLeastOneUppercase: Yup.boolean(),
    mustContainsAtLeastOneLowercase: Yup.boolean(),
    mustContainsAtLeastOneSpecialChar: Yup.boolean(),
    mustContainsAtLeastOneDigit: Yup.boolean(),
  });

  const schemaCookies = Yup.object().shape({
    cookieConsentTimeFrame: Yup.number(),
    domainCookiesSettings: Yup.string(),
    httpOnlyCookiesSettings: Yup.boolean(),
  });

  const schemaKeyVault = Yup.object().shape({
    isEnableKeyVault: Yup.boolean(),
    urlKeyVault: Yup.string(),
    tenantId: Yup.string(),
    clientId: Yup.string(),
    clientSecret: Yup.string(),
  });

  const schemaJwt = Yup.object().shape({
    secret: Yup.string(),
    issuer: Yup.string(),
    audience: Yup.string(),
    subject: Yup.string(),
    expiration: Yup.number(),
    refreshTokenTTL: Yup.number(),
    validateIssuer: Yup.boolean(),
    validateAudience: Yup.boolean(),
    validateLifetime: Yup.boolean(),
    validateIssuerSigningKey: Yup.boolean(),
    resetTokenTTL: Yup.number(),
    cookiesTTL: Yup.number(),
  });

  const [userSettingsViewModel, setUserSettingsViewModel] = useState({
    acceptSMSNotifications: getAppSettingsData.value.userSettings.acceptSMSNotifications,
    acceptEmailNotifications: getAppSettingsData.value.userSettings.acceptEmailNotifications,
    twoFactorAuthentication: getAppSettingsData.value.userSettings.twoFactorAuthentication,
    preferedNotificationChannel: getAppSettingsData.value.userSettings.preferedNotificationChannel,
    preferedLanguage: getAppSettingsData.value.userSettings.preferedLanguage,
    vibrateMode: getAppSettingsData.value.userSettings.vibrateMode,
  })

  const [timeAndLocaleSettingsViewModel, setTimeAndLocaleSettingsViewModel] = useState({
    language: getAppSettingsData.value.timeAndLocaleSettings.language,
    timeZoneId: getAppSettingsData.value.timeAndLocaleSettings.timeZoneId,
    datePattern: getAppSettingsData.value.timeAndLocaleSettings.datePattern,
    timePattern: getAppSettingsData.value.timeAndLocaleSettings.timePattern,
  })

  const [multiFactorAuthenticationSettingsViewModel, setMultiFactorAuthenticationSettingsViewModel] = useState({
    isEnableMulltiFactAuth: getAppSettingsData.value.multiFactorAuthenticationSettings.isEnable,
    pinLength: getAppSettingsData.value.multiFactorAuthenticationSettings.pinLength,
    pinTTL: getAppSettingsData.value.multiFactorAuthenticationSettings.pinTTL,
  })

  const [passwordPolicySettingsViewModel, setPasswordPolicySettingsViewModel] = useState({
    isEnablePasswordPolicy: getAppSettingsData.value.passwordPolicySettings.isEnable,
    durationPasswordPolicy: getAppSettingsData.value.passwordPolicySettings.duration,
    minimumLength: getAppSettingsData.value.passwordPolicySettings.minimumLength,
    alertUserToChangeFrom: getAppSettingsData.value.passwordPolicySettings.alertUserToChangeFrom,
    enforcePasswordHistory: getAppSettingsData.value.passwordPolicySettings.enforcePasswordHistory,
    passwordComplexityIsEnable: getAppSettingsData.value.passwordPolicySettings.passwordComplexityIsEnable,
    mustContainsAtLeastOneUppercase: getAppSettingsData.value.passwordPolicySettings.mustContainsAtLeastOneUppercase,
    mustContainsAtLeastOneLowercase: getAppSettingsData.value.passwordPolicySettings.mustContainsAtLeastOneLowercase,
    mustContainsAtLeastOneSpecialChar: getAppSettingsData.value.passwordPolicySettings.mustContainsAtLeastOneSpecialChar,
    mustContainsAtLeastOneDigit: getAppSettingsData.value.passwordPolicySettings.mustContainsAtLeastOneDigit,
  })

  const [cookiesSettingsViewModel, setCookiesSettingsViewModel] = useState({
    cookieConsentTimeFrame: getAppSettingsData.value.cookiesSettings.cookieConsentTimeFrame,
    domainCookiesSettings: getAppSettingsData.value.cookiesSettings.domain,
    httpOnlyCookiesSettings: getAppSettingsData.value.cookiesSettings.httpOnly,
  })

  const [keyVaultSettingsViewModel, setKeyVaultSettingsViewModel] = useState({
    isEnableKeyVault: getAppSettingsData.value.keyVaultSettings.isEnable,
    urlKeyVault: getAppSettingsData.value.keyVaultSettings.url,
    tenantId: getAppSettingsData.value.keyVaultSettings.tenantId,
    clientId: getAppSettingsData.value.keyVaultSettings.clientId,
    clientSecret: getAppSettingsData.value.keyVaultSettings.clientSecret,
  })

  const [jwtSettingsViewModel, setJwtSettingsViewModel] = useState({
    secret: getAppSettingsData.value.jwtSettings.secret,
    issuer: getAppSettingsData.value.jwtSettings.issuer,
    audience: getAppSettingsData.value.jwtSettings.audience,
    subject: getAppSettingsData.value.jwtSettings.subject,
    expiration: getAppSettingsData.value.jwtSettings.expiration,
    refreshTokenTTL: getAppSettingsData.value.jwtSettings.refreshTokenTTL,
    validateIssuer: getAppSettingsData.value.jwtSettings.validateIssuer,
    validateAudience: getAppSettingsData.value.jwtSettings.validateAudience,
    validateLifetime: getAppSettingsData.value.jwtSettings.validateLifetime,
    validateIssuerSigningKey: getAppSettingsData.value.jwtSettings.validateIssuerSigningKey,
    resetTokenTTL: getAppSettingsData.value.jwtSettings.resetTokenTTL,
    cookiesTTL: getAppSettingsData.value.jwtSettings.cookiesTTL,
  })
  const [errorsAppSettings, setErrorsAppSettings] = useState({
    acceptSMSNotifications: "",
    acceptEmailNotifications: "",
    twoFactorAuthentication: "",
    preferedNotificationChannel: "",
    preferedLanguage: "",
    vibrateMode: "",

    language: "",
    timeZoneId: "",
    datePattern: "",
    timePattern: "",

    isEnableMulltiFactAuth: "",
    pinLength: "",
    pinTTL: "",

    // passwordPolicySettings
    isEnablePasswordPolicy: "",
    durationPasswordPolicy: "",
    minimumLength: "",
    alertUserToChangeFrom: "",
    enforcePasswordHistory: "",
    passwordComplexityIsEnable: "",
    mustContainsAtLeastOneUppercase: "",
    mustContainsAtLeastOneLowercase: "",
    mustContainsAtLeastOneSpecialChar: "",
    mustContainsAtLeastOneDigit: "",

    // cookiesSettings
    cookieConsentTimeFrame: "",
    domainCookiesSettings: "",
    httpOnlyCookiesSettings: "",

    // keyVaultSettings
    isEnableKeyVault: "",
    urlKeyVault: "",
    tenantId: "",
    clientId: "",
    clientSecret: "",

    // jwtSettings
    secret: "",
    issuer: "",
    audience: "",
    subject: "",
    expiration: "",
    refreshTokenTTL: "",
    validateIssuer: "",
    validateAudience: "",
    validateLifetime: "",
    validateIssuerSigningKey: "",
    resetTokenTTL: "",
    cookiesTTL: "",
  });

  if (getAppSettingsData.value.key && !getAppSettingsData.pending && !actu) {
    setActu(true);
    setUserSettingsViewModel({
      acceptSMSNotifications: getAppSettingsData.value.userSettings.acceptSMSNotifications,
      acceptEmailNotifications: getAppSettingsData.value.userSettings.acceptEmailNotifications,
      twoFactorAuthentication: getAppSettingsData.value.userSettings.twoFactorAuthentication,
      preferedNotificationChannel: getAppSettingsData.value.userSettings.preferedNotificationChannel,
      preferedLanguage: getAppSettingsData.value.userSettings.preferedLanguage,
      vibrateMode: getAppSettingsData.value.userSettings.vibrateMode,
    })
    setTimeAndLocaleSettingsViewModel({
      language: getAppSettingsData.value.timeAndLocaleSettings.language,
      timeZoneId: getAppSettingsData.value.timeAndLocaleSettings.timeZoneId,
      datePattern: getAppSettingsData.value.timeAndLocaleSettings.datePattern,
      timePattern: getAppSettingsData.value.timeAndLocaleSettings.timePattern,
    })
    setMultiFactorAuthenticationSettingsViewModel({
      isEnableMulltiFactAuth: getAppSettingsData.value.multiFactorAuthenticationSettings.isEnable,
      pinLength: getAppSettingsData.value.multiFactorAuthenticationSettings.pinLength,
      pinTTL: getAppSettingsData.value.multiFactorAuthenticationSettings.pinTTL,
    })
    setPasswordPolicySettingsViewModel({
      isEnablePasswordPolicy: getAppSettingsData.value.passwordPolicySettings.isEnable,
      durationPasswordPolicy: getAppSettingsData.value.passwordPolicySettings.duration,
      minimumLength: getAppSettingsData.value.passwordPolicySettings.minimumLength,
      alertUserToChangeFrom: getAppSettingsData.value.passwordPolicySettings.alertUserToChangeFrom,
      enforcePasswordHistory: getAppSettingsData.value.passwordPolicySettings.enforcePasswordHistory,
      passwordComplexityIsEnable: getAppSettingsData.value.passwordPolicySettings.passwordComplexityIsEnable,
      mustContainsAtLeastOneUppercase: getAppSettingsData.value.passwordPolicySettings.mustContainsAtLeastOneUppercase,
      mustContainsAtLeastOneLowercase: getAppSettingsData.value.passwordPolicySettings.mustContainsAtLeastOneLowercase,
      mustContainsAtLeastOneSpecialChar: getAppSettingsData.value.passwordPolicySettings.mustContainsAtLeastOneSpecialChar,
      mustContainsAtLeastOneDigit: getAppSettingsData.value.passwordPolicySettings.mustContainsAtLeastOneDigit,
    })
    setCookiesSettingsViewModel({
      cookieConsentTimeFrame: getAppSettingsData.value.cookiesSettings.cookieConsentTimeFrame,
      domainCookiesSettings: getAppSettingsData.value.cookiesSettings.domain,
      httpOnlyCookiesSettings: getAppSettingsData.value.cookiesSettings.httpOnly,
    })
    setKeyVaultSettingsViewModel({
      isEnableKeyVault: getAppSettingsData.value.keyVaultSettings.isEnable,
      urlKeyVault: getAppSettingsData.value.keyVaultSettings.url,
      tenantId: getAppSettingsData.value.keyVaultSettings.tenantId,
      clientId: getAppSettingsData.value.keyVaultSettings.clientId,
      clientSecret: getAppSettingsData.value.keyVaultSettings.clientSecret,
    })
    setJwtSettingsViewModel({
      secret: getAppSettingsData.value.jwtSettings.secret,
      issuer: getAppSettingsData.value.jwtSettings.issuer,
      audience: getAppSettingsData.value.jwtSettings.audience,
      subject: getAppSettingsData.value.jwtSettings.subject,
      expiration: getAppSettingsData.value.jwtSettings.expiration,
      refreshTokenTTL: getAppSettingsData.value.jwtSettings.refreshTokenTTL,
      validateIssuer: getAppSettingsData.value.jwtSettings.validateIssuer,
      validateAudience: getAppSettingsData.value.jwtSettings.validateAudience,
      validateLifetime: getAppSettingsData.value.jwtSettings.validateLifetime,
      validateIssuerSigningKey: getAppSettingsData.value.jwtSettings.validateIssuerSigningKey,
      resetTokenTTL: getAppSettingsData.value.jwtSettings.resetTokenTTL,
      cookiesTTL: getAppSettingsData.value.jwtSettings.cookiesTTL,
    })
  }

  const handleAppSettings = async (e) => {
    e.preventDefault();
    setErrorsAppSettings({
      ...errorsAppSettings,
      acceptSMSNotifications: "",
      acceptEmailNotifications: "",
      twoFactorAuthentication: "",
      preferedNotificationChannel: "",
      preferedLanguage: "",
      vibrateMode: "",

      language: "",
      timeZoneId: "",
      datePattern: "",
      timePattern: "",

      isEnableMulltiFactAuth: "",
      pinLength: "",
      pinTTL: "",

      // passwordPolicySettings
      isEnablePasswordPolicy: "",
      durationPasswordPolicy: "",
      minimumLength: "",
      alertUserToChangeFrom: "",
      enforcePasswordHistory: "",
      passwordComplexityIsEnable: "",
      mustContainsAtLeastOneUppercase: "",
      mustContainsAtLeastOneLowercase: "",
      mustContainsAtLeastOneSpecialChar: "",
      mustContainsAtLeastOneDigit: "",

      // cookiesSettings
      cookieConsentTimeFrame: "",
      domainCookiesSettings: "",
      httpOnlyCookiesSettings: "",

      // keyVaultSettings
      isEnableKeyVault: "",
      urlKeyVault: "",
      tenantId: "",
      clientId: "",
      clientSecret: "",

      // jwtSettings
      secret: "",
      issuer: "",
      audience: "",
      subject: "",
      expiration: "",
      refreshTokenTTL: "",
      validateIssuer: "",
      validateAudience: "",
      validateLifetime: "",
      validateIssuerSigningKey: "",
      resetTokenTTL: "",
      cookiesTTL: "",
    });

    const valuesTimeLocale = await schemaTimeLocale.validate(timeAndLocaleSettingsViewModel);
    const valuesMultiFact = await schemaMultiFact.validate(multiFactorAuthenticationSettingsViewModel);
    const valuesPassword = await schemaPasswordPolicy.validate(passwordPolicySettingsViewModel);
    const valuesCookies = await schemaCookies.validate(cookiesSettingsViewModel);
    const valuesKeyVault = await schemaKeyVault.validate(keyVaultSettingsViewModel);
    const valuesJwt = await schemaJwt.validate(jwtSettingsViewModel);

    if (valuesTimeLocale.language === "" || valuesTimeLocale.datePattern === "" || valuesTimeLocale.timePattern === "" ||
      valuesTimeLocale.timeZoneId === "" ||
      ((role === 'Administrator' || role === 'SuperAdmin') && (valuesMultiFact.pinLength === 0 ||
        valuesMultiFact.pinTTL === 0 || valuesPassword.durationPasswordPolicy === 0 ||
        valuesPassword.minimumLength === 0 || valuesPassword.alertUserToChangeFrom === 0)) ||
      (role === 'SuperAdmin' && (valuesCookies.cookieConsentTimeFrame === 0 || valuesCookies.domainCookiesSettings === "" ||
        valuesKeyVault.urlKeyVault === "" || valuesKeyVault.tenantId === "" || valuesKeyVault.clientId === "" ||
        valuesKeyVault.clientSecret === "" || valuesJwt.issuer === "" || valuesJwt.cookiesTTL === 0 ||
        valuesJwt.audience === "" || valuesJwt.subject === "" || valuesJwt.expiration === 0 || valuesJwt.refreshTokenTTL === 0 ||
        valuesJwt.resetTokenTTL === 0 || valuesJwt.secret === ""))) {
      let languageError = "", dateError = "", timePatternError = "", timeZoneError = "", pinError = "", pinTTLError = "", durationError = "", minLenPassError = "", alertUserPassError = "", domainError = "",
        cookieConsentError = "", urlError = "", tenantError = "", clientIdError = "", clientSecretError = "", secretError = "",
        issuerError = "", audienceError = "", subjectError = "", expirationError = "", refreshTokenTTLError = "",
        resetTokenTTLError = "", cookiesTTLError = "";

      if (valuesTimeLocale.language === "")
        languageError = commonLocalizer("MODULE_COMMON_WEB_SETTINGS_TIMES_AND_LOCALES_APP_LANGUAGE_IS_REQUIRED");
      if (valuesTimeLocale.datePattern === "")
        dateError = commonLocalizer("MODULE_COMMON_WEB_SETTINGS_TIMES_AND_LOCALES_DATE_FORMAT_IS_REQUIRED");
      if (valuesTimeLocale.timePattern === "")
        timePatternError = commonLocalizer("MODULE_COMMON_WEB_SETTINGS_TIMES_AND_LOCALES_TIMEZONE_IS_REQUIRED");
      if (valuesTimeLocale.timeZoneId === "")
        timeZoneError = commonLocalizer("MODULE_COMMON_WEB_SETTINGS_TIMES_AND_LOCALES_TIME_FORMAT_IS_REQUIRED");
      if (valuesMultiFact.pinTTL === 0)
        pinError = commonLocalizer("MODULE_COMMON_WEB_SETTINGS_2FA_VALUE_MUST_BE_GREATHER_THAN_ZERO");
      if (valuesMultiFact.pinLength === 0)
        pinTTLError = commonLocalizer("MODULE_COMMON_WEB_SETTINGS_2FA_VALUE_MUST_BE_GREATHER_THAN_ZERO");

      if (valuesPassword.durationPasswordPolicy === 0)
        durationError = commonLocalizer("MODULE_COMMON_WEB_SETTINGS_PASSWORD_POLICY_MUST_BE_GREATHER_THANT_ZERO");
      if (valuesPassword.minimumLength === 0)
        minLenPassError = commonLocalizer("MODULE_COMMON_WEB_SETTINGS_PASSWORD_POLICY_MUST_BE_GREATHER_THANT_ZERO");
      if (valuesPassword.alertUserToChangeFrom === 0)
        alertUserPassError = commonLocalizer("MODULE_COMMON_WEB_SETTINGS_PASSWORD_POLICY_MUST_BE_GREATHER_THANT_ZERO");

      if (valuesCookies.domainCookiesSettings === "")
        domainError = commonLocalizer("MODULE_COMMON_WEB_SETTINGS_SUBGROUP_COOKIES_DOMAIN_IS_REQUIRED");
      if (valuesCookies.cookieConsentTimeFrame === 0)
        cookieConsentError = commonLocalizer("MODULE_COMMON_WEB_SETTINGS_SUBGROUP_COOKIES_DELAI_IS_REQUIRED");

      if (valuesKeyVault.urlKeyVault === "")
        urlError = commonLocalizer("MODULE_COMMON_WEB_SETTINGS_AZURE_KEY_VAULT_URL_IS_REQUIRED");
      if (valuesKeyVault.tenantId === "")
        tenantError = commonLocalizer("MODULE_COMMON_WEB_SETTINGS_AZURE_KEY_VAULT_TENANT_ID_IS_REQUIRED");
      if (valuesKeyVault.clientId === "")
        clientIdError = commonLocalizer("MODULE_COMMON_WEB_SETTINGS_AZURE_KEY_VAULT_CLIENT_ID_IS_REQUIRED");
      if (valuesKeyVault.clientSecret === "")
        clientSecretError = commonLocalizer("MODULE_COMMON_WEB_SETTINGS_AZURE_KEY_VAULT_CLIENT_SECRET_IS_REQUIRED");

      if (valuesJwt.secret === "")
        secretError = commonLocalizer("MODULE_COMMON_WEB_SETTINGS_JWT_SECRET_IS_REQUIRED");
      if (valuesJwt.issuer === "")
        issuerError = commonLocalizer("MODULE_COMMON_WEB_SETTINGS_JWT_PUBLIC_IS_REQUIRED");
      if (valuesJwt.audience === "")
        audienceError = commonLocalizer("MODULE_COMMON_WEB_SETTINGS_JWT_AUDIENCE_IS_REQUIRED");
      if (valuesJwt.subject === "")
        subjectError = commonLocalizer("MODULE_COMMON_WEB_SETTINGS_JWT_SUBJECT_IS_REQUIRED");
      if (valuesJwt.expiration === 0)
        expirationError = commonLocalizer("MODULE_COMMON_WEB_SETTINGS_JWT_EXPIRES_IS_REQUIRED");
      if (valuesJwt.refreshTokenTTL === 0)
        refreshTokenTTLError = commonLocalizer("MODULE_COMMON_WEB_SETTINGS_JWT_REFRESH_TOKEN_IS_REQUIRED");
      if (valuesJwt.resetTokenTTL === 0)
        resetTokenTTLError = commonLocalizer("MODULE_COMMON_WEB_SETTINGS_JWT_RESET_TOKEN_EXPIRES_IS_REQUIRED");
      if (valuesJwt.cookiesTTL === 0)
        cookiesTTLError = commonLocalizer("MODULE_COMMON_WEB_SETTINGS_JWT_COOKIES_EXPIRES_IS_REQUIRED");
      setErrorsAppSettings({
        ...errorsAppSettings,
        language: languageError,
        datePattern: dateError,
        timePattern: timePatternError,
        timeZoneId: timeZoneError,
        pinLength: pinTTLError,
        pinTTL: pinError,
        durationPasswordPolicy: durationError,
        minimumLength: minLenPassError,
        alertUserToChangeFrom: alertUserPassError,
        domainCookiesSettings: domainError,
        cookieConsentTimeFrame: cookieConsentError,
        urlKeyVault: urlError,
        tenantId: tenantError,
        clientId: clientIdError,
        clientSecret: clientSecretError,
        secret: secretError,
        issuer: issuerError,
        audience: audienceError,
        subject: subjectError,
        expiration: expirationError,
        refreshTokenTTL: refreshTokenTTLError,
        resetTokenTTL: resetTokenTTLError,
        cookiesTTL: cookiesTTLError,
      });
    } else {

      const appSettingsCommand = {
        isAdministrator: true,
        userSettings: {
          acceptSMSNotifications: userSettingsViewModel.acceptSMSNotifications ?? false,
          acceptEmailNotifications: userSettingsViewModel.acceptEmailNotifications ?? false,
          twoFactorAuthentication: userSettingsViewModel.twoFactorAuthentication ?? false,
          preferedNotificationChannel: userSettingsViewModel.preferedNotificationChannel,
          preferedLanguage: userSettingsViewModel.preferedLanguage,
          vibrateMode: userSettingsViewModel.vibrateMode ?? false,
        },

        timeAndLocaleSettings: {
          language: timeAndLocaleSettingsViewModel.language,
          timeZoneId: timeAndLocaleSettingsViewModel.timeZoneId,
          datePattern: timeAndLocaleSettingsViewModel.datePattern,
          timePattern: timeAndLocaleSettingsViewModel.timePattern,
        },
        multiFactorAuthenticationSettings: {
          isEnable: multiFactorAuthenticationSettingsViewModel.isEnableMulltiFactAuth ?? false,
          pinLength: multiFactorAuthenticationSettingsViewModel.pinLength,
          pinTTL: multiFactorAuthenticationSettingsViewModel.pinTTL,
        },
        passwordPolicySettings: {
          isEnable: passwordPolicySettingsViewModel.isEnablePasswordPolicy ?? false,
          duration: passwordPolicySettingsViewModel.durationPasswordPolicy,
          minimumLength: passwordPolicySettingsViewModel.minimumLength,
          alertUserToChangeFrom: passwordPolicySettingsViewModel.alertUserToChangeFrom,
          enforcePasswordHistory: passwordPolicySettingsViewModel.enforcePasswordHistory ?? false,
          passwordComplexityIsEnable: passwordPolicySettingsViewModel.passwordComplexityIsEnable ?? false,
          mustContainsAtLeastOneUppercase: passwordPolicySettingsViewModel.mustContainsAtLeastOneUppercase ?? false,
          mustContainsAtLeastOneLowercase: passwordPolicySettingsViewModel.mustContainsAtLeastOneLowercase ?? false,
          mustContainsAtLeastOneSpecialChar: passwordPolicySettingsViewModel.mustContainsAtLeastOneSpecialChar ?? false,
          mustContainsAtLeastOneDigit: passwordPolicySettingsViewModel.mustContainsAtLeastOneDigit ?? false,
        },

        cookiesSettings: {
          cookieConsentTimeFrame: cookiesSettingsViewModel.cookieConsentTimeFrame,
          domain: cookiesSettingsViewModel.domainCookiesSettings,
          httpOnly: cookiesSettingsViewModel.httpOnlyCookiesSettings ?? false,
        },
        keyVaultSettings: {
          isEnable: keyVaultSettingsViewModel.isEnableKeyVault ?? false,
          url: keyVaultSettingsViewModel.urlKeyVault,
          tenantId: keyVaultSettingsViewModel.tenantId,
          clientId: keyVaultSettingsViewModel.clientId,
          clientSecret: keyVaultSettingsViewModel.clientSecret,
        },
        jwtSettings: {
          secret: jwtSettingsViewModel.secret,
          issuer: jwtSettingsViewModel.issuer,
          audience: jwtSettingsViewModel.audience,
          subject: jwtSettingsViewModel.subject,
          expiration: jwtSettingsViewModel.expiration,
          refreshTokenTTL: jwtSettingsViewModel.refreshTokenTTL,
          validateIssuer: jwtSettingsViewModel.validateIssuer ?? false,
          validateAudience: jwtSettingsViewModel.validateAudience ?? false,
          validateLifetime: jwtSettingsViewModel.validateLifetime ?? false,
          validateIssuerSigningKey: jwtSettingsViewModel.validateIssuerSigningKey ?? false,
          resetTokenTTL: jwtSettingsViewModel.resetTokenTTL,
          cookiesTTL: jwtSettingsViewModel.cookiesTTL,
        }
      }
      dispatch(updateAppSettings(appSettingsCommand as UpdateAppSettingsCommand));
    }
  };

  window.document.title = commonLocalizer("MODULE_COMMON_WEB_SETTINGS_TITLE");

  return (
    <div className="h-full flex flex-col justify-between app-settings">
      {updateAppSettingsData.Errors &&
        updateAppSettingsData.Errors.length > 0 &&
        !updateAppSettingsData.pending &&
        updateAppSettingsData.Errors.map((message, key) => {
          return (
            <div className="w-full mx-auto mb-auto" key={key}>
              <MessageComponent
                showCloseIcon
                id="msg_error"
                className="errorServer m-1"
                content={message}
                key={key}
                severity="Error"
              ></MessageComponent>
            </div>
          );
        })}
      {getAppSettingsData.Errors &&
        getAppSettingsData.Errors.length > 0 &&
        !getAppSettingsData.pending &&
        getAppSettingsData.Errors.map((message, key) => {
          return (
            <div className="w-full mx-auto my-2" key={key}>
              <MessageComponent
                showCloseIcon
                id="msg_error"
                className="errorServer m-1"
                content={message}
                key={key}
                severity="Error"
              ></MessageComponent>
            </div>
          );
        })}

      {updateAppSettingsData.value && !updateAppSettingsData.pending ? (
        <div className="absolute left-[35%] top-[35%] w-1/2 mx-auto">
          <OperationResultComponent
            message={commonLocalizer("MODULE_COMMON_WEB_SETTINGS_MESSAGES_YOU_UPDATED_SUCCESSFULLY")}
            title={commonLocalizer("MODULE_COMMON_WEB_SETTINGS_MESSAGES_UPDATED_SUCCESSFULLY")}
            titleButton={commonLocalizer("MODULE_COMMON_WEB_SETTINGS_BACK")}
            linkButton="/app-settings"
          />
        </div>
      ) : (
        <>
          <div className={` ${ClasseName.TITLE} `}>
            <h1 className="">{commonLocalizer("MODULE_COMMON_WEB_SETTINGS_TITLE")}</h1>
            <Breadcrumb items={[{ title: commonLocalizer("MODULE_COMMON_SIDEBAR_DASHBOARD"), link: "/dashboard" }, { title: commonLocalizer("MODULE_COMMON_WEB_SETTINGS_TITLE") }]} />
          </div>
          <div className={`h-full mx-auto pt-5 pb-2 xl:w-11/12 xmd:w-full xxs:w-11/12 xl:px-0 xmd:px-2 xxs:px-0`}>
            <form className={`card-component-settings min-h-[calc(100vh-220px)] h-auto flex flex-col justify-between gap-0 my-0 xl:px-8 xmd:px-0 xxs:px-4 w-11/12 mx-auto`} onSubmit={handleAppSettings}>

              <TabComponent
                id="appSettingsTab"
                cssClass="border-0 border-transparent p-0"
                animation={animateSidebar}
                ref={tabInstance}
              >
                <TabItemsDirective>
                  <TabItemDirective header={headertext[0]} content={() => <UserSettings errorsAppSettings={errorsAppSettings} viewModel={userSettingsViewModel} setViewModel={setUserSettingsViewModel} />} />
                  {(role === 'Administrator' || role === 'SuperAdmin') && <TabItemDirective header={headertext[1]} content={() => <TimeAndLocaleSettings errorsAppSettings={errorsAppSettings} viewModel={timeAndLocaleSettingsViewModel} setViewModel={setTimeAndLocaleSettingsViewModel} />} />}
                  {(role === 'Administrator' || role === 'SuperAdmin') && <TabItemDirective header={headertext[2]} content={() => <MultiFactorAuthSettings errorsAppSettings={errorsAppSettings} viewModel={multiFactorAuthenticationSettingsViewModel} setViewModel={setMultiFactorAuthenticationSettingsViewModel} />} />}
                  {(role === 'Administrator' || role === 'SuperAdmin') && <TabItemDirective header={headertext[3]} content={() => <PasswordPolicySettings errorsAppSettings={errorsAppSettings} viewModel={passwordPolicySettingsViewModel} setViewModel={setPasswordPolicySettingsViewModel} />} />}
                  {(role === 'SuperAdmin') && <TabItemDirective header={headertext[4]} content={() => <CookiesSettings errorsAppSettings={errorsAppSettings} viewModel={cookiesSettingsViewModel} setViewModel={setCookiesSettingsViewModel} />} />}
                  {(role === 'SuperAdmin') && <TabItemDirective header={headertext[5]} content={() => <KeyVaultSettings errorsAppSettings={errorsAppSettings} viewModel={keyVaultSettingsViewModel} setViewModel={setKeyVaultSettingsViewModel} />} />}
                  {(role === 'SuperAdmin') && <TabItemDirective header={headertext[6]} content={() => <JwtSettings errorsAppSettings={errorsAppSettings} viewModel={jwtSettingsViewModel} setViewModel={setJwtSettingsViewModel} />} />}
                </TabItemsDirective>
              </TabComponent>

              <div className="flex flex-col gap-4 mt-auto h-12 items-end justify-end footer">
                <Button
                  param={{
                    type: "button",
                    css: (updateAppSettingsData.pending ? "disabled" : "") + " okBtn px-5 py-1 h-12 rounded-md text-sm",
                    name: commonLocalizer("MODULE_COMMON_WEB_SETTINGS_VALIDATE"),
                    disabled: updateAppSettingsData.pending,
                    handleClick: handleAppSettings
                  }}
                />
              </div>
            </form>
          </div>
        </>
      )}
    </div>
  );
};

export default AppSettings;
