import { useDebounced } from "src/app/core/hooks";
import { HttpClient } from "../../../../http/http-client";

const addAgency = (http: HttpClient) => async (payload: object) => {
  const response = await http.post("/v1/branches/save", payload);
  const result: AddAgency = response.data;
  
  return response !== undefined ? (result as AddAgency) : undefined;
};

const updateAgency = (http: HttpClient) => async (payload: object) => {
  const response = await http.post("/v1/branches/save", payload);
  const result: UpdateAgency = response.data;
  
  return response !== undefined ? (result as UpdateAgency) : undefined;
};

const deleteAgency = (http: HttpClient) => async (payload: object) => {
  const response = await http.delete("/v1/branches/delete", payload);
  const result: DeleteAgency = response.data;
  
  return response !== undefined ? (result as DeleteAgency) : undefined;
};

const getAgencies = (http: HttpClient) => async () => {
  const response = await http.get("/v1/branches/get-all");
  const result: GetAgencies = response.data;

  return response !== undefined ? (result as GetAgencies) : undefined;
};

const getAgency = (http: HttpClient) => async (payload: object) => {
  const response = await http.get("/v1/branches/get", payload);
  const result: GetAgency = response.data;

  return response !== undefined ? (result as GetAgency) : undefined;
};

export class ControllerApi {
  private readonly http = new HttpClient();

  public readonly addAgency = Object.assign(addAgency(this.http), {
    useResponse: (
      handler: (result: AddAgency) => unknown,
      args: Parameters<ReturnType<typeof addAgency>>[0]
    ) => useDebounced(() => this.addAgency(args).then(handler), Object.values(args), 500),
  });

  public readonly updateAgency = Object.assign(updateAgency(this.http), {
    useResponse: (
      handler: (result: UpdateAgency) => unknown,
      args: Parameters<ReturnType<typeof updateAgency>>[0]
    ) => useDebounced(() => this.updateAgency(args).then(handler), Object.values(args), 500),
  });
  

  public readonly deleteAgency = Object.assign(deleteAgency(this.http), {
    useResponse: (
      handler: (result: DeleteAgency) => unknown,
      args: Parameters<ReturnType<typeof deleteAgency>>[0]
    ) => useDebounced(() => this.deleteAgency(args).then(handler), Object.values(args), 500),
  });
  
  public readonly getAgencies = Object.assign(getAgencies(this.http), {
    useResponse: (
      handler: (result: GetAgencies) => unknown,
      args: Parameters<ReturnType<typeof getAgencies>>[]
    ) => useDebounced(() => this.getAgencies().then(handler), Object.values(args), 500),
  });
  
  public readonly getAgency = Object.assign(getAgency(this.http), {
    useResponse: (
      handler: (result: GetAgency) => unknown,
      args: Parameters<ReturnType<typeof getAgency>>[0]
    ) => useDebounced(() => this.getAgency(args).then(handler), Object.values(args), 500),
  });

}