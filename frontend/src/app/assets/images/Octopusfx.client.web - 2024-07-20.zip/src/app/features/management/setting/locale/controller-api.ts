import { useDebounced } from "src/app/core/hooks";
import { HttpClient } from "../../../../http/http-client";

const updateTenantPreferences = (http: HttpClient) => async (payload: object) => {
  const response = await http.post("/v1/tenantpreferences/save", payload);
  const result: UpdateUserPreferencesResult = response.data;
  
  return response !== undefined ? (result as UpdateUserPreferencesResult) : undefined;
};

const getTenantPreferences = (http: HttpClient) => async (payload: string) => {
  const response = await http.get("/v1/tenantpreferences/get");
  const result: GetUserPreferences = response.data;

  return response !== undefined ? (result as GetUserPreferences) : undefined;
};

export class ControllerApi {
  private readonly http = new HttpClient();
  public readonly updateTenantPreferences = Object.assign(updateTenantPreferences(this.http), {
    useResponse: (
      handler: (result: UpdateUserPreferencesResult) => unknown,
      args: Parameters<ReturnType<typeof updateTenantPreferences>>[0]
    ) => useDebounced(() => this.updateTenantPreferences(args).then(handler), Object.values(args), 500),
  });
  
  public readonly getTenantPreferences = Object.assign(getTenantPreferences(this.http), {
    useResponse: (
      handler: (result: GetUserPreferences) => unknown,
      args: Parameters<ReturnType<typeof getTenantPreferences>>[0]
    ) => useDebounced(() => this.getTenantPreferences(args).then(handler), Object.values(args), 500),
  });

}