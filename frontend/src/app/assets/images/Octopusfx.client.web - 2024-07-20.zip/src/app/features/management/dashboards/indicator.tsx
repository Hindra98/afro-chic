
import 'src/app/styles/components/_indicator.scss'

type Indicator = {
  label?: string;
  value?: string | number;
  color?: string;
}

const Indicators = (props: Indicator) => {
  return (
    <div className={`indicator ${props?.label} flex flex-col gap-1 border-s-[6px] ps-2 ${props?.color}`}>
      <span className={` `}>{props?.label}</span>
      <span className={` ${props?.color} font-bold text-xl `}>{props?.value}</span>
    </div>
  )
}

export default Indicators