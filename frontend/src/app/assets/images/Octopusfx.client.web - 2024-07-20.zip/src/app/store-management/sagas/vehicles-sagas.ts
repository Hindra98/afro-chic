
import { call, put, takeLatest } from "redux-saga/effects";
import { ActionTypes } from "../actions/constants/action-types";
import { DeleteVehicleAction, DeleteVehicleFailurePayload, DeleteVehicleSuccessPayload, GetVehicleAction, GetVehicleFailurePayload, GetVehiclesFailurePayload, UpdateVehicleAction, UpdateVehicleFailurePayload, UpdateVehicleSuccessPayload } from "../actions/vehicles";
import { deleteVehicleFailure, deleteVehicleSuccess, getVehicleFailure, getVehiclesFailure, getVehiclesSuccess, getVehicleSuccess, updateVehicleFailure, updateVehicleSuccess } from "../actions/vehicles/vehicles-actions";
import { ControllerApi } from "src/app/features/management/vehicles/locale/controller-api";

const controllerApi = new ControllerApi();

const callApiToUpdateVehicles = async (command: FormData) => controllerApi.updateVehicle(command);
const callApiToDeleteVehicles = async (command: DeleteVehicleCommand) => controllerApi.deleteVehicle(command);
const callApiToGetVehicles = async () => controllerApi.getVehicles();
const callApiToGetVehicle = async (command: VehicleCommand) => controllerApi.getVehicle(command);

function* updateVehicleSaga(action: UpdateVehicleAction) {
  try {
    const response = yield call(callApiToUpdateVehicles, action.payload.command);
    if (response) {
      if (response?.hasSucceeded) {
        yield put(updateVehicleSuccess({ value: true } as UpdateVehicleSuccessPayload));
        const responseGetVehicle = yield call(callApiToGetVehicles);
        if (responseGetVehicle) {
          yield put(getVehiclesSuccess(responseGetVehicle as GetVehicles));
        } else {
          let messages: string[] = [];
          responseGetVehicle?.errorMessages.map((item) => {
            return messages.push(item.errorMessage);
          });
          yield put(getVehiclesFailure({ errors: messages } as GetVehiclesFailurePayload));
        }
      } else {
        let messages: string[] = [];
        response.errorMessages.map((item) => {
          return messages.push(item.errorMessage);
        });
        yield put(updateVehicleFailure({ errors: messages } as UpdateVehicleFailurePayload));
      }
    } else {
      let messages: string[] = [];
      messages.push("Erreur lors de la connexion au serveur");
      yield put(updateVehicleFailure({ errors: messages } as UpdateVehicleFailurePayload));
    }
  } catch (e) {
    let messages: string[] = [];
    messages.push(e.message);
    yield put(updateVehicleFailure({ errors: messages } as UpdateVehicleFailurePayload));
  }
}

function* deleteVehicleSaga(action: DeleteVehicleAction) {
  try {
    const response = yield call(callApiToDeleteVehicles, action.payload.command);
    if (response) {
      if (response?.hasSucceeded) {
        yield put(deleteVehicleSuccess({ value: true } as DeleteVehicleSuccessPayload));
        const responseGetVehicle = yield call(callApiToGetVehicles);
        if (responseGetVehicle) {
          yield put(getVehiclesSuccess(responseGetVehicle as GetVehicles));
        } else {
          let messages: string[] = [];
          responseGetVehicle?.errorMessages.map((item) => {
            return messages.push(item.errorMessage);
          });
          yield put(getVehiclesFailure({ errors: messages } as GetVehiclesFailurePayload));
        }
      } else {
        let messages: string[] = [];
        response.errorMessages.map((item) => {
          return messages.push(item.errorMessage);
        });
        yield put(deleteVehicleFailure({ errors: messages } as DeleteVehicleFailurePayload));
      }
    } else {
      let messages: string[] = [];
      messages.push("Erreur lors de la connexion au serveur");
      yield put(deleteVehicleFailure({ errors: messages } as DeleteVehicleFailurePayload));
    }
  } catch (e) {
    let messages: string[] = [];
    messages.push(e.message);
    yield put(deleteVehicleFailure({ errors: messages } as DeleteVehicleFailurePayload));
  }
}

function* getVehiclesSaga() {
  try {
    const response = yield call(callApiToGetVehicles);
    if (response) {
      yield put(getVehiclesSuccess(response as GetVehicles));
    } else {
      let messages: string[] = [];
      response?.errorMessages.map((item) => {
        return messages.push(item.errorMessage);
      });
      yield put(getVehiclesFailure({ errors: messages } as GetVehiclesFailurePayload));
    }

  } catch (e) {
    let messages: string[] = [];
    messages.push(e.message);
    yield put(getVehiclesFailure({ errors: messages } as GetVehiclesFailurePayload));
  }
}

function* getVehicleSaga(action: GetVehicleAction) {
  try {
    const response = yield call(callApiToGetVehicle, action.payload.command);
    if (response) {
      yield put(getVehicleSuccess(response as GetVehicle));
    } else {
      let messages: string[] = [];
      response?.errorMessages.map((item) => {
        return messages.push(item.errorMessage);
      });
      yield put(getVehicleFailure({ errors: messages } as GetVehicleFailurePayload));
    }

  } catch (e) {
    let messages: string[] = [];
    messages.push(e.message);
    yield put(getVehicleFailure({ errors: messages } as GetVehicleFailurePayload));
  }
}

export function* watchVehiclesSaga(){
  yield takeLatest(ActionTypes.VEHICLES_REQUEST, getVehiclesSaga);
  yield takeLatest(ActionTypes.VEHICLE_REQUEST, getVehicleSaga);
  yield takeLatest(ActionTypes.UPDATE_VEHICLE_REQUEST, updateVehicleSaga);
  yield takeLatest(ActionTypes.DELETE_VEHICLE_REQUEST, deleteVehicleSaga);
}