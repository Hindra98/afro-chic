
export const useAppSize = () => ({ width: window.innerWidth, height: window.innerHeight });