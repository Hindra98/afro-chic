export interface UpdateUserPreferencesStoreShape {
  pending: boolean;
  Errors: string[];
  value: boolean;
}
export let initialStateUpdateUserPreferences: UpdateUserPreferencesStoreShape =
  {
    value: false,
    pending: false,
    Errors: [],
  };

export interface UpdateUserPreferencesModelShape {
  command: UpdateUserPreferencesCommand;
}
export interface UpdateUserPreferencesFailurePayload {
  errors: string[];
}
export interface UpdateUserPreferencesSuccessPayload {
  value: boolean;
}
export interface UpdateUserPreferencesRequest {
  type: string;
  payload: UpdateUserPreferencesCommand;
}
export interface UpdateUserPreferencesFailure {
  type: string;
  payload: UpdateUserPreferencesFailurePayload;
}
export interface UpdateUserPreferencesSuccess {
  type: string;
  payload: UpdateUserPreferencesSuccessPayload;
}
export interface UpdateUserPreferencesPayload {
  command: UpdateUserPreferencesCommand;
  value: UpdateUserPreferencesSuccessPayload;
  errors: UpdateUserPreferencesFailurePayload;
}
export interface UpdateUserPreferencesAction {
  type: string;
  payload: UpdateUserPreferencesPayload;
}

export interface GetUserPreferencesStoreShape {
  pending: boolean;
  Errors: string[];
  value: GetUserPreferences;
  errServer: ServerErrorMessageItem;
}
export let getUserPreferencesInitialState: GetUserPreferencesStoreShape = {
  value: {
    payload: {
      notificationChannel: "",
      notificationChannelLabel: "",
      language: "",
      timeZone: "",
      datePattern: "",
      timePattern: "",
      userId: "",
      IsPhoneNumberSet: false,
      IsEmailAddressSet: false,
    } as GetUserPreferencesResultPayload,
    timeZones: [
      {
        id: "",
        displayName: "",
        daylightName: "",
      } as GetUserPreferencesResultTimezone
    ],
    languages: [
      {
        id: "",
        displayName: "",
        threeLetterISOLanguageName: "",
        twoLetterISOLanguageName: "",
      } as GetUserPreferencesResultLanguages
    ],
    datePatterns: [
      {
        id: "",
        displayName: "",
        description: "",
        template: "",
      } as GetUserPreferencesResultDatePatterns
    ],
  },
  pending: false,
  Errors: [],
  errServer: {
    detail: "",
    instance: "",
    message: "",
    status: 0,
    title: "",
    type: ""
  } as ServerErrorMessageItem,
};

export interface GetUserPreferencesModelShape {
  command: string;
}
export interface GetUserPreferencesFailurePayload {
  errors: string[];
}
export interface GetUserPreferencesRequest {
  type: string;
  payload: string;
}
export interface GetUserPreferencesSuccess {
  type: string;
  payload: GetUserPreferences;
}
export interface GetUserPreferencesFailure {
  type: string;
  payload: GetUserPreferencesFailurePayload;
}
export interface GetUserPreferencesPayload {
  command: string;
  user: GetUserPreferences;
  errors: GetUserPreferencesFailurePayload;
  errServer: ServerErrorMessageItem;
}
export interface GetUserPreferencesAction {
  type: string;
  payload: GetUserPreferencesPayload;
}
