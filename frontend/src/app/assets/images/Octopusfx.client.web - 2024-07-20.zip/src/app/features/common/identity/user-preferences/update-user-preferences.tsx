import { useState } from "react";
import { useNavigate } from "react-router-dom";
import * as Yup from "yup";
import Button from "src/app/components/form/Button";
import { useAppDispatch, useAppSelector } from "src/app/core/hooks/core-hooks";
import { MessageComponent } from "@syncfusion/ej2-react-notifications";
import OperationResultComponent from "src/app/components/shared/operation-result-component";
import { ChangeEventArgs } from "@syncfusion/ej2/dropdowns";
import { DropDownListComponent } from "@syncfusion/ej2-react-dropdowns";
import { getUserPreferences, updateUserPreferences } from '../../../../store-management/actions/user-preferences/user-preferences-actions';
import { ShimmerText } from "src/app/components/shared/shimmer";
import { ClasseName } from "src/app/core/constants/class-name";
import { useLocalizer } from "src/app/core/Localization";
import { SwitchComponent } from "@syncfusion/ej2-react-buttons";
import Breadcrumb from "src/app/components/shared/breadcrumb";
import { getMyProfile } from "src/app/store-management/actions/myprofile/my-profil-actions";
import "../../../../styles/_user-preferences.scss";

type ItemFields = {
  text: string;
  value: string;
  iconCss: string;
};

const UpdateUserPreferences = () => {
  const commonLocalizer = useLocalizer("Common-ResCommon");

  const dispatch = useAppDispatch();
  const updateUserPreference = useAppSelector((state) => state.updateUserPreferences);
  const getUserPreference = useAppSelector((state) => state.getUserPreferences);
  const getUserData = useAppSelector((state) => state.myProfileGetData);

  const [getUne, setGetUne] = useState(false);

  const getDataUser = () => {
    dispatch(getMyProfile(""));
    dispatch(getUserPreferences(""));
  };

  if (!getUne && !getUserPreference.pending && getUserPreference.Errors.length === 0) {
    getDataUser();
    setGetUne(true);
  }

  const navigate = useNavigate();

  const schema = Yup.object().shape({
    language: Yup.string(),
    notificationChannel: Yup.string(),
    timeZone: Yup.string(),
    datePattern: Yup.string(),
    timePattern: Yup.string(),
  });

  const [actu, setActu] = useState(false);

  const [userPreferencesViewModel, setUserPreferencesViewModel] = useState({
    language: getUserPreference.value.payload.language,
    timeZone: getUserPreference.value.payload.timeZone,
    datePattern: getUserPreference.value.payload.datePattern,
    timePattern: getUserPreference.value.payload.timePattern,
    notificationChannel: getUserPreference.value.payload.notificationChannel
  });
  const [errorsUserPreferences, setErrorsUserPreferences] = useState({
    language: "",
    timeZone: "",
    datePattern: "",
    timePattern: "",
    notificationChannel: "",
  });
  const allLanguage = (): { [key: string]: Object }[] => {
    let newLang: { [key: string]: Object }[] = [];
    getUserPreference.value.languages.map((item) =>
      newLang.push({
        "value": item.twoLetterISOLanguageName,
        "langue": item.displayName,
        "iconLang": ""
      })
    );
    return newLang;
  }
  const allDatePattern = (): { [key: string]: Object }[] => {
    let newDate: { [key: string]: Object }[] = [];
    getUserPreference.value.datePatterns.map((item) =>
      newDate.push({
        "value": item.id,
        "datePattern": item.displayName,
        "iconDate": ""
      })
    );
    return newDate;
  }
  const allTimeZone = (): { [key: string]: Object }[] => {
    let newTime: { [key: string]: Object }[] = [];
    getUserPreference.value.timeZones.map((item) =>
      newTime.push({
        "value": item.id,
        "timezone": item.displayName,
        "iconTime": ""
      })
    );
    return newTime;
  }

  const language: { [key: string]: Object }[] = allLanguage();
  const languageFields: ItemFields = { text: 'langue', value: 'value', iconCss: 'iconLang' };

  const timeZone: { [key: string]: Object }[] = allTimeZone();
  const timeZoneFields: ItemFields = { text: 'timezone', value: 'value', iconCss: 'iconTime' };

  const timePattern: { [key: string]: Object }[] = [
    { "value": "12h", "timepattern": "12h", "iconTime": "" },
    { "value": "24h", "timepattern": "24h", "iconTime": "" }
  ]
  const timePatternFields: ItemFields = { text: 'timepattern', value: 'value', iconCss: 'iconTime' };

  const datePattern: { [key: string]: Object }[] = allDatePattern();
  const datePatternFields: ItemFields = { text: 'datePattern', value: 'value', iconCss: 'iconDate' };

  const onChange = (args: ChangeEventArgs, item: string, itemFields: ItemFields) => {
    setUserPreferencesViewModel({
      ...userPreferencesViewModel,
      [item]: (args.itemData === null) ? 'null' : args.itemData[itemFields.value].toString()
    });
  }

  const handleChangeSwitch = (e, text: string) => {
    let value = '';
    if (e.checked)
      value = 'SMS';
    else value = 'EMAIL';

    setUserPreferencesViewModel({
      ...userPreferencesViewModel,
      [text]: value,
    });
  }

  if (
    (getUserPreference.value.payload.datePattern ||
      getUserPreference.value.payload.timePattern ||
      getUserPreference.value.payload.timeZone) &&
    !getUserPreference.pending &&
    !actu
  ) {
    setActu(true);
    setUserPreferencesViewModel({
      ...userPreferencesViewModel,
      language: getUserPreference.value.payload.language,
      notificationChannel: getUserPreference.value.payload.notificationChannel,
      datePattern: getUserPreference.value.payload.datePattern,
      timePattern: getUserPreference.value.payload.timePattern,
      timeZone: getUserPreference.value.payload.timeZone,
    });
  }

  const handleUserPreferences = async (e) => {
    e.preventDefault();
    setErrorsUserPreferences({
      language: "",
      timeZone: "",
      datePattern: "",
      timePattern: "",
      notificationChannel: "",
    });
    const values = await schema.validate(userPreferencesViewModel);

    if (values.language === "" || values.notificationChannel === "" || values.timeZone === "" || values.datePattern === "") {
      let languageError = "",
        datePatternError = "",
        timePatternError = "",
        timeZoneError = "",
        notificationChannelError = "";
      if (values.language === "")
        languageError = commonLocalizer("MODULE_COMMON_USER_PREFENCES_INVALID_LANGUAGE");
      if (values.notificationChannel === "")
        notificationChannelError = commonLocalizer("MODULE_COMMON_USER_PREFENCES_INVALID_NOTIFICATION_CHANNEL");
      if (values.timeZone === "")
        timeZoneError = commonLocalizer("MODULE_COMMON_USER_PREFENCES_INVALID_TIMEZONE");
      if (values.datePattern === "")
        datePatternError = commonLocalizer("MODULE_COMMON_USER_PREFENCES_INVALID_DATE_FOMAT");

      setErrorsUserPreferences({
        language: languageError,
        datePattern: datePatternError,
        timePattern: timePatternError,
        timeZone: timeZoneError,
        notificationChannel: notificationChannelError,
      });
    } else {
      dispatch(await updateUserPreferences({ ...userPreferencesViewModel, timePattern: '24h' } as UpdateUserPreferencesCommand));
    }
  };

  window.document.title = commonLocalizer("MODULE_COMMON_USER_PREFENCES_UPDATE");

  const returnPreviousPage = () => {
    navigate(-1);
  };

  return (
    <div className="h-full flex flex-col justify-between user-profile">
      {updateUserPreference.Errors &&
        updateUserPreference.Errors.length > 0 &&
        !updateUserPreference.pending &&
        updateUserPreference.Errors.map((message, key) => {
          return (
            <div className="w-full mx-auto mb-auto" key={key}>
              <MessageComponent
                showCloseIcon
                id="msg_error"
                className="errorServer m-1"
                content={message}
                key={key}
                severity="Error"
              ></MessageComponent>
            </div>
          );
        })}
      {getUserPreference.Errors &&
        getUserPreference.Errors.length > 0 &&
        !getUserPreference.pending &&
        getUserPreference.Errors.map((message, key) => {
          return (
            <div className="w-full mx-auto my-2" key={key}>
              <MessageComponent
                showCloseIcon
                id="msg_error"
                className="errorServer m-1"
                content={message}
                key={key}
                severity="Error"
              ></MessageComponent>
            </div>
          );
        })}

      {updateUserPreference.value && !updateUserPreference.pending ? (
        <div className="absolute left-[35%] top-[35%] w-1/2 mx-auto">
          <OperationResultComponent
            message={commonLocalizer("MODULE_COMMON_USER_PREFENCES_MESSAGES_UPDATED_SUCCESSFULLY")}
            title={commonLocalizer("MODULE_COMMON_USER_PREFENCES_UPDATE")}
            titleButton={commonLocalizer("MODULE_COMMON_USER_PREFENCES_MY_PREFERENCES")}
            linkButton="/my-settings"
          />
        </div>
      ) : (
        <>
          <div className={` ${ClasseName.TITLE} `}>
            <h1 className="">{commonLocalizer("MODULE_COMMON_USER_PREFENCES_MY_PREFERENCES")}</h1>
            <Breadcrumb items={[{ title: commonLocalizer("MODULE_COMMON_SIDEBAR_DASHBOARD"), link: "/dashboard" }, { title: commonLocalizer("MODULE_COMMON_USER_PREFENCES_MY_PREFERENCES") }]} />
          </div>

          <div className={`h-full mx-auto pt-3 pb-2 xl:w-11/12 xmd:w-full xxs:w-11/12 xl:px-0 xmd:px-2 xxs:px-0`}>
            <form className={` ${ClasseName.CARD_COMPONENT_FORM} `} onSubmit={handleUserPreferences}>
              <div className={`${ClasseName.CARD_COMPONENT}`}>
                {getUserPreference.pending ? (
                  <div className="flex flex-col w-full gap-0 mx-auto">
                    <div className="username w-full mx-auto"><ShimmerText /></div>
                    <div className="username w-full mx-auto"><ShimmerText /></div>
                    <div className="username w-full mx-auto"><ShimmerText /></div>
                  </div>
                ) : (
                  <>
                    <>
                      <div className="language flex flex-col gap-2 justify-between">
                        <label htmlFor="language">{commonLocalizer("MODULE_COMMON_USER_PREFENCES_PREFERED_LANGUAGE_LABEL")}</label>
                        <DropDownListComponent
                          cssClass="w-full border px-2 py-1 input-notify"
                          id="language"
                          dataSource={language}
                          fields={languageFields}
                          change={(args) => onChange(args, "language", languageFields)}
                          value={userPreferencesViewModel.language}
                          placeholder={commonLocalizer("MODULE_COMMON_USER_PREFENCES_PREFERED_LANGUAGE_HELP")}
                          popupHeight="220px"
                        />
                        {errorsUserPreferences.language && (
                          <div className="error">
                            {errorsUserPreferences.language.toString()}
                          </div>
                        )}
                      </div>
                      <div className="timeZone flex flex-col gap-2 justify-between">
                        <label htmlFor="timeZone">{commonLocalizer("MODULE_COMMON_USER_PREFENCES_TIMEZONE_LABEL")}</label>
                        <DropDownListComponent
                          cssClass="w-full border px-2 py-1 input-notify"
                          id="timeZone"
                          dataSource={timeZone}
                          fields={timeZoneFields}
                          change={(args) =>
                            onChange(args, "timeZone", timeZoneFields)
                          }
                          value={userPreferencesViewModel.timeZone}
                          placeholder={commonLocalizer("MODULE_COMMON_USER_PREFENCES_TIMEZONE_HELP")}
                          popupHeight="220px"
                        />
                        {errorsUserPreferences.timeZone && (
                          <div className="error">
                            {errorsUserPreferences.timeZone.toString()}
                          </div>
                        )}
                      </div>
                    </>

                    <div className="notificationChannel flex flex-col gap-2 justify-between">
                      <label htmlFor="notificationChannel">
                        {commonLocalizer("MODULE_COMMON_USER_PREFENCES_PREFERED_NOTIFICATION_CHANNEL_LABEL")}
                      </label>
                      <div
                        className="w-full px-2 py-1 input-notif flex justify-start gap-5"
                        id="notificationChannel"
                      >
                        <label htmlFor="notificationChannel" className="" onClick={() => handleChangeSwitch({ checked: false, event: PointerEvent, name: 'change' }, "notificationChannel")}>E-mail</label>
                        <SwitchComponent
                          id={"notificationChannel"}
                          checked={userPreferencesViewModel.notificationChannel === "SMS"}
                          value="true"
                          name={"notificationChannel"}
                          cssClass={" switcher"}
                          readOnly={!(getUserData.value.payload.email.length > 0 && getUserData.value.payload.phoneNumber.length > 0)}
                          disabled={!(getUserData.value.payload.email.length > 0 && getUserData.value.payload.phoneNumber.length > 0)}
                          change={(e) => handleChangeSwitch(e, "notificationChannel")}
                        ></SwitchComponent>
                        <label htmlFor="notificationChannel" className="" onClick={() => handleChangeSwitch({ checked: true, event: PointerEvent, name: 'change' }, "notificationChannel")}>SMS</label>

                      </div>
                      {errorsUserPreferences.notificationChannel && (
                        <div className="error">
                          {errorsUserPreferences.notificationChannel.toString()}
                        </div>
                      )}
                    </div>

                    <>
                      <div className="datePattern flex flex-col gap-2 justify-between">
                        <label htmlFor="datePattern">{commonLocalizer("MODULE_COMMON_USER_PREFENCES_DATE_FORMAT_LABEL")}</label>
                        <DropDownListComponent
                          cssClass="w-full border px-2 py-1 input-notify"
                          id="datePattern"
                          dataSource={datePattern}
                          fields={datePatternFields}
                          change={(args) =>
                            onChange(args, "datePattern", datePatternFields)
                          }
                          value={userPreferencesViewModel.datePattern}
                          placeholder={commonLocalizer("MODULE_COMMON_USER_PREFENCES_DATE_FORMAT_HELP")}
                          popupHeight="220px"
                        />
                        {errorsUserPreferences.datePattern && (
                          <div className="error">
                            {errorsUserPreferences.datePattern.toString()}
                          </div>
                        )}
                      </div>

                      <div className="timePattern flex flex-col gap-2 justify-between">
                        <label htmlFor="timePattern">{commonLocalizer("MODULE_COMMON_USER_PREFENCES_TIME_FORMAT_LABEL")}</label>
                        <DropDownListComponent
                          cssClass="w-full border px-2 py-1 input-notify disabled"
                          disabled={true}
                          readonly={true}
                          id="timePattern"
                          dataSource={timePattern}
                          fields={timePatternFields}
                          change={(args) =>
                            onChange(args, "timePattern", timePatternFields)
                          }
                          value={userPreferencesViewModel.timePattern}
                          placeholder={commonLocalizer("MODULE_COMMON_USER_PREFENCES_TIME_FORMAT_HELP")}
                          popupHeight="220px"
                        />
                        {errorsUserPreferences.timePattern && (
                          <div className="error">
                            {errorsUserPreferences.timePattern.toString()}
                          </div>
                        )}
                      </div>
                    </>

                    <div className="btns flex flex-col gap-2 justify-between mt-auto">
                      <Button
                        param={{
                          type: "button",
                          css: (updateUserPreference.pending && "disabled") + " cancelBtn px-5 py-1 mt-5 col-span-2 h-12 rounded-md mx-auto xxs:w-full",
                          name: commonLocalizer("MODULE_COMMON_USER_PREFENCES_CANCEL_BTN_TEXT"),
                          disabled: updateUserPreference.pending,
                          handleClick: returnPreviousPage,
                        }}
                      />
                      <Button
                        param={{
                          type: "submit",
                          css: (updateUserPreference.pending && "disabled") + " okBtn px-5 py-1 mb-5 col-span-2 h-12 rounded-md mx-auto xxs:w-full",
                          name: commonLocalizer("MODULE_COMMON_USER_PREFENCES_CONFIRM_BTN_TEXT"),
                          disabled: updateUserPreference.pending
                        }}
                      />
                    </div>
                  </>
                )}
              </div>
            </form>
          </div>
        </>
      )}
    </div>
  );
};

export default UpdateUserPreferences;
