export const brandsDataGrid = [
  {
    id: "f3405e44-962e-451c-84c8-f04efbfc1933",
    name: "MarqueModif1",
    models: [
      {
        id: "5f88b51c-26d2-4555-b41c-44af23ae11fe",
        name: "mod11",
        description: "descr11",
        brandId: "f3405e44-962e-451c-84c8-f04efbfc1933",
      },
      {
        id: "797d220c-f5db-4d3d-9604-2a141a717dfc",
        name: "mod44",
        description: "descr44",
        brandId: "f3405e44-962e-451c-84c8-f04efbfc1933",
      },
      {
        id: "9077f759-cdd9-4363-9c26-48c2354b20bc",
        name: "mod22",
        description: "descr22",
        brandId: "f3405e44-962e-451c-84c8-f04efbfc1933",
      },
      {
        id: "df2bdc86-15d2-4f85-a13c-1f8ecb2e9636",
        name: "mod33",
        description: "descr33",
        brandId: "f3405e44-962e-451c-84c8-f04efbfc1933",
      },
    ],
  },
];

export const modelsDataGrid = [
  {
    id: "5f88b51c-26d2-4555-b41c-44af23ae11fe",
    name: "mod11",
    description: "descr11",
    brandId: "f3405e44-962e-451c-84c8-f04efbfc1933",
  },
  {
    id: "797d220c-f5db-4d3d-9604-2a141a717dfc",
    name: "mod44",
    description: "descr44",
    brandId: "f3405e44-962e-451c-84c8-f04efbfc1933",
  },
  {
    id: "9077f759-cdd9-4363-9c26-48c2354b20bc",
    name: "mod22",
    description: "descr22",
    brandId: "f3405e44-962e-451c-84c8-f04efbfc1933",
  },
  {
    id: "df2bdc86-15d2-4f85-a13c-1f8ecb2e9636",
    name: "mod33",
    description: "descr33",
    brandId: "f3405e44-962e-451c-84c8-f04efbfc1933",
  },
];
