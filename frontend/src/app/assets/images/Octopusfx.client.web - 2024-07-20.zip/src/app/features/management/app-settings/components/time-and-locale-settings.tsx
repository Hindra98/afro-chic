import { Dispatch, SetStateAction } from 'react'
import CardSettings from '../card-settings'
import { useAppSelector } from 'src/app/core/hooks/core-hooks'
import { ChangeEventArgs } from "@syncfusion/ej2/dropdowns";
import { ShimmerText } from 'src/app/components/shared/shimmer'
import { DropDownListComponent } from '@syncfusion/ej2-react-dropdowns'
import { useLocalizer } from 'src/app/core/Localization';

type ItemFields = {
  text: string;
  value: string;
  iconCss: string;
};

type Props = {
  viewModel?: {
    language: string;
    timeZoneId: string;
    datePattern: string;
    timePattern: string;
  }
  setViewModel?: Dispatch<SetStateAction<{
    language: string;
    timeZoneId: string;
    datePattern: string;
    timePattern: string;
  }>>
  errorsAppSettings?
}

const TimeAndLocaleSettings = ({ errorsAppSettings = null, setViewModel, viewModel }: Props) => {
  const commonLocalizer = useLocalizer("Common-ResCommon");

  const getAppSettingsData = useAppSelector((state) => state.getAppSettings);

  const allLanguage = (): { [key: string]: Object }[] => {
    let newLang: { [key: string]: Object }[] = [];
    getAppSettingsData.value.languages.map((item) =>
      newLang.push({
        "value": item.twoLetterISOLanguageName,
        "langue": item.displayName,
        "iconLang": ""
      })
    );
    return newLang;
  }
  const allDatePattern = (): { [key: string]: Object }[] => {
    let newDate: { [key: string]: Object }[] = [];
    getAppSettingsData.value.datePatterns.map((item) =>
      newDate.push({
        "value": item.id,
        "datePattern": item.displayName,
        "iconDate": ""
      })
    );
    return newDate;
  }
  const allTimeZone = (): { [key: string]: Object }[] => {
    let newTime: { [key: string]: Object }[] = [];
    getAppSettingsData.value.timeZones.map((item) =>
      newTime.push({
        "value": item.id,
        "timeZoneId": item.displayName,
        "iconTime": ""
      })
    );
    return newTime;
  }

  const language: { [key: string]: Object }[] = allLanguage();
  const languageFields: ItemFields = { text: 'langue', value: 'value', iconCss: 'iconLang' };

  const datePattern: { [key: string]: Object }[] = allDatePattern();
  const datePatternFields: ItemFields = { text: 'datePattern', value: 'value', iconCss: 'iconDate' };

  const timeZoneId: { [key: string]: Object }[] = allTimeZone();
  const timeZoneIdFields: ItemFields = { text: 'timeZoneId', value: 'value', iconCss: 'iconTime' };

  const timePattern: { [key: string]: Object }[] = [
    { "value": "12h", "timePattern": "12h", "iconDate": "" },
    { "value": "24h", "timePattern": "24h", "iconDate": "" }
  ]
  const timePatternFields: ItemFields = { text: 'timePattern', value: 'value', iconCss: 'iconDate' };

  const handleChangeComboBox = (args: ChangeEventArgs, item: string, itemFields: ItemFields) => {
    setViewModel({
      ...viewModel,
      [item]: (args.itemData === null) ? 'null' : args.itemData[itemFields.value].toString()
    });
  }

  return (
    <>
      {getAppSettingsData.pending ? (<div className="p-0 m-0 w-full mx-auto"><ShimmerText /><ShimmerText /><ShimmerText /></div>) : (
        <CardSettings title={commonLocalizer("MODULE_COMMON_WEB_SETTINGS_TIMES_AND_LOCALES_TITLE")}>

          <div className="language flex flex-col gap-2 justify-between w-full p-0 m-0">
            <div className="flex flex-row gap-5 justify-between w-full p-0 m-0">
              <label htmlFor="language" className="w-1/3">{commonLocalizer("MODULE_COMMON_WEB_SETTINGS_TIMES_AND_LOCALES_APP_LANGUAGE")}</label>
              <div className="w-3/4">
                <DropDownListComponent
                  cssClass="px-2 py-1 input-notify"
                  id="language"
                  dataSource={language}
                  fields={languageFields}
                  change={(args) => handleChangeComboBox(args, "language", languageFields)}
                  value={viewModel.language}
                  placeholder={commonLocalizer("MODULE_COMMON_WEB_SETTINGS_TIMES_AND_LOCALES_APP_LANGUAGE_HELP")}
                  popupHeight="220px"
                />
              </div>
            </div>
            {errorsAppSettings.language &&
              (<div className="error">{errorsAppSettings.language.toString()}</div>)}
          </div>

          <div className="timeZoneId flex flex-col gap-2 justify-between w-full p-0 m-0">
            <div className="flex flex-row gap-5 justify-between w-full p-0 m-0">
              <label htmlFor="timeZoneId" className="w-1/3">{commonLocalizer("MODULE_COMMON_WEB_SETTINGS_TIMES_AND_LOCALES_TIMEZONE")}</label>
              <div className="w-3/4">
                <DropDownListComponent
                  cssClass="px-2 py-1 input-notify"
                  id="timeZoneId"
                  dataSource={timeZoneId}
                  fields={timeZoneIdFields}
                  change={(args) => handleChangeComboBox(args, "timeZoneId", timeZoneIdFields)}
                  value={viewModel.timeZoneId}
                  placeholder={commonLocalizer("MODULE_COMMON_WEB_SETTINGS_TIMES_AND_LOCALES_TIMEZONE_HELP")}
                  popupHeight="220px"
                />
              </div>
            </div>
            {errorsAppSettings.timeZoneId &&
              (<div className="error">{errorsAppSettings.timeZoneId.toString()}</div>)}
          </div>

          <div className="datePattern flex flex-col gap-2 justify-between w-full p-0 m-0">
            <div className="flex flex-row gap-5 justify-between w-full p-0 m-0">
              <label htmlFor="datePattern" className="w-1/3 label-disabled">{commonLocalizer("MODULE_COMMON_WEB_SETTINGS_TIMES_AND_LOCALES_DATE_FORMAT")}</label>
              <div className="w-3/4">
                <DropDownListComponent
                  cssClass="px-2 py-1 input-notify label-disabled"
                  id="datePattern"
                  dataSource={datePattern}
                  fields={datePatternFields}
                  disabled={true}
                  readonly={true}
                  change={(args) => handleChangeComboBox(args, "datePattern", datePatternFields)}
                  value={viewModel.datePattern}
                  placeholder={commonLocalizer("MODULE_COMMON_WEB_SETTINGS_TIMES_AND_LOCALES_DATE_FORMAT_HELP")}
                  popupHeight="220px"
                />
              </div>
            </div>
            {errorsAppSettings.datePattern &&
              (<div className="error">{errorsAppSettings.datePattern.toString()}</div>)}
          </div>

          <div className="timePattern flex flex-col gap-2 justify-between w-full p-0 m-0">
            <div className="flex flex-row gap-5 justify-between w-full p-0 m-0">
              <label htmlFor="timePattern" className="w-1/3 label-disabled">{commonLocalizer("MODULE_COMMON_WEB_SETTINGS_TIMES_AND_LOCALES_TIME_FORMAT")}</label>
              <div className="w-3/4">
                <DropDownListComponent
                  cssClass="px-2 py-1 input-notify label-disabled"
                  id="timePattern"
                  dataSource={timePattern}
                  fields={timePatternFields}
                  disabled={true}
                  readonly={true}
                  change={(args) => handleChangeComboBox(args, "timePattern", timePatternFields)}
                  value={viewModel.timePattern}
                  placeholder={commonLocalizer("MODULE_COMMON_WEB_SETTINGS_TIMES_AND_LOCALES_TIME_FORMAT_HELP")}
                  popupHeight="220px"
                />
              </div>
            </div>
            {errorsAppSettings.timePattern &&
              (<div className="error">{errorsAppSettings.timePattern.toString()}</div>)}
          </div>

        </CardSettings>
      )}
    </>
  )
}

export default TimeAndLocaleSettings