export interface AddTenantStoreShape {
  pending: boolean;
  Errors: string[];
  value: boolean;
}
export let initialStateAddTenant: AddTenantStoreShape = {
  value: false,
  pending: false,
  Errors: [],
};

export interface AddTenantModelShape {
  command: FormData;
}
export interface AddTenantFailurePayload {
  errors: string[];
}
export interface AddTenantSuccessPayload {
  value: boolean;
}
export interface AddTenantRequest {
  type: string;
  payload: FormData;
}
export interface AddTenantFailure {
  type: string;
  payload: AddTenantFailurePayload;
}
export interface AddTenantSuccess {
  type: string;
  payload: AddTenantSuccessPayload;
}
export interface AddTenantPayload {
  command: FormData;
  value: AddTenantSuccessPayload;
  errors: AddTenantFailurePayload;
}
export interface AddTenantAction {
  type: string;
  payload: AddTenantPayload;
}

export interface UpdateTenantStoreShape {
  pending: boolean;
  Errors: string[];
  value: boolean;
}
export let initialStateUpdateTenant: UpdateTenantStoreShape = {
  value: false,
  pending: false,
  Errors: [],
};

export interface UpdateTenantModelShape {
  command: FormData;
}
export interface UpdateTenantFailurePayload {
  errors: string[];
}
export interface UpdateTenantSuccessPayload {
  value: boolean;
}
export interface UpdateTenantRequest {
  type: string;
  payload: FormData;
}
export interface UpdateTenantFailure {
  type: string;
  payload: UpdateTenantFailurePayload;
}
export interface UpdateTenantSuccess {
  type: string;
  payload: UpdateTenantSuccessPayload;
}
export interface UpdateTenantPayload {
  command: FormData;
  value: UpdateTenantSuccessPayload;
  errors: UpdateTenantFailurePayload;
}
export interface UpdateTenantAction {
  type: string;
  payload: UpdateTenantPayload;
}

export interface DeleteTenantStoreShape {
  pending: boolean;
  Errors: string[];
  value: boolean;
}
export let initialStateDeleteTenant: DeleteTenantStoreShape = {
  value: false,
  pending: false,
  Errors: [],
};

export interface DeleteTenantModelShape {
  command: DeleteTenantCommand;
}
export interface DeleteTenantFailurePayload {
  errors: string[];
}
export interface DeleteTenantSuccessPayload {
  value: boolean;
}
export interface DeleteTenantRequest {
  type: string;
  payload: DeleteTenantCommand;
}
export interface DeleteTenantFailure {
  type: string;
  payload: DeleteTenantFailurePayload;
}
export interface DeleteTenantSuccess {
  type: string;
  payload: DeleteTenantSuccessPayload;
}
export interface DeleteTenantPayload {
  command: DeleteTenantCommand;
  value: DeleteTenantSuccessPayload;
  errors: DeleteTenantFailurePayload;
}
export interface DeleteTenantAction {
  type: string;
  payload: DeleteTenantPayload;
}



export interface GetTenantsStoreShape {
  pending: boolean;
  Errors: string[];
  value: GetTenants;
}
export let getTenantsInitialState: GetTenantsStoreShape = {
  value: {
    tenants: [],
    hostNames: [],
    isSuperAdministrator: false,
  } as GetTenants,
  pending: false,
  Errors: [],
};

export interface GetTenantsFailurePayload {
  errors: string[];
}
export interface GetTenantsRequest {
  type: string;
  payload: string;
}
export interface GetTenantsSuccess {
  type: string;
  payload: GetTenants;
}
export interface GetTenantsFailure {
  type: string;
  payload: GetTenantsFailurePayload;
}
export interface GetTenantsPayload {
  command: string;
  user: GetTenants;
  errors: GetTenantsFailurePayload;
}
export interface GetTenantsAction {
  type: string;
  payload: GetTenantsPayload;
}

export interface GetTenantStoreShape {
  pending: boolean;
  Errors: string[];
  value: GetTenant;
}
export let getTenantInitialState: GetTenantStoreShape = {
  value: {
    vendor: {
      key: "",
      name: "",
      subscriptionID: "",
      databaseName: "",
      description: "",
      logoUrl: "",
      detail: "",
      language: "",
      regionalFormatId: "",
      isEnable: true,
      isDeletable: false,
      statusWording: "",
      timeZoneId: "",
      status: "ENABLED",
      defaultAdministrator: {
        id: "",
        userName: "",
        password: "",
        firstName: "",
        lastName: "",
        middleName: "",
        emailAddress: "",
        phoneNumber: "",
        idCardNumber: "",
        isUserConsentEmailNotification: true,
        isUserConsentSmsNotification: true,
        preferedCommunicationChannel: 0,
        identityDocumentType: 0,
      } as DefaultAdministrator,
    } as Tenant,
    regionalFormats: [],
    languages: [],
    timeZones: [],
    idDocumentTypes: [],
  },
  pending: false,
  Errors: [],
};
export interface TenantFailurePayload {
  errors: string[];
}
export interface TenantRequest {
  type: string;
  payload: string;
}
export interface TenantSuccess {
  type: string;
  payload: GetTenant;
}
export interface TenantFailure {
  type: string;
  payload: TenantFailurePayload;
}
export interface TenantPayload {
  command: TenantCommand;
  user: GetTenant;
  errors: TenantFailurePayload;
}
export interface TenantAction {
  type: string;
  payload: TenantPayload;
}

export interface ExportPdfTenantsStoreShape {
  pending: boolean;
  Errors: string[];
  value: boolean;
}
export let exportPdfTenantsInitialState: ExportPdfTenantsStoreShape = {
  value: false,
  pending: false,
  Errors: [],
};
export interface ExportPdfTenantsFailurePayload {
  errors: string[];
}
export interface ExportPdfTenantsRequest {
  type: string;
  payload: FormData;
}
export interface ExportPdfTenantsSuccess {
  type: string;
  payload: {value: boolean};
}
export interface ExportPdfTenantsFailure {
  type: string;
  payload: ExportPdfTenantsFailurePayload;
}
export interface ExportPdfTenantsPayload {
  command: FormData;
  user: {value: boolean};
  errors: ExportPdfTenantsFailurePayload;
}
export interface ExportPdfTenantsAction {
  type: string;
  payload: ExportPdfTenantsPayload;
}
