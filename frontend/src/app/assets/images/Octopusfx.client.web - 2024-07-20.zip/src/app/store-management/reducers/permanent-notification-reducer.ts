
import { produce } from "immer";
import { ActionTypes } from "../actions/constants/action-types";
import { CountPermanentNotificationAction, CountPermanentNotificationStoreShape, initialStatePermanentNotification, initialStateUpdatePermanentNotification, PermanentNotificationAction, PermanentNotificationStoreShape, UpdatePermanentNotificationAction, UpdatePermanentNotificationStoreShape } from "../actions/permanent-notification-message";
import { DataManager, Query } from "@syncfusion/ej2/data";

const initializeState: string[] = [];
const initializeCountNotification: CountPermanentNotificationStoreShape = { pending: false, Errors: [], value: { unreadNotificationsCount: 0 } };

export const checkNotificationReducer = (state = initializeState, args: { type: string; payload: SetNotificationStatusCommand }) => {
  switch (args.type) {

    case ActionTypes.SET_NOTIFICATION_STATUS:
      return produce(state, (draftState) => {
        if (args.payload.checked && !draftState.includes(args.payload.id)) draftState.push(args.payload.id);
        if (!args.payload.checked) draftState.splice(draftState.indexOf(args.payload.id), 1);
      });

    default:
      return state;
  }
};

export const countPermanentNotificationReducer = (state: CountPermanentNotificationStoreShape = initializeCountNotification, args: CountPermanentNotificationAction): CountPermanentNotificationStoreShape => {

  switch (args.type) {

    case ActionTypes.COUNT_PERMANENT_NOTIFICATION:
      return produce(state, (draftState) => {
        draftState.pending = true;
        draftState.Errors = [];
      });

    case ActionTypes.COUNT_PERMANENT_NOTIFICATION_SUCCESS:
      return produce(state, (draftState) => {
        draftState.Errors = [];
        draftState.pending = false;
        draftState.value.unreadNotificationsCount = args?.payload?.user?.unreadNotificationsCount
      });

    default:
      return state;
  }
};

export const permanentNotificationReducer = (state: PermanentNotificationStoreShape = initialStatePermanentNotification, args: PermanentNotificationAction): PermanentNotificationStoreShape => {

  switch (args.type) {

    case ActionTypes.GET_NOTIFICATIONS_REQUEST:
      return produce(state, (draftState) => {
        draftState.pending = true;
        draftState.Errors = [];
      });

    case ActionTypes.GET_NOTIFICATIONS_FAILURE:
      return produce(state, (draftState) => {
        draftState.Errors = args.payload?.errors.errors;
        draftState.pending = false;
      });

    case ActionTypes.GET_NOTIFICATIONS_SUCCESS:
      return produce(state, (draftState) => {
        draftState.Errors = [];
        draftState.pending = false;
        draftState.value.userId = args?.payload?.user?.userId
        draftState.value.notificationCount = args?.payload?.user?.notificationCount
        draftState.value.payload = args?.payload?.user?.payload
      });

    default:
      return state;
  }
};

export const markReadPermanentNotificationReducer = (state: UpdatePermanentNotificationStoreShape = initialStateUpdatePermanentNotification, args: UpdatePermanentNotificationAction): UpdatePermanentNotificationStoreShape => {

  switch (args.type) {

    case ActionTypes.MARK_READ_NOTIFICATIONS_REQUEST:
      return produce(state, (draftState) => {
        draftState.pending = true;
        draftState.Errors = [];
      });

    case ActionTypes.MARK_READ_NOTIFICATIONS_FAILURE:
      return produce(state, (draftState) => {
        draftState.Errors = args.payload?.errors.errors;
        draftState.pending = false;
      });

    case ActionTypes.MARK_READ_NOTIFICATIONS_SUCCESS:
      return produce(state, (draftState) => {
        draftState.Errors = [];
        draftState.pending = false;
        draftState.value = args?.payload?.value.isCompleted
      });

    default:
      return state;
  }
};

export const deletePermanentNotificationReducer = (state: UpdatePermanentNotificationStoreShape = initialStateUpdatePermanentNotification, args: UpdatePermanentNotificationAction): UpdatePermanentNotificationStoreShape => {

  switch (args.type) {

    case ActionTypes.DELETE_NOTIFICATIONS_REQUEST:
      return produce(state, (draftState) => {
        draftState.pending = true;
        draftState.Errors = [];
      });

    case ActionTypes.DELETE_NOTIFICATIONS_FAILURE:
      return produce(state, (draftState) => {
        draftState.Errors = args.payload?.errors.errors;
        draftState.pending = false;
      });

    case ActionTypes.DELETE_NOTIFICATIONS_SUCCESS:
      return produce(state, (draftState) => {
        draftState.Errors = [];
        draftState.pending = false;
        draftState.value = args?.payload?.value.isCompleted
      });

    default:
      return state;
  }
};

const initialPage = { skip: 0, take: 2 }
const initialState = {
  data: [],
  error: false,
  result: [],
  count: 0
}

export const sortPermanentNotificationReducer = (state = initialState, args) => {

  const dataSource = [...initialState.data];
  let filter = [];
  const gridData = new DataManager(dataSource);

  if (args.gridQuery !== undefined) {
    filter = args.gridQuery.queries.filter((fn: any) => {
      return fn.fn === "onWhere"
    })
  }

  switch (args.type) {

    case ActionTypes.GRID_NOTIFICATIONS_SORTING:
      const sortData = gridData.executeLocal(args.gridQuery);
      const currentPageDataSort = new DataManager(sortData).executeLocal(new Query().skip(args.payload.skip).take(args.payload.take));
      return ({
        data: { result: currentPageDataSort, count: sortData.length }
      })

    case ActionTypes.GRID_NOTIFICATIONS_PAGER:
      const pageData = gridData.executeLocal(new Query());
      const result = args.gridQuery !== undefined ? new DataManager(pageData).executeLocal(args.gridQuery) : pageData;
      const currentPageDataPage = new DataManager(result).executeLocal(new Query().skip(args.payload.skip).take(args.payload.take));
      return ({
        data: { result: currentPageDataPage, count: filter.length ? result.length : pageData.length }
      })

    case ActionTypes.GRID_NOTIFICATIONS_FILTER:
      const filterData = gridData.executeLocal(args.gridQuery);
      const currentPageDataFilter = new DataManager(filterData).executeLocal(new Query().skip(args.payload.skip).take(args.payload.take))
      return ({
        data: { result: currentPageDataFilter, count: filterData.length }
      })

    default:
      const defaultCount = state.data.length;
      return produce(state, (draftState) => {
        draftState.data.slice(initialPage.skip, initialPage.take)
        draftState.count = defaultCount
      });
  }
};
