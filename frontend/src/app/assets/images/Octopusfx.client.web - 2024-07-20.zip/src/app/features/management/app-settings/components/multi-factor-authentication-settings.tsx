import { Dispatch, SetStateAction } from "react";
import RangeSettingsLine from "../range-settings-line";
import SwitchSettingsLine from "../switch-settings-line";
import CardSettings from "../card-settings";
import { useAppSelector } from "src/app/core/hooks/core-hooks";
import { ShimmerText } from "src/app/components/shared/shimmer";
import { useLocalizer } from "src/app/core/Localization";

type Props = {
  viewModel?: {
    isEnableMulltiFactAuth: boolean;
    pinLength: number;
    pinTTL: number;
  }
  setViewModel?: Dispatch<SetStateAction<{
    isEnableMulltiFactAuth: boolean;
    pinLength: number;
    pinTTL: number;
  }>>
  errorsAppSettings?;
};

const MultiFactorAuthSettings = ({ setViewModel, viewModel }: Props) => {
  const commonLocalizer = useLocalizer("Common-ResCommon");
  const getAppSettingsData = useAppSelector((state) => state.getAppSettings);

  const handleChangeSwitch = (e, text: string) => {
    const value = e.checked;
    setViewModel({
      ...viewModel,
      [text]: value,
    });
  };

  const handleChangeRange = (e, text: string): void => {
    const { name, value } = e.target;
    setViewModel({
      ...viewModel,
      [name]: value,
    });
  };

  return (
    <>
      {getAppSettingsData.pending ? (<div className="p-0 m-0 w-full mx-auto"><ShimmerText /><ShimmerText /><ShimmerText /></div>) : (
        <CardSettings title={commonLocalizer("MODULE_COMMON_WEB_SETTINGS_2FA_TITLE")}>

          <SwitchSettingsLine change={(e) => handleChangeSwitch(e, "isEnableMulltiFactAuth")} title={commonLocalizer("MODULE_COMMON_WEB_SETTINGS_2FA_ENABLE")} name="isEnableMulltiFactAuth" description={commonLocalizer("MODULE_COMMON_WEB_SETTINGS_2FA_HELP")} checked={viewModel.isEnableMulltiFactAuth} />

          <RangeSettingsLine disabled={!viewModel.isEnableMulltiFactAuth} value={viewModel.pinLength} min={1} max={9} change={(e) => handleChangeRange(e, "pinLength")} css="mt-4" title={commonLocalizer("MODULE_COMMON_WEB_SETTINGS_2FA_PIN_CODE_LENGTH")} name="pinLength" />

          <RangeSettingsLine disabled={!viewModel.isEnableMulltiFactAuth} value={viewModel.pinTTL} min={1} max={9} change={(e) => handleChangeRange(e, "pinTTL")} title={commonLocalizer("MODULE_COMMON_WEB_SETTINGS_2FA_PIN_EXPIRES")} name="pinTTL" />

        </CardSettings>
      )}
    </>
  );
};

export default MultiFactorAuthSettings;
