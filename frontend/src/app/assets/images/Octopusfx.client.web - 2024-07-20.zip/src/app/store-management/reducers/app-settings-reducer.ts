import { ActionTypes } from "../actions/constants/action-types";
import { produce } from "immer";
import { GetAppSettingsAction, getAppSettingsInitialState, GetAppSettingsStoreShape, initialStateUpdateAppSettings, UpdateAppSettingsAction, UpdateAppSettingsStoreShape } from '../actions/app-settings/index';


export const updateAppSettingsReducer = (state: UpdateAppSettingsStoreShape = initialStateUpdateAppSettings, args: UpdateAppSettingsAction): UpdateAppSettingsStoreShape => {

  switch (args.type) {

    case ActionTypes.UPDATE_APP_SETTINGS_REQUEST:
      return produce(state, (draftState) => {
        draftState.Errors = [];
        draftState.value = false;
        draftState.pending = true;
      });

      case ActionTypes.UPDATE_APP_SETTINGS_FAILURE:
        return produce(state, (draftState) => {
          draftState.Errors = args.payload?.errors.errors;
          draftState.value = false;
          draftState.pending = false;
        });

        case ActionTypes.UPDATE_APP_SETTINGS_SUCCESS:
          return produce(state, (draftState) => {
            draftState.Errors = [];
            draftState.value = true;
            draftState.pending = false;
          });

    default:
      return state;
  }
};

export const getAppSettingsReducer = (state: GetAppSettingsStoreShape = getAppSettingsInitialState, args: GetAppSettingsAction): GetAppSettingsStoreShape => {

    switch (args.type) {

      case ActionTypes.GET_APP_SETTINGS_REQUEST:
        return produce(state, (draftState) => {
          draftState.pending = true;
          draftState.Errors = [];
        });
  
        case ActionTypes.GET_APP_SETTINGS_FAILURE:
          return produce(state, (draftState) => {
            draftState.Errors = args.payload?.errors?.errors;
            draftState.pending = false;
          });
  
          case ActionTypes.GET_APP_SETTINGS_SUCCESS:
            return produce(state, (draftState) => {
              draftState.Errors = [];
              
              draftState.value.key = args.payload?.user?.key
              draftState.value.isAdministrator = args.payload?.user?.isAdministrator
              draftState.value.isSuperAdmin = args.payload?.user?.isSuperAdmin

              draftState.value.userSettings = args.payload?.user?.userSettings
              
              draftState.value.timeAndLocaleSettings = args.payload?.user?.timeAndLocaleSettings
              draftState.value.multiFactorAuthenticationSettings = args.payload?.user?.multiFactorAuthenticationSettings
              draftState.value.passwordPolicySettings = args.payload?.user?.passwordPolicySettings

              draftState.value.cookiesSettings = args.payload?.user?.cookiesSettings
              draftState.value.keyVaultSettings = args.payload?.user?.keyVaultSettings
              draftState.value.jwtSettings = args.payload?.user?.jwtSettings

              draftState.value.timeZones = args.payload?.user?.timeZones
              draftState.value.languages = args.payload?.user?.languages
              draftState.value.datePatterns = args.payload?.user?.datePatterns

              draftState.pending = false;
            });
  
      default:
        return state;
    }
  };