
export interface UpdateBrandStoreShape {
  value: boolean,
  pending: boolean,
  errors: string[],
}
export let initialStateUpdateBrand: UpdateBrandStoreShape = {
  value: false,
  pending: false,
  errors: []
}
export interface UpdateBrandModelShape {
  command: UpdateBrandCommand,
}
export interface UpdateBrandFailurePayload {
  errors: string[],
}
export interface UpdateBrandSuccessPayload {
  value: boolean;
}
export interface UpdateBrandFailure {
  type: string,
  payload: UpdateBrandFailurePayload,
}
export interface UpdateBrandSuccess {
  type: string,
  payload: UpdateBrandSuccessPayload,
}
export interface UpdateBrandPayload {
  command: UpdateBrandCommand,
  value: UpdateBrandSuccessPayload,
  errors: UpdateBrandFailurePayload,
}
export interface UpdateBrandAction {
  type: string,
  payload: UpdateBrandPayload,
}

export interface DeleteBrandStoreShape {
  value: boolean,
  pending: boolean,
  errors: string[],
}
export let initialStateDeleteBrand: DeleteBrandStoreShape = {
  value: false,
  pending: false,
  errors: []
}
export interface DeleteBrandModelShape {
  command: DeleteBrandCommand,
}
export interface DeleteBrandFailurePayload {
  errors: string[],
}
export interface DeleteBrandSuccessPayload {
  value: boolean;
}
export interface DeleteBrandFailure {
  type: string,
  payload: DeleteBrandFailurePayload,
}
export interface DeleteBrandSuccess {
  type: string,
  payload: DeleteBrandSuccessPayload,
}
export interface DeleteBrandPayload {
  command: DeleteBrandCommand,
  value: DeleteBrandSuccessPayload,
  errors: DeleteBrandFailurePayload,
}
export interface DeleteBrandAction {
  type: string,
  payload: DeleteBrandPayload,
}

export interface GetBrandsStoreShape {
  value: GetBrands,
  pending: boolean,
  errors: string[],
}
export let initialStateGetBrands: GetBrandsStoreShape = {
  value: {
    hasAlreadyCalled: false,
    isAdministrator: false,
    brands: [],
  } as GetBrands,
  pending: false,
  errors: []
}
export interface GetBrandsModelShape {
  command: GetBrands,
}
export interface GetBrandsFailurePayload {
  errors: string[],
}
export interface GetBrandsFailure {
  type: string,
  payload: GetBrandsFailurePayload,
}
export interface GetBrandsSuccess {
  type: string,
  payload: GetBrands,
}
export interface GetBrandsPayload {
  command: string,
  value: GetBrands,
  errors: GetBrandsFailurePayload,
}
export interface GetBrandsAction {
  type: string,
  payload: GetBrandsPayload,
}

export interface GetBrandStoreShape {
  value: GetBrand,
  pending: boolean,
  errors: string[],
}
export let initialStateGetBrand: GetBrandStoreShape = {
  value: {
    brand: {
      id: "",
      title: "",
      models: []
    } as Brand,
  } as GetBrand,
  pending: false,
  errors: []
}
export interface GetBrandModelShape {
  command: GetBrand,
}
export interface GetBrandFailurePayload {
  errors: string[],
}
export interface GetBrandFailure {
  type: string,
  payload: GetBrandFailurePayload,
}
export interface GetBrandSuccess {
  type: string,
  payload: GetBrand,
}
export interface GetBrandPayload {
  command: BrandCommand,
  value: GetBrand,
  errors: GetBrandFailurePayload,
}
export interface GetBrandAction {
  type: string,
  payload: GetBrandPayload,
}
