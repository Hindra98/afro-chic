import {
  SidebarComponent,
  TabAnimationSettingsModel,
  TabComponent,
  TabItemDirective,
  TabItemsDirective,
} from "@syncfusion/ej2-react-navigations";
import { ReactElement, useRef, useState } from "react";
import VehicleDataGridTabs from "./vehicle-data-grid-tabs";
import Breadcrumb from "src/app/components/shared/breadcrumb";
import { useLocalizer } from "src/app/core/Localization";
import "src/app/styles/_notifications.scss";
import CreateUpdateVehicleSidebar from "./create-update-vehicle-sidebar";
import ConfirmActionsDialog from "src/app/components/shared/dialog-components/confirm-actions-dialog";
import BrandDataGridTabs from "./brands-data-grid-tabs";
import CreateUpdateBrandSidebar from "./create-update-brand-sidebar";

const VehicleDataGrid = () => {
  const commonLocalizer = useLocalizer("Common-ResCommon");
  let tabInstance = useRef<TabComponent>(null);

  const [titleDialog, setTiltleDialog] = useState("");
  const [btnDialog, setBtnDialog] = useState([]);
  const [messageDialog, setMessageDialog] = useState<ReactElement>(null);
  const openDialog = useState(false);

  const [isShowBackdrop, setShowBackdrop] = useState<boolean>(false);
  const [isEditing, setIsEditing] = useState<boolean>(false);
  let vehicleSidebarInstance = useRef<SidebarComponent>(null);
  let brandSidebarInstance = useRef<SidebarComponent>(null);

  const animateSidebar: TabAnimationSettingsModel = {
    previous: { effect: "None", duration: 600, easing: "ease" },
    next: { effect: "None", duration: 600, easing: "ease" },
  };

  const sidebarClose = () => {
    vehicleSidebarInstance.current.hide();
    brandSidebarInstance.current.hide();
    setShowBackdrop(false);
  };

  let headertext: any = [
    { text: "Véhicules", iconCss: "icon" },
    { text: "Marques", iconCss: "icon" },
  ];

  window.document.title = "Véhicules";
  return (
    <div className="h-full flex flex-col justify-start mx-auto notifications-component">
      <div
        className={` text-3xl align-top flex flex-col justify-start ps-10 pt-4 flex-wrap my-2 gap-0 `}
      >
        <h1 className="">{"Véhicules"}</h1>
        <Breadcrumb
          items={[
            {
              title: commonLocalizer("MODULE_COMMON_SIDEBAR_DASHBOARD"),
              link: "/dashboard",
            },
            { title: "Véhicules" },
          ]}
        />
      </div>

      <TabComponent
        id="vehicleTab"
        cssClass="border-0 border-transparent h-full e-fill"
        animation={animateSidebar}
        ref={tabInstance}
      >
        <TabItemsDirective>
          <TabItemDirective
            header={headertext[0]}
            content={() =>
              VehicleDataGridTabs({
                sidebarInstance: vehicleSidebarInstance,
                sidebarClose,
                isShowBackdrop,
                setShowBackdrop,
                isEditing,
                setIsEditing,
                setTiltleDialog,
                setBtnDialog,
                setMessageDialog,
                openDialog,
              })
            }
          />
          <TabItemDirective
            header={headertext[1]}
            content={() =>
              BrandDataGridTabs({
                sidebarInstance: brandSidebarInstance,
                sidebarClose,
                isShowBackdrop,
                setShowBackdrop,
                isEditing,
                setIsEditing,
                setTiltleDialog,
                setBtnDialog,
                setMessageDialog,
                openDialog,
              })
            }
          />
        </TabItemsDirective>
      </TabComponent>

      <CreateUpdateVehicleSidebar
        isEditing={isEditing}
        func={{
          sidebarClose: sidebarClose.bind(this),
          isShowBackdrop: isShowBackdrop,
          sidebarInstance: vehicleSidebarInstance,
        }}
      />

      <CreateUpdateBrandSidebar
        isEditing={isEditing}
        func={{
          sidebarClose: sidebarClose.bind(this),
          isShowBackdrop: isShowBackdrop,
          sidebarInstance: brandSidebarInstance,
        }}
      />

      <ConfirmActionsDialog
        openDialog={openDialog}
        title={titleDialog}
        button={btnDialog}
      >
        {messageDialog}
      </ConfirmActionsDialog>
    </div>
  );
};

export default VehicleDataGrid;
