export interface AddAgencyStoreShape {
  pending: boolean;
  Errors: string[];
  value: boolean;
}
export let initialStateAddAgency: AddAgencyStoreShape = {
  value: false,
  pending: false,
  Errors: [],
};

export interface AddAgencyModelShape {
  command: BranchCommand;
}
export interface AddAgencyFailurePayload {
  errors: string[];
}
export interface AddAgencySuccessPayload {
  value: boolean;
}
export interface AddAgencyRequest {
  type: string;
  payload: BranchCommand;
}
export interface AddAgencyFailure {
  type: string;
  payload: AddAgencyFailurePayload;
}
export interface AddAgencySuccess {
  type: string;
  payload: AddAgencySuccessPayload;
}
export interface AddAgencyPayload {
  command: BranchCommand;
  value: AddAgencySuccessPayload;
  errors: AddAgencyFailurePayload;
}
export interface AddAgencyAction {
  type: string;
  payload: AddAgencyPayload;
}

export interface UpdateAgencyStoreShape {
  pending: boolean;
  Errors: string[];
  value: boolean;
}
export let initialStateUpdateAgency: UpdateAgencyStoreShape = {
  value: false,
  pending: false,
  Errors: [],
};

export interface UpdateAgencyModelShape {
  command: BranchCommand;
}
export interface UpdateAgencyFailurePayload {
  errors: string[];
}
export interface UpdateAgencySuccessPayload {
  value: boolean;
}
export interface UpdateAgencyRequest {
  type: string;
  payload: BranchCommand;
}
export interface UpdateAgencyFailure {
  type: string;
  payload: UpdateAgencyFailurePayload;
}
export interface UpdateAgencySuccess {
  type: string;
  payload: UpdateAgencySuccessPayload;
}
export interface UpdateAgencyPayload {
  command: BranchCommand;
  value: UpdateAgencySuccessPayload;
  errors: UpdateAgencyFailurePayload;
}
export interface UpdateAgencyAction {
  type: string;
  payload: UpdateAgencyPayload;
}

export interface DeleteAgencyStoreShape {
  pending: boolean;
  Errors: string[];
  value: boolean;
}
export let initialStateDeleteAgency: DeleteAgencyStoreShape = {
  value: false,
  pending: false,
  Errors: [],
};

export interface DeleteAgencyModelShape {
  command: DeleteAgencyCommand;
}
export interface DeleteAgencyFailurePayload {
  errors: string[];
}
export interface DeleteAgencySuccessPayload {
  value: boolean;
}
export interface DeleteAgencyRequest {
  type: string;
  payload: DeleteAgencyCommand;
}
export interface DeleteAgencyFailure {
  type: string;
  payload: DeleteAgencyFailurePayload;
}
export interface DeleteAgencySuccess {
  type: string;
  payload: DeleteAgencySuccessPayload;
}
export interface DeleteAgencyPayload {
  command: DeleteAgencyCommand;
  value: DeleteAgencySuccessPayload;
  errors: DeleteAgencyFailurePayload;
}
export interface DeleteAgencyAction {
  type: string;
  payload: DeleteAgencyPayload;
}

export interface GetAgenciesStoreShape {
  pending: boolean;
  Errors: string[];
  value: GetAgencies;
}
export let getAgenciesInitialState: GetAgenciesStoreShape = {
  value: {
    branches: [],
  } as GetAgencies,
  pending: false,
  Errors: [],
};

export interface GetAgenciesFailurePayload {
  errors: string[];
}
export interface GetAgenciesRequest {
  type: string;
  payload: string;
}
export interface GetAgenciesSuccess {
  type: string;
  payload: GetAgencies;
}
export interface GetAgenciesFailure {
  type: string;
  payload: GetAgenciesFailurePayload;
}
export interface GetAgenciesPayload {
  command: string;
  user: GetAgencies;
  errors: GetAgenciesFailurePayload;
}
export interface GetAgenciesAction {
  type: string;
  payload: GetAgenciesPayload;
}

export interface GetAgencyStoreShape {
  pending: boolean;
  Errors: string[];
  value: GetAgency;
}
export let getAgencyInitialState: GetAgencyStoreShape = {
  value: {
    branch: {
      id: "",
      name: "",
      description: "",
      isHeadQuarter: false,
      isDeletable: false,
      settings: {
        regionalFormat: "",
        language: "",
        timeZone: "",
        currencyPosition: "RIGHT"
      },
      latitude: 0,
      longitude: 0,
      radius: 0,
      order: 0
    } as Branch,
    regionalFormats: [],
    languages: [],
    timeZones: [],
  },
  pending: false,
  Errors: [],
};
export interface AgencyFailurePayload {
  errors: string[];
}
export interface AgencyRequest {
  type: string;
  payload: string;
}
export interface AgencySuccess {
  type: string;
  payload: GetAgency;
}
export interface AgencyFailure {
  type: string;
  payload: AgencyFailurePayload;
}
export interface AgencyPayload {
  command: AgencyCommand;
  user: GetAgency;
  errors: AgencyFailurePayload;
}
export interface AgencyAction {
  type: string;
  payload: AgencyPayload;
}
