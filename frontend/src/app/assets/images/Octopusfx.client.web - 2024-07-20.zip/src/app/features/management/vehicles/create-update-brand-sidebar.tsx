import { SidebarComponent } from "@syncfusion/ej2-react-navigations";
import { MessageComponent } from "@syncfusion/ej2-react-notifications";
import { MutableRefObject, useState } from "react";
import Button from "src/app/components/form/Button";
import InputWithIcon from "src/app/components/form/Input";
import TextArea from "src/app/components/form/TextArea";
import OperationResultComponent from "src/app/components/shared/operation-result-component";
import { ShimmerText } from "src/app/components/shared/shimmer";
import { useAppDispatch, useAppSelector } from "src/app/core/hooks/core-hooks";
import {
  validateFormData,
  ValidationType,
  Validator,
} from "src/app/core/text/regex";
import { updateBrand } from "src/app/store-management/actions/brands/brands-actions";
import { v4 as uuidv4 } from "uuid";

type DataBrand = {
  isEditing?: boolean;
  func: FuncBrand;
};

type FuncBrand = {
  sidebarInstance: MutableRefObject<SidebarComponent>;
  sidebarClose: () => void;
  isShowBackdrop: boolean;
};

export interface FieldBrand {
  value?: string;
  error?: string;
}
export interface FormBrand {
  key?: FieldBrand;
  title?: FieldBrand;
  createdOn?: FieldBrand;
  description?: FieldBrand;
}

export interface FormBrandValidation {
  title?: Validator;
  createdOn?: Validator;
  nameModel?: Validator;
}

type ModelBrand = {
  id: string;
  model: Model;
};

export default function CreateUpdateBrandSidebar(data: DataBrand) {
  const getBrandData = useAppSelector((state) => state.getBrand);
  const updateBrandData = useAppSelector((state) => state.updateBrand);
  const dispatch = useAppDispatch();
  const [showServerErrorMessage, setShowServerErrorMessage] = useState(false);
  const [models, setModels] = useState<ModelBrand[]>([]);
  const [errorModels, setErrorModels] = useState<boolean>(false);

  let closefailedMsg = document
    ?.getElementById("msg_error")
    ?.getElementsByClassName("e-msg-close-icon");
  for (var i = 0; i < closefailedMsg?.length; i++) {
    closefailedMsg[i]?.addEventListener("click", () => {
      setShowServerErrorMessage(false);
      document.getElementById("msg_error")?.setAttribute("class", "h-0 hidden");
      document
        .getElementById("msg_server")
        ?.setAttribute("class", "h-0 hidden");
    });
  }

  const [brandModel, setBrandModel] = useState<FormBrand>({});

  const brandModelValidation: FormBrandValidation = {
    title: {
      validatorType: ValidationType.REQUIRED,
      message: "Nom de marque obligatoire",
    },
    createdOn: {
      validatorType: ValidationType.REQUIRED,
      message: "Date de création obligatoire",
    },
    nameModel: {
      validatorType: ValidationType.REQUIRED,
      message: "Nom du modèle de marque obligatoire",
    },
  };
  const [actu, setActu] = useState(false);
  const [showServerSuccessMessage, setShowServerSuccessMessage] =
    useState(false);

  const initialData = () => {
    setBrandModel({});
    setModels([]);
    setShowServerSuccessMessage(false);
    setShowServerErrorMessage(false);
    setActu(false);
    setErrorModels(false);
  };

  if (!actu && !getBrandData?.pending) {
    setBrandModel({
      key: {
        value: getBrandData?.value?.brand?.id?.toString(),
        error: "",
      },
      title: {
        value: getBrandData?.value?.brand?.title?.toString(),
        error: "",
      },
    });
    getBrandData?.value?.brand?.models?.length > 0 &&
      setModels(
        getBrandData?.value?.brand?.models.map((model, index) => ({
          id: "model_" + index,
          model: model,
        }))
      );
    setActu(true);
  }

  const handleChange = (event) => {
    const { name, value } = event.target;
    setBrandModel({
      ...brandModel,
      [name]: { value: value, error: "" },
    });
  };

  const handleChangeModel = (event, id: string, add: boolean = true) => {
    event.preventDefault();
    if (add) {
      setModels([
        ...models,
        {
          id: id,
          model: { id: "", brandId: "", title: "", description: "" },
        },
      ]);
    } else {
      const updatedModels = models.filter((model) => model.id !== id);
      setModels(updatedModels);
    }
    setErrorModels(false);
  };
  const handleChangeInputModel = (event, id: number) => {
    const { name, value } = event.target;

    const newModel = [...models];
    newModel[id] = {
      ...newModel[id],
      model: { ...newModel[id].model, [name]: value },
    };
    setModels(newModel);
    setErrorModels(false);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setErrorModels(false);

    const nameErr: Validator = validateFormData(
      brandModel?.title?.value,
      brandModelValidation?.title
    )?.errors;
    let modelsErr = false;

    setBrandModel({
      title: {
        ...brandModel?.title,
        error: nameErr?.message ?? "",
      },
    });

    models.map(
      (model) =>
        model.model.title === "" && (setErrorModels(true), (modelsErr = true))
    );

    if (!(nameErr?.message || modelsErr)) {
      const allModels: Model[] = [];
      models.map((model) => allModels.push(model.model));
      const valueUpdated = {
        key: getBrandData?.value?.brand?.id?.toString(),
        title: brandModel?.title?.value?.toString(),
        description: brandModel?.description?.value?.toString(),
        createdOn: brandModel?.createdOn?.value?.toString(),
        models: allModels,
      };

      dispatch(updateBrand(valueUpdated as UpdateBrandCommand));

      setShowServerErrorMessage(true);
      setShowServerSuccessMessage(true);
    }
  };

  return (
    <SidebarComponent
      ref={data?.func?.sidebarInstance}
      closeOnDocumentClick={false}
      showBackdrop={data?.func?.isShowBackdrop}
      width="700px"
      target=".apimaincontent"
      id="apiSidebar"
      className="tenant-sidebar"
      type={"Over"}
      enableGestures={false}
      position={"Right"}
      open={() => initialData()}
    >
      <div className="flex flex-col justify-start items-center h-full py-7 relative sidebar-grid">
        <div className="flex flex-row justify-between w-full px-9 mt- mb-2">
          <h2 className="text-3xl title">
            {data?.isEditing
              ? "Modification d'une marque"
              : "Ajouter une marque"}
          </h2>
          <span
            className="icon cursor-pointer cancelicon- text-2xl"
            onClick={data?.func?.sidebarClose?.bind(this)}
          ></span>
        </div>

        {getBrandData.errors &&
          showServerErrorMessage &&
          getBrandData.errors.length > 0 &&
          !getBrandData.pending &&
          getBrandData.errors.map((message, key) => {
            return (
              <div className="w-full px-2" id="msg_server" key={key}>
                <MessageComponent
                  showCloseIcon
                  id="msg_error"
                  className="errorServer p-1"
                  content={message}
                  key={key}
                  severity="Error"
                ></MessageComponent>
              </div>
            );
          })}

        {updateBrandData.errors &&
          showServerErrorMessage &&
          updateBrandData.errors.length > 0 &&
          !updateBrandData.pending &&
          updateBrandData.errors.map((message, key) => {
            return (
              <div className="w-full px-2" id="msg_server" key={key}>
                <MessageComponent
                  showCloseIcon
                  id="msg_error"
                  className="errorServer p-1"
                  content={message}
                  key={key}
                  severity="Error"
                ></MessageComponent>
              </div>
            );
          })}
        {updateBrandData.value &&
        showServerSuccessMessage &&
        !updateBrandData.pending ? (
          <div className="absolut mt-[25vh] h-[30vh] w-3/4 mx-auto">
            <OperationResultComponent
              message={
                data?.isEditing
                  ? "Vous avez modifié avec success cette marque"
                  : "Vous avez ajouté une nouvelle marque"
              }
              title={
                data?.isEditing ? "Modification de marque" : "Ajout de marque"
              }
              titleButton={"Fermez cette page et consultez la liste"}
            />
          </div>
        ) : getBrandData?.pending ? (
          <div className="flex flex-col py-4 px-8 w-full h-full gap-0 mx-auto">
            <div className="w-full mx-auto">
              <ShimmerText />
            </div>
            <div className="w-full mx-auto">
              <ShimmerText />
            </div>
            <div className="w-full mx-auto">
              <ShimmerText />
            </div>
          </div>
        ) : (
          <form
            className="flex flex-col justify-between items-center content py-4 px-8 w-full h-full"
            onSubmit={handleSubmit}
          >
            <div className="flex flex-col justify-start items-center gap-8 w-full py-8 px-4 form">
              {data?.isEditing && (
                <div className="help me-auto -mt-8">
                  <p className="help text-xl font-bold">
                    {getBrandData?.value?.brand?.title}
                  </p>
                </div>
              )}

              <fieldset className="w-full border px-10 py-5">
                <legend className="font-bold px-4 text-lg">Marque</legend>

                <div className="flex flex-col gap-3 name w-full">
                  <label htmlFor="nameBrand" className="text-base">
                    Nom de la marque
                  </label>
                  <InputWithIcon
                    type={"text"}
                    name={"title"}
                    id={"nameBrand"}
                    placeholder={"Nom de la marque"}
                    onChange={handleChange}
                    defaultValue={brandModel?.title?.value?.toString()}
                    value={brandModel?.title?.value?.toString()}
                    className={`w-full `}
                  />
                  {brandModel?.title?.error && (
                    <div className="error">{brandModel?.title?.error}</div>
                  )}
                </div>

                <div className="flex flex-col gap-3 createdOn w-full py-5">
                  <label htmlFor="description" className="text-base">
                    Description
                  </label>
                  <TextArea
                    name="description"
                    id="description"
                    defaultValue={""}
                    placeholder={"Description de la marque"}
                    cols={30}
                    rows={5}
                    className="w-full border px-2 py-1 input-sidebar bg-white"
                  ></TextArea>
                </div>
              </fieldset>

              <fieldset className="w-full border px-10 py-5">
                <legend className="font-bold px-4 text-lg">Modèles</legend>
                <p className="text-gray-700 text-help pb-4">
                  Lorem ipsum, dolor sit amet consectetur adipisicing elit.
                  Sapiente, provident expedita. Ab unde blanditiis asperiores
                  corporis veritatis, laboriosam quia pariatur vero debitis a
                  totam ipsum, fugit, corrupti ratione praesentium consequatur!
                </p>
                <div className="flex flex-col gap-4 justify-between w-full">
                  <div className="grid grid-cols-2 justify-start w-full">
                    <b>Nom</b>
                    <b className="-ms-10">Description</b>
                  </div>
                  {models?.map((model, index) => (
                    <div
                      className="flex flex-row gap-4 justify-between w-full"
                      key={index}
                    >
                      <InputWithIcon
                        type={"text"}
                        name={"title"}
                        id={`nameBrand_${index}`}
                        placeholder={`Nom du modèle`}
                        onChange={(e) => handleChangeInputModel(e, index)}
                        defaultValue={model?.model?.title?.toString()}
                        value={model?.model?.title?.toString()}
                        className={`w-full`}
                      />
                      <InputWithIcon
                        type={"text"}
                        name={"description"}
                        id={`descriptionBrand_${index}`}
                        placeholder={`Description du modèle`}
                        onChange={(e) => handleChangeInputModel(e, index)}
                        defaultValue={model?.model?.description?.toString()}
                        value={model?.model?.description?.toString()}
                        className={`w-full`}
                      />
                      <Button
                        param={{
                          type: "button",
                          name: (
                            <span className="icon cancelicon- rounded-full"></span>
                          ),
                          css: "deleteBtn w-fit p-2 rounded-full",
                          handleClick: (e) =>
                            handleChangeModel(e, model.id.toString(), false),
                        }}
                      />
                    </div>
                  ))}
                  <div className="flex flex-col gap-2 items-start w-full">
                    {errorModels && (
                      <div className="error w-full pb-2">
                        Veuillez remplir tous les paramètres de modèle de votre
                        marque
                      </div>
                    )}
                    <Button
                      param={{
                        type: "button",
                        name: "Ajouter",
                        css: " cancelBtn w-full",
                        handleClick: (e) => handleChangeModel(e, uuidv4()),
                      }}
                    />
                  </div>
                </div>
              </fieldset>
            </div>

            <div className="flex flex-row gap-4 justify-end footer px-4 py-4 ms-auto">
              <Button
                param={{
                  type: "button",
                  name: "Annuler",
                  handleClick: data?.func?.sidebarClose?.bind(this),
                  css:
                    (updateBrandData?.pending ? "disabled" : "") +
                    " cancelBtn w-full",
                  disabled: updateBrandData.pending,
                }}
              />
              <Button
                param={{
                  type: "submit",
                  name: "Valider",
                  handleClick: handleSubmit,
                  css:
                    (updateBrandData?.pending ? "disabled" : "") +
                    " okBtn w-full",
                  disabled: updateBrandData.pending,
                }}
              />
            </div>
          </form>
        )}
      </div>
    </SidebarComponent>
  );
}
