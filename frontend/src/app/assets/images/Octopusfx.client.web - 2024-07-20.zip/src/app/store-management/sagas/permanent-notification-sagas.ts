import { call, put, takeLatest } from "redux-saga/effects";
import { ActionTypes } from "../actions/constants/action-types";
import { ControllerApi } from "src/app/features/common/identity/permanent-notifications/locale/controller-api";
import { PermanentNotificationFailurePayload, UpdatePermanentNotificationAction, UpdatePermanentNotificationFailurePayload } from "../actions/permanent-notification-message";
import { countPermanentNotificationMessagesSuccess, permanentNotificationMessagesFailure, permanentNotificationMessagesSuccess, UpdatePermanentNotificationMessagesFailure, UpdatePermanentNotificationMessagesSuccess } from "../actions/permanent-notification-message/permanent-notification-actions";

const controllerApi = new ControllerApi();

const callApiToCountPermanentNotification = async () => controllerApi.countPermanentNotificationMessages();
const callApiToPermanentNotification = async () => controllerApi.getPermanentNotificationMessages();
const callApiToDeletePermanentNotification = async (command: UpdatePermanentNotificationCommand) => controllerApi.deleteNotifications(command);
const callApiToMarkreadPermanentNotification = async (command: UpdatePermanentNotificationCommand) => controllerApi.markReadNotification(command);

function* countPermanentNotificationSaga() {
  try {
    const response = yield call(callApiToCountPermanentNotification);

    if (response) {
      yield put(countPermanentNotificationMessagesSuccess(response as CountPermanentNotification));

    } else {
      let messages: string[] = [];
      response?.errorMessages.map((item) => {
        return messages.push(item.errorMessage);
      });
      yield put(permanentNotificationMessagesFailure({ errors: messages } as PermanentNotificationFailurePayload));
    }

  } catch (e) {
    let messages: string[] = [];
    messages.push(e.message);
    yield put(permanentNotificationMessagesFailure({ errors: messages } as PermanentNotificationFailurePayload));
  }
}

function* permanentNotificationSaga() {
  try {
    const response = yield call(callApiToPermanentNotification);


    if (response) {
      yield put(permanentNotificationMessagesSuccess(response as PermanentNotificationUser));
      const responseCountNotification = yield call(callApiToCountPermanentNotification);
      if (responseCountNotification) yield put(countPermanentNotificationMessagesSuccess(responseCountNotification as CountPermanentNotification));

    } else {
      let messages: string[] = [];
      response?.errorMessages.map((item) => {
        return messages.push(item.errorMessage);
      });
      yield put(permanentNotificationMessagesFailure({ errors: messages } as PermanentNotificationFailurePayload));
    }

  } catch (e) {
    let messages: string[] = [];
    messages.push(e.message);
    yield put(permanentNotificationMessagesFailure({ errors: messages } as PermanentNotificationFailurePayload));
  }
}

function* markReadPermanentNotificationsSaga(action: UpdatePermanentNotificationAction) {
  try {
    const response = yield call(callApiToMarkreadPermanentNotification, action.payload.command);


    if (response.hasSucceeded) {
      yield put(UpdatePermanentNotificationMessagesSuccess(response.payload as UpdatePermanentNotificationSuccessPayload));
      const responseNotification = yield call(callApiToPermanentNotification);
      if (responseNotification) yield put(permanentNotificationMessagesSuccess(responseNotification as PermanentNotificationUser));
    } else {
      let messages: string[] = [];
      response.errorMessages.map((item) => {
        return messages.push(item.errorMessage);
      });
      yield put(UpdatePermanentNotificationMessagesFailure({ errors: messages } as UpdatePermanentNotificationFailurePayload));
    }

  } catch (e) {
    let messages: string[] = [];
    messages.push(e.message);
    yield put(UpdatePermanentNotificationMessagesFailure({ errors: messages } as UpdatePermanentNotificationFailurePayload));
  }
}

function* deletePermanentNotificationsSaga(action: UpdatePermanentNotificationAction) {
  try {
    const response = yield call(callApiToDeletePermanentNotification, action.payload.command);

    if (response.hasSucceeded) {
      yield put(UpdatePermanentNotificationMessagesSuccess({ isCompleted: true } as UpdatePermanentNotificationSuccessPayload));
      const responseNotification = yield call(callApiToPermanentNotification);
      if (responseNotification) yield put(permanentNotificationMessagesSuccess(responseNotification as PermanentNotificationUser));
    } else {
      let messages: string[] = [];
      response.errorMessages.map((item) => {
        return messages.push(item.errorMessage);
      });
      yield put(UpdatePermanentNotificationMessagesFailure({ errors: messages } as UpdatePermanentNotificationFailurePayload));
    }

  } catch (e) {
    let messages: string[] = [];
    messages.push(e.message);
    yield put(UpdatePermanentNotificationMessagesFailure({ errors: messages } as UpdatePermanentNotificationFailurePayload));
  }
}

function* sortPermanentNotificationsSaga(action: UpdatePermanentNotificationAction) {
  try {
    const response = yield call(callApiToDeletePermanentNotification, action.payload.command);

    if (response.hasSucceeded) {
      yield put(UpdatePermanentNotificationMessagesSuccess({ isCompleted: true } as UpdatePermanentNotificationSuccessPayload));
      const responseNotification = yield call(callApiToPermanentNotification);
      if (responseNotification) yield put(permanentNotificationMessagesSuccess(responseNotification as PermanentNotificationUser));
    } else {
      let messages: string[] = [];
      response.errorMessages.map((item) => {
        return messages.push(item.errorMessage);
      });
      yield put(UpdatePermanentNotificationMessagesFailure({ errors: messages } as UpdatePermanentNotificationFailurePayload));
    }

  } catch (e) {
    let messages: string[] = [];
    messages.push(e.message);
    yield put(UpdatePermanentNotificationMessagesFailure({ errors: messages } as UpdatePermanentNotificationFailurePayload));
  }
}

export function* watchMyPermanentNotificationSaga() {
  yield takeLatest(ActionTypes.COUNT_PERMANENT_NOTIFICATION, countPermanentNotificationSaga);
  yield takeLatest(ActionTypes.GET_NOTIFICATIONS_REQUEST, permanentNotificationSaga);
  yield takeLatest(ActionTypes.MARK_READ_NOTIFICATIONS_REQUEST, markReadPermanentNotificationsSaga);
  yield takeLatest(ActionTypes.DELETE_NOTIFICATIONS_REQUEST, deletePermanentNotificationsSaga);
  yield takeLatest(ActionTypes.GRID_NOTIFICATIONS_SORTING_REQUEST, sortPermanentNotificationsSaga);
}
