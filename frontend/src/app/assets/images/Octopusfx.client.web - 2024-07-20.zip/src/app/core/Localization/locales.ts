
export const localesTranslations = {
  "fr-FR": {
    "grid": {
      "EmptyRecord": "Aucun enregistrement à afficher",
      "GroupDropArea": "Faites glisser un en-tête de colonne ici pour grouper par cette colonne",
      "UnGroup": "Cliquez ici pour dégrouper",
      "EmptyDataSourceError": "La source de données ne doit pas être vide au chargement initial",
      "Item": "Article",
      "Items": "Articles"
    },
    "pager": {
      "currentPageInfo": "{0} de {1} pages",
      "totalItemsInfo": "({0} articles)",
      "firstPageTooltip": "Aller à la première page",
      "lastPageTooltip": "Aller à la dernière page",
      "nextPageTooltip": "Aller à la page suivante",
      "previousPageTooltip": "Aller à la page précédente",
      "nextPagerTooltip": "Aller au pager suivant",
      "previousPagerTooltip": "Aller au pager précédent"
    },
    "dropdowns": {
      "noRecordsTemplate": "Aucun enregistrement trouvé",
      "actionFailureTemplate": "La requête a échoué"
    },
    "datepicker": {
      "placeholder": "Sélectionner une date",
      "today": "Aujourd'hui"
    }
  }
}
