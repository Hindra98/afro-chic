import { useState } from "react";
import { useNavigate } from "react-router-dom";
import * as Yup from "yup";
import Button from "src/app/components/form/Button";
import OperationSuccessComponent from "src/app/components/shared/operation-result-component";
import { ChangeEventArgs } from "@syncfusion/ej2/dropdowns";
import { DropDownListComponent } from "@syncfusion/ej2-react-dropdowns";
import { SwitchComponent } from "@syncfusion/ej2-react-buttons";
import "../../../styles/_settings.scss";

type ItemFields = {
  text: string;
  value: string;
  iconCss: string;
};

const UpdateTenantPreferences = () => {

  const navigate = useNavigate();

  const schema = Yup.object().shape({
    language: Yup.string(),
    datePattern: Yup.string(),
    isTwoFactorAuthenticationEnabled: Yup.boolean(),
  });

  const [tenantPreferencesViewModel, setTenantPreferencesViewModel] = useState({
    isTwoFactorAuthenticationEnabled: true,
  });
  const [errorsTenantPreferences, setErrorsTenantPreferences] = useState({
    language: "",
    datePattern: "",
  });
  const language: { [key: string]: Object }[] = [
    { "value": "en", "langue": "EN", "iconLang": "" },
    { "value": "fr", "langue": "FR", "iconLang": "" }
  ]
  const languageFields: ItemFields = { text: 'langue', value: 'value', iconCss: 'iconLang' };

  const datePattern: { [key: string]: Object }[] = [
    { "value": "d/m/y", "datePattern": "DD/MM/YYYY", "iconDate": "" },
    { "value": "d-m-y", "datePattern": "DD-MM-YYYY", "iconDate": "" }
  ]
  const datePatternFields: ItemFields = { text: 'datePattern', value: 'value', iconCss: 'iconDate' };

  const onChange = (args: ChangeEventArgs, item: string, itemFields: ItemFields) => {
    setTenantPreferencesViewModel({
      ...tenantPreferencesViewModel,
      [item]: (args.itemData === null) ? 'null' : args.itemData[itemFields.value].toString()
    });
  }
  
  const handleTenantPreferences = async (e) => {
    e.preventDefault();
    setErrorsTenantPreferences({
      language: "",
      datePattern: "",
    });
    const values = await schema.validate(tenantPreferencesViewModel);

    if (values.language === "" || values.datePattern === "") {
      let languageError = "",
        datePatternError = ""
        if (values.language === "")
          languageError = "Langue non valide";
        if (values.datePattern === "")
          datePatternError = "Format de date non valide";

      setErrorsTenantPreferences({
        language: languageError,
        datePattern: datePatternError,
      });
    } else {
      console.log("Donnees validees: ", tenantPreferencesViewModel)
    }
  };

  window.document.title = "Modifier les preferences de l'utilisateur";

  const returnPreviousPage = () => {
    navigate(-1);
  };

    return (
      <div className="h-full flex flex-col justify-between settings">
        {false ? (
          <div className="mb-auto">
            <OperationSuccessComponent
              message={"Vous avez modifié avec success vos données"}
              title="Modification des preferences utilisateur"
              titleButton="Valider"
              linkButton="/settings"
            />
          </div>
        ) : (
          <div className="form-fields w-full h-full px-3 py-5 bg-white xl:px-5 2xl:px-12 md:px-8">
            <div className="text-3xl align-top flex flex-row items-center justify-center flex-wrap my-5">
              <span
                className="e-icons left-circleicon- text-3xl cursor-pointer block me-auto"
                onClick={returnPreviousPage}
              ></span>
              <h1 className="text-right me-auto">Modification de l'abonnement</h1>
            </div>

            <form
              className="grid grid-cols-2 content-between justify-between items-stretch gap-8 mx-auto mt-12 mb-2 xmd:px-8 xxs:px-4"
              onSubmit={handleTenantPreferences}
            >
              <div className="xmd:col-span-1 xxs:col-span-2 p-2 flex flex-col justify-evenly xxs:gap-4">
                <div className="isTwoFactorAuthenticationEnabled flex flex-row justify-between">
                  <label htmlFor="isTwoFactorAuthenticationEnabled">J'accepte d'activer le deuxieme facteur d'authentification</label>
                  <SwitchComponent id="isTwoFactorAuthenticationEnabled" checked={tenantPreferencesViewModel.isTwoFactorAuthenticationEnabled} value="true" name="isTwoFactorAuthenticationEnabled" cssClass=""></SwitchComponent>
                </div>

                <div className="datePattern flex flex-col gap-2 justify-between">
                  <label htmlFor="datePattern">Format de date</label>
                  <DropDownListComponent cssClass="w-full border px-2 py-1 input-notify" id="datePattern" dataSource={datePattern} fields={datePatternFields} change={(args)=>onChange(args, "datePattern", datePatternFields)} placeholder="Choisir votre format de date" popupHeight="220px"  />
                  {errorsTenantPreferences.datePattern && (<div className="error">{errorsTenantPreferences.datePattern.toString()}</div>)}
                </div>

              </div>

              <div className="xmd:col-span-1 xxs:col-span-2 p-2 flex flex-col justify-start xxs:gap-4">
                <div className="language flex flex-col gap-2 justify-between">
                  <label htmlFor="language">Langue preferee</label>
                  <DropDownListComponent cssClass="w-full border px-2 py-1 input-notify" id="language" dataSource={language} fields={languageFields}  change={(args)=>onChange(args, "language", languageFields)} placeholder="Choisir votre langue" popupHeight="220px"  />
                  {errorsTenantPreferences.language && (<div className="error">{errorsTenantPreferences.language.toString()}</div>)}
                </div>
              </div>

              <div className="text-center my-3"></div>

              <Button param={{type: "submit", css: "px-5 py-3 mb-5 col-span-2 rounded-md mx-auto lg:w-3/5 xmd:w-4/5 xxs:w-full", name: "Valider"}} />
               
            </form>
          </div>
        )}
      </div>
    );
};

export default UpdateTenantPreferences;
