

export interface GetAuditsStoreShape {
  pending: boolean;
  Errors: string[];
  value: GetAudits;
}
export let getAuditsInitialState: GetAuditsStoreShape = {
  value: {
    auditItems: [],
  } as GetAudits,
  pending: false,
  Errors: [],
};

export interface GetAuditsFailurePayload {
  errors: string[];
}
export interface GetAuditsRequest {
  type: string;
  payload: string;
}
export interface GetAuditsSuccess {
  type: string;
  payload: GetAudits;
}
export interface GetAuditsFailure {
  type: string;
  payload: GetAuditsFailurePayload;
}
export interface GetAuditsPayload {
  command: string;
  user: GetAudits;
  errors: GetAuditsFailurePayload;
}
export interface GetAuditsAction {
  type: string;
  payload: GetAuditsPayload;
}
