import { all, fork } from "redux-saga/effects";
import { watchGetLanguagesSaga } from "./languages-sagas";
import { watchAuthenticateUserSaga } from "./oauth-sagas";
import { watchAccountUserSaga } from "./accounts-sagas";
import { watchUsersSaga } from "./users-sagas";
import { watchMyProfileSaga } from "./my-profile-sagas";
import { watchUserPreferencesSaga } from "./user-preferences-sagas";
import { watchMyPermanentNotificationSaga } from "./permanent-notification-sagas";
import { watchAppSettingsSaga } from "./app-settings-sagas";
import { watchTenantsSaga } from "./tenants-saga";
import { watchAgenciesSaga } from "./agencies-saga";
import { watchAuditsSaga } from "./audits-saga";
import { watchVehiclesSaga } from "./vehicles-sagas";
import { watchBrandsSaga } from "./brands-saga";

export default function* rootSaga() {
  yield all([
    fork(watchAuthenticateUserSaga),
    fork(watchAccountUserSaga),
    fork(watchGetLanguagesSaga),
    fork(watchUsersSaga),
    fork(watchMyProfileSaga),
    fork(watchMyPermanentNotificationSaga),
    fork(watchUserPreferencesSaga),
    fork(watchTenantsSaga),
    fork(watchAgenciesSaga),
    fork(watchAuditsSaga),
    fork(watchAppSettingsSaga),
    fork(watchVehiclesSaga),
    fork(watchBrandsSaga),
  ]);
}

export const getClaim = (decodedToken: string, claimKkey: string): string => {
  var claim = "";
  decodedToken
    .split(",")
    .filter((key) => key.toLocaleLowerCase().includes(`${claimKkey}`))
    .forEach((value) => {
      const element = value.split(":");
      const urlParams = element[1].split("/");
      const claimValue = urlParams[urlParams.length - 1].slice(0, -1);
      if (claimValue.toLocaleLowerCase() === claimKkey.toLocaleLowerCase())
        claim = element[2].slice(1, element[2].length - 1);
    });
  return claim;
};
