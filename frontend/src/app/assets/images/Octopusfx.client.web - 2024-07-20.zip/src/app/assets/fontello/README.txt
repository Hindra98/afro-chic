{
  "name": "octopusfx.client.web",
  "version": "0.1.0",
  "private": true,
  "dependencies": {
    "@browser-bunyan/server-stream": "^1.8.0",
    "@reduxjs/toolkit": "^2.2.1",
    "@syncfusion/ej2": "^25.1.40",
    "@syncfusion/ej2-base": "^25.1.35",
    "@syncfusion/ej2-icons": "^25.1.35",
    "@syncfusion/ej2-notifications": "^25.2.3",
    "@syncfusion/ej2-popups": "^25.1.38",
    "@syncfusion/ej2-react-base": "^25.1.35",
    "@syncfusion/ej2-react-buttons": "^25.1.39",
    "@syncfusion/ej2-react-dropdowns": "^25.1.39",
    "@syncfusion/ej2-react-grids": "^25.1.37",
    "@syncfusion/ej2-react-image-editor": "^25.1.40",
    "@syncfusion/ej2-react-inputs": "^25.1.40",
    "@syncfusion/ej2-react-lists": "^25.2.3",
    "@syncfusion/ej2-react-navigations": "^25.1.39",
    "@syncfusion/ej2-react-notifications": "^25.1.35",
    "@syncfusion/ej2-react-popups": "^25.1.41",
    "@syncfusion/ej2-react-splitbuttons": "^25.1.38",
    "@tailwindcss/forms": "^0.5.7",
    "@testing-library/jest-dom": "^5.17.0",
    "@testing-library/react": "^13.4.0",
    "@testing-library/user-event": "^13.5.0",
    "@types/jest": "^27.5.2",
    "@types/node": "^16.18.85",
    "@types/node-sass": "^4.11.7",
    "@types/qs": "^6.9.12",
    "@types/react": "^18.2.60",
    "@types/react-dom": "^18.2.19",
    "@types/uuid": "^9.0.8",
    "axios": "^1.6.7",
    "axios-retry": "^4.0.0",
    "browser-bunyan": "^1.8.0",
    "eslint": "^8.57.0",
    "formik": "^2.4.5",
    "i18next": "^23.10.0",
    "immer": "^10.0.3",
    "jwt-decode": "^4.0.0",
    "jwt-token": "^1.0.9",
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "react-error-boundary": "^4.0.13",
    "react-i18next": "^14.0.5",
    "react-redux": "^9.1.0",
    "react-router-dom": "^6.22.2",
    "react-scripts": "5.0.1",
    "redux": "^5.0.1",
    "redux-saga": "^1.3.0",
    "redux-thunk": "^3.1.0",
    "sass": "^1.72.0",
    "typescript": "^4.9.5",
    "web-vitals": "^2.1.4",
    "yup": "^1.4.0"
  },
  "scripts": {
    "start": "set PORT=5000 && react-scripts start",
    "build": "react-scripts build",
    "test": "jest",
    "eject": "react-scripts eject"
  },
  "eslintConfig": {
    "extends": [
      "react-app",
      "react-app/jest"
    ]
  },
  "browserslist": {
    "production": [
      ">0.2%",
      "not dead",
      "not op_mini all"
    ],
    "development": [
      "last 1 chrome version",
      "last 1 firefox version",
      "last 1 safari version"
    ]
  },
  "devDependencies": {
    "jest": "^27.5.1",
    "tailwindcss": "^3.4.1"
  }
}
