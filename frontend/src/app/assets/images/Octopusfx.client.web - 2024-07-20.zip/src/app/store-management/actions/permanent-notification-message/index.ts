export interface PermanentNotificationStoreShape {
  pending: boolean;
  Errors: string[];
  value: PermanentNotificationUser;
}
export interface CountPermanentNotificationStoreShape {
  pending: boolean;
  Errors: string[];
  value: CountPermanentNotification;
}
export let initialStatePermanentNotification: PermanentNotificationStoreShape =
{
  value: {
    userId: "",
    notificationCount: 0,
    payload: [],
  },
  pending: false,
  Errors: [],
};

export interface PermanentNotificationFailurePayload {
  errors: string[];
}
export interface PermanentNotificationRequest {
  type: string;
}
export interface PermanentNotificationSuccess {
  type: string;
  payload: PermanentNotificationUser;
}
export interface PermanentNotificationFailure {
  type: string;
  payload: PermanentNotificationFailurePayload;
}
export interface PermanentNotificationPayload {
  user: PermanentNotificationUser;
  errors: PermanentNotificationFailurePayload;
}
export interface PermanentNotificationAction {
  type: string;
  payload: PermanentNotificationPayload;
}

export interface CountPermanentNotificationSuccess {
  type: string;
  payload: CountPermanentNotification;
}
export interface CountPermanentNotificationPayload {
  user: CountPermanentNotification;
}
export interface CountPermanentNotificationAction {
  type: string;
  payload: CountPermanentNotificationPayload;
}



export interface UpdatePermanentNotificationStoreShape {
  pending: boolean;
  Errors: string[];
  value: boolean;
}
export let initialStateUpdatePermanentNotification: UpdatePermanentNotificationStoreShape =
{
  value: false,
  pending: false,
  Errors: [],
};

export interface UpdatePermanentNotificationModelShape {
  command: UpdatePermanentNotificationCommand;
}
export interface UpdatePermanentNotificationFailurePayload {
  errors: string[];
}
export interface UpdatePermanentNotificationRequest {
  type: string;
  payload: UpdatePermanentNotificationCommand;
}
export interface UpdatePermanentNotificationFailure {
  type: string;
  payload: UpdatePermanentNotificationFailurePayload;
}
export interface UpdatePermanentNotificationSuccess {
  type: string;
  payload: UpdatePermanentNotificationSuccessPayload;
}
export interface UpdatePermanentNotificationPayload {
  command: UpdatePermanentNotificationCommand;
  value: UpdatePermanentNotificationSuccessPayload;
  errors: UpdatePermanentNotificationFailurePayload;
}
export interface UpdatePermanentNotificationAction {
  type: string;
  payload: UpdatePermanentNotificationPayload;
}
