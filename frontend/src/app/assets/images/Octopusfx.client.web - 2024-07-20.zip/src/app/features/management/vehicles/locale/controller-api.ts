import { useDebounced } from "src/app/core/hooks";
import { HttpClient } from "../../../../http/http-client";

const updateVehicle = (http: HttpClient) => async (payload: object) => {
  const response = await http.post("/v1/vehicles/save", payload);
  const result: UpdateVehicleResult = response.data;
  
  return response !== undefined ? (result as UpdateVehicleResult) : undefined;
};

const deleteVehicle = (http: HttpClient) => async (payload: object) => {
  const response = await http.delete("/v1/vehicles/delete", payload);
  const result: DeleteVehicleResult = response.data;
  
  return response !== undefined ? (result as DeleteVehicleResult) : undefined;
};

const getVehicles = (http: HttpClient) => async () => {
  const response = await http.get("/v1/vehicles/get-all");
  const result: GetVehicles = response.data;

  return response !== undefined ? (result as GetVehicles) : undefined;
};

const getVehicle = (http: HttpClient) => async (payload: object) => {
  const response = await http.get("/v1/vehicles/get", payload);
  const result: GetVehicle = response.data;

  return response !== undefined ? (result as GetVehicle) : undefined;
};

const updateBrand = (http: HttpClient) => async (payload: object) => {
  const response = await http.post("/v1/brands/save", payload);
  const result: UpdateBrandResult = response.data;
  
  return response !== undefined ? (result as UpdateBrandResult) : undefined;
};

const deleteBrand = (http: HttpClient) => async (payload: object) => {
  const response = await http.delete("/v1/brands/delete", payload);
  const result: DeleteBrandResult = response.data;
  
  return response !== undefined ? (result as DeleteBrandResult) : undefined;
};

const getBrands = (http: HttpClient) => async () => {
  const response = await http.get("/v1/brands/get-all");
  const result: GetBrands = response.data;

  return response !== undefined ? (result as GetBrands) : undefined;
};

const getBrand = (http: HttpClient) => async (payload: object) => {
  const response = await http.get("/v1/brands/get", payload);
  const result: GetBrand = response.data;

  return response !== undefined ? (result as GetBrand) : undefined;
};


export class ControllerApi {
  private readonly http = new HttpClient();
  
  public readonly updateVehicle = Object.assign(updateVehicle(this.http), {
    useResponse: (
      handler: (result: UpdateVehicleResult) => unknown,
      args: Parameters<ReturnType<typeof updateVehicle>>[0]
    ) => useDebounced(() => this.updateVehicle(args).then(handler), Object.values(args), 500),
  });

  public readonly deleteVehicle = Object.assign(deleteVehicle(this.http), {
    useResponse: (
      handler: (result: DeleteVehicleResult) => unknown,
      args: Parameters<ReturnType<typeof deleteVehicle>>[0]
    ) => useDebounced(() => this.deleteVehicle(args).then(handler), Object.values(args), 500),
  });
  
  public readonly getVehicles = Object.assign(getVehicles(this.http), {
    useResponse: (
      handler: (result: GetVehicles) => unknown,
      args: Parameters<ReturnType<typeof getVehicles>>[]
    ) => useDebounced(() => this.getVehicles().then(handler), Object.values(args), 500),
  });
  
  public readonly getVehicle = Object.assign(getVehicle(this.http), {
    useResponse: (
      handler: (result: GetVehicle) => unknown,
      args: Parameters<ReturnType<typeof getVehicle>>[0]
    ) => useDebounced(() => this.getVehicle(args).then(handler), Object.values(args), 500),
  });
  
  public readonly updateBrand = Object.assign(updateBrand(this.http), {
    useResponse: (
      handler: (result: UpdateBrandResult) => unknown,
      args: Parameters<ReturnType<typeof updateBrand>>[0]
    ) => useDebounced(() => this.updateBrand(args).then(handler), Object.values(args), 500),
  });

  public readonly deleteBrand = Object.assign(deleteBrand(this.http), {
    useResponse: (
      handler: (result: DeleteBrandResult) => unknown,
      args: Parameters<ReturnType<typeof deleteBrand>>[0]
    ) => useDebounced(() => this.deleteBrand(args).then(handler), Object.values(args), 500),
  });
  
  public readonly getBrands = Object.assign(getBrands(this.http), {
    useResponse: (
      handler: (result: GetBrands) => unknown,
      args: Parameters<ReturnType<typeof getBrands>>[]
    ) => useDebounced(() => this.getBrands().then(handler), Object.values(args), 500),
  });
  
  public readonly getBrand = Object.assign(getBrand(this.http), {
    useResponse: (
      handler: (result: GetBrand) => unknown,
      args: Parameters<ReturnType<typeof getBrand>>[0]
    ) => useDebounced(() => this.getBrand(args).then(handler), Object.values(args), 500),
  });

}