import { useDebounced } from "src/app/core/hooks";
import { HttpClient } from "../../../../http/http-client";

const getAudits = (http: HttpClient) => async () => {
  const response = await http.get("/v1/audits/get-all");
  const result: GetAudits = response.data;

  return response !== undefined ? (result as GetAudits) : undefined;
};

export class ControllerApi {
  private readonly http = new HttpClient();

  public readonly getAudits = Object.assign(getAudits(this.http), {
    useResponse: (
      handler: (result: GetAudits) => unknown,
      args: Parameters<ReturnType<typeof getAudits>>[]
    ) => useDebounced(() => this.getAudits().then(handler), Object.values(args), 500),
  });

}