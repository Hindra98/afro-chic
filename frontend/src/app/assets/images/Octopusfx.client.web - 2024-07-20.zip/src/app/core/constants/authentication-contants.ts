export const AuthenticationConstants = {

    TENANT_ID: "tenant_id",
    ACCESS_TOKEN: "access_token",
    USER_LANGUAGE: "user_language",

}