import { Dispatch, SetStateAction } from "react";
import InputWithIcon from "src/app/components/form/Input";
import SwitchSettingsLine from "../switch-settings-line";
import CardSettings from "../card-settings";
import { useAppSelector } from "src/app/core/hooks/core-hooks";
import { ShimmerText } from "src/app/components/shared/shimmer";
import { useLocalizer } from "src/app/core/Localization";

type Props = {
  viewModel?: {
    isEnableKeyVault: boolean;
    urlKeyVault: string;
    tenantId: string;
    clientId: string;
    clientSecret: string;
  }
  setViewModel?: Dispatch<SetStateAction<{
    isEnableKeyVault: boolean;
    urlKeyVault: string;
    tenantId: string;
    clientId: string;
    clientSecret: string;
  }>>
  errorsAppSettings?;
};

const KeyVaultSettings = ({ errorsAppSettings = null, setViewModel, viewModel }: Props) => {
  const commonLocalizer = useLocalizer("Common-ResCommon");
  const getAppSettingsData = useAppSelector((state) => state.getAppSettings);

  const handleChangeSwitch = (e, text: string) => {
    const value = e.checked;
    setViewModel({
      ...viewModel,
      [text]: value,
    });
  };
  const handleChangeInput = (e) => {
    const { name, value } = e.target;
    setViewModel({
      ...viewModel,
      [name]: value,
    });
  };

  return (
    <>
      {getAppSettingsData.pending ? (<div className="p-0 m-0 w-full mx-auto"><ShimmerText /><ShimmerText /><ShimmerText /></div>) : (
        <CardSettings title={commonLocalizer("MODULE_COMMON_WEB_SETTINGS_AZURE_KEY_VAULT_TITLE")}>

          <SwitchSettingsLine change={(e) => handleChangeSwitch(e, "isEnableKeyVault")} title={commonLocalizer("MODULE_COMMON_WEB_SETTINGS_AZURE_KEY_VAULT_ENABLE")} name="isEnableKeyVault" description={commonLocalizer("MODULE_COMMON_WEB_SETTINGS_AZURE_KEY_VAULT_ENABLE_HELP")} checked={viewModel.isEnableKeyVault} />

          <div className="tenantId flex flex-col gap-2 justify-between w-full p-0 m-0">
            <div className="flex flex-row gap-5 justify-between items-center w-full p-0 m-0">
              <label htmlFor="tenantId" className={`w-1/3 ${!viewModel.isEnableKeyVault ? "label-disabled" : ""}`}>
                {commonLocalizer("MODULE_COMMON_WEB_SETTINGS_AZURE_KEY_VAULT_TENANT_ID")}
                <p className="font-normal text-sm user-help" title={commonLocalizer("MODULE_COMMON_WEB_SETTINGS_AZURE_KEY_VAULT_TENANT_ID_HELP")}>
                  {commonLocalizer("MODULE_COMMON_WEB_SETTINGS_AZURE_KEY_VAULT_TENANT_ID_HELP")}
                </p>
              </label>
              <div className="w-3/4">
                <InputWithIcon
                  type="text"
                  id='tenantId'
                  name='tenantId'
                  icon={``}
                  placeholder={commonLocalizer("MODULE_COMMON_WEB_SETTINGS_AZURE_KEY_VAULT_TENANT_ID")}
                  className={`w-full mx-auto ${!viewModel.isEnableKeyVault ? "label-disabled" : ""}`}
                  disabled={!viewModel.isEnableKeyVault}
                  value={viewModel.tenantId}
                  onChange={handleChangeInput}
                  eye={false}
                />
              </div>
            </div>
            {errorsAppSettings.tenantId &&
              (<div className="error">{errorsAppSettings.tenantId.toString()}</div>)}
          </div>

          <div className="urlKeyVault flex flex-col gap-2 justify-between w-full p-0 m-0">
            <div className="flex flex-row gap-5 justify-between items-center w-full p-0 m-0">
              <label htmlFor="urlKeyVault" className={`w-1/3 ${!viewModel.isEnableKeyVault ? "label-disabled" : ""}`}>
                {commonLocalizer("MODULE_COMMON_WEB_SETTINGS_AZURE_KEY_VAULT_URL")}
                <p className="font-normal text-sm user-help" title={commonLocalizer("MODULE_COMMON_WEB_SETTINGS_AZURE_KEY_VAULT_URL_HELP")}>
                  {commonLocalizer("MODULE_COMMON_WEB_SETTINGS_AZURE_KEY_VAULT_URL_HELP")}
                </p>
              </label>
              <div className="w-3/4">
                <InputWithIcon
                  type="text"
                  id='urlKeyVault'
                  name='urlKeyVault'
                  icon={``}
                  placeholder={commonLocalizer("MODULE_COMMON_WEB_SETTINGS_AZURE_KEY_VAULT_URL")}
                  className={`w-full mx-auto  ${!viewModel.isEnableKeyVault ? "label-disabled" : ""}`}
                  disabled={!viewModel.isEnableKeyVault}
                  value={viewModel.urlKeyVault}
                  onChange={handleChangeInput}
                  eye={false}
                />
              </div>
            </div>
            {errorsAppSettings.urlKeyVault &&
              (<div className="error">{errorsAppSettings.urlKeyVault.toString()}</div>)}
          </div>

          <div className="clientId flex flex-col gap-2 justify-between w-full p-0 m-0">
            <div className="flex flex-row gap-5 justify-between items-center w-full p-0 m-0">
              <label htmlFor="clientId" className={`w-1/3 ${!viewModel.isEnableKeyVault ? "label-disabled" : ""}`}>
                {commonLocalizer("MODULE_COMMON_WEB_SETTINGS_AZURE_KEY_VAULT_CLIENT_ID")}
                <p className="font-normal text-sm user-help" title={commonLocalizer("MODULE_COMMON_WEB_SETTINGS_AZURE_KEY_VAULT_CLIENT_ID_HELP")}>
                  {commonLocalizer("MODULE_COMMON_WEB_SETTINGS_AZURE_KEY_VAULT_CLIENT_ID_HELP")}
                </p>
              </label>
              <div className="w-3/4">
                <InputWithIcon
                  type="text"
                  id='clientId'
                  name='clientId'
                  icon={``}
                  placeholder={commonLocalizer("MODULE_COMMON_WEB_SETTINGS_AZURE_KEY_VAULT_CLIENT_ID")}
                  className={`w-full mx-auto  ${!viewModel.isEnableKeyVault ? "label-disabled" : ""}`}
                  disabled={!viewModel.isEnableKeyVault}
                  value={viewModel.clientId}
                  onChange={handleChangeInput}
                  eye={false}
                />
              </div>
            </div>
            {errorsAppSettings.clientId &&
              (<div className="error">{errorsAppSettings.clientId.toString()}</div>)}
          </div>

          <div className="clientSecret flex flex-col gap-2 justify-between w-full p-0 m-0">
            <div className="flex flex-row gap-5 justify-between items-center w-full p-0 m-0">
              <label htmlFor="clientSecret" className={`w-1/3 ${!viewModel.isEnableKeyVault ? "label-disabled" : ""}`}>
                {commonLocalizer("MODULE_COMMON_WEB_SETTINGS_AZURE_KEY_VAULT_SECRET")}
                <p className="font-normal text-sm user-help" title={commonLocalizer("MODULE_COMMON_WEB_SETTINGS_AZURE_KEY_VAULT_SECRET_HELP")}>
                  {commonLocalizer("MODULE_COMMON_WEB_SETTINGS_AZURE_KEY_VAULT_SECRET_HELP")}
                </p>
              </label>
              <div className="w-3/4">
                <InputWithIcon
                  type="text"
                  id='clientSecret'
                  name='clientSecret'
                  icon={``}
                  placeholder={commonLocalizer("MODULE_COMMON_WEB_SETTINGS_AZURE_KEY_VAULT_SECRET")}
                  className={`w-full mx-auto  ${!viewModel.isEnableKeyVault ? "label-disabled" : ""}`}
                  disabled={!viewModel.isEnableKeyVault}
                  value={viewModel.clientSecret}
                  onChange={handleChangeInput}
                  eye={false}
                />
              </div>
            </div>
            {errorsAppSettings.clientSecret &&
              (<div className="error">{errorsAppSettings.clientSecret.toString()}</div>)}
          </div>

        </CardSettings>
      )}
    </>
  );
};

export default KeyVaultSettings;
