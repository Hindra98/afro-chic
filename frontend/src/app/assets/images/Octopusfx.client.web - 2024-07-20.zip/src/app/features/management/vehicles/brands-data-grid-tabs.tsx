import {
  ColumnDirective,
  ColumnsDirective,
  Edit,
  ExcelExport,
  ExcelExportProperties,
  Filter,
  Sort,
  GridComponent,
  Inject,
  Page,
  PdfExport,
  PdfExportProperties,
  Resize,
  Selection,
  RecordClickEventArgs,
  DetailRow,
} from "@syncfusion/ej2-react-grids";
import { useEffect, useRef, useState } from "react";
import { useAppDispatch, useAppSelector } from "src/app/core/hooks/core-hooks";
import "src/app/styles/_notifications.scss";
import ToolsbarOptions from "src/app/components/shared/grid-components/toolsbar-options";
import emptyrecords from "src/app/components/shared/grid-components/empty-records";
import iconBrand from "src/app/assets/image-octopusfx/user.png";
import { GridConstants } from "src/app/core/constants/data-grid";
import { deleteBrand, getBrand, getBrands } from "src/app/store-management/actions/brands/brands-actions";
import { MessageComponent } from "@syncfusion/ej2-react-notifications";

function nameTemplate(props: Brand) {
  return (
    <span
      className={`name-link cursor-pointer hover:text-blue-900 hover:underline hover:font-bold`}
    >
      {props.title}
    </span>
  );
}

type Props = {
  isShowBackdrop?
  isEditing?
  setIsEditing?
  sidebarInstance?
  sidebarClose?
  setShowBackdrop?
  setTiltleDialog?
  setBtnDialog?
  setMessageDialog?
  openDialog?
}

const BrandDataGridTabs = (props: Props) => {

  let brandGrid = useRef<GridComponent>(null);
  const dispatch = useAppDispatch();

  const getAllBrands = useAppSelector((state) => state.getBrands);
  const deleteBrandData = useAppSelector((state) => state.deleteBrand);

  const [getRefresh, setGetRefresh] = useState(false);
  const [checkRow, setCheckRow] = useState(false);
  const exportFilename = "marque_vehicule";
  const rowsPerPage = 5;
  const [currentPage, setCurrentPage] = useState(1);

  const getBrandsData = () => {
    dispatch(getBrands());
  };
  const getBrandInfos = (id: string) => {
    dispatch(getBrand({ SearchCriteria: id } as BrandCommand));
  };

  function CheckRowsTemplate() {
    const [check, setCheck] = useState(false)
    const handleSelectAllRows = () => {
      let tabs: number[] = [];
      for (let key = 0; key < rowsPerPage; key++) { tabs.push(key) }
      if (brandGrid?.current?.getAllDataRows().length > 0) {
        (check) ? brandGrid?.current?.selectRows([]) : brandGrid?.current?.selectRows(tabs);
        setCheck(!check);
        setCheckRow(!check);
      }
    }
    return (
      <div className="ms-[8px]" onClick={handleSelectAllRows}>
        <span className={`cursor-pointer icon ${check ? "checkicon- text-blue-900" : "check-emptyicon-"} text-[19px]`}></span>
      </div>
    );
  }

  useEffect(() => {
    setCheckRow(brandGrid?.current?.getSelectedRecords()?.length > 0);
  }, [brandGrid]);

  if (
    !getRefresh &&
    !getAllBrands?.pending &&
    !getAllBrands?.value?.hasAlreadyCalled &&
    getAllBrands?.errors?.length === 0
  ) {
    getBrandsData();
    setGetRefresh(true);
  }

  const [tenantViewModel, setBrandViewModel] = useState<any>({});

  const handleActionBegin = (args: any) => {
    if (args.requestType === "add" || args.requestType === "beginEdit") {
      props.sidebarInstance?.current?.toggle();
      props.setShowBackdrop(true);
      args.cancel = true;
    }
  };


  const handleAdd = () => {
    if (brandGrid.current) {
      props.setIsEditing(false);
      getBrandInfos("");
      brandGrid.current.addRecord();
    }
  };

  const handleClickRecord = (e: RecordClickEventArgs) => {
    if (brandGrid.current) {
      const index = e.cellIndex;
      let keyRecord = e.rowData as Brand;

      const selectedRecordsLength =
        brandGrid.current.getSelectedRecords() as Brand[];
      if (
        selectedRecordsLength.length > 1 ||
        selectedRecordsLength.length === 0
      )
        setCheckRow(true);
      else {
        if (selectedRecordsLength[0].id === keyRecord.id)
          setCheckRow(false);
        else setCheckRow(true);
      }
      if (index > 0) {
        getBrandInfos(keyRecord.id);
        props.setIsEditing(true);
        setBrandViewModel({ ...tenantViewModel, id: keyRecord.id });
        brandGrid.current.addRecord();
      }
    }
  };

  const handleDelete = () => {
    if (brandGrid.current) {
      const selectedRecords =
        brandGrid.current.getSelectedRecords() as Brand[];
      if (selectedRecords.length === 1) {
        const delValue = { BrandId: selectedRecords[0]?.id.toString() }
        props.setTiltleDialog(`Suppression d'une marque: ${selectedRecords[0]?.title}`);
        props.setMessageDialog(
          <p>
            Voulez-vous vraiment supprimer cette marque : <b>{selectedRecords[0]?.title}</b> ?<br />
            Nom: <b>{selectedRecords[0]?.title}</b><br />
            Nombre de modèles: <b>{selectedRecords[0]?.models.length.toString()}</b><br />
          </p>
        );
        props.setBtnDialog([
          {
            type: "button",
            name: "Annuler",
            css: "cancelBtn",
            handleClick: () => props?.openDialog[1](false),
          },
          {
            type: "button",
            name: "Confirmer",
            css: "okBtn",
            handleClick: () => { dispatch(deleteBrand(delValue as DeleteBrandCommand)); props?.openDialog[1](false) }
          },
        ]);
        props?.openDialog[1](true);

      } else {
        props.setTiltleDialog(`Erreur!!!`);
        props.setMessageDialog(<p>Vous devez selectionner une et une seule marque pour cette opération</p>);
        props.setBtnDialog([
          {
            type: "button",
            name: "Ok",
            css: "okBtn",
            handleClick: () => props?.openDialog[1](false),
          }
        ]);
        props?.openDialog[1](true);
      }
    }
  };


  const editSettings: any = {
    allowEditing: true,
    allowAdding: true,
    allowDeleting: true,
    mode: "Normal",
    allowEditOnDblClick: false,
  };
  const handlePageChange = (page: number) => {
    brandGrid.current.pageSettings.currentPage = page;
    setCurrentPage(page);
  };
  const handleSearch = (searchText: string) => {
    console.log("handle", searchText);
  };

  const select: any = {
    persistSelection: true,
    type: "Single",
    checkboxOnly: false,
    mode: "Both",
    checkboxMode: "ResetOnRowClick",
  };


  const gridFilter: any = { type: "Menu" };
  const pdfExportProperties: PdfExportProperties = {
    header: {
      fromTop: 0,
      height: 130,
      contents: [
        {
          type: "Line",
          style: { penColor: "#000080", penSize: 2, dashStyle: "Solid" },
          points: { x1: 0, y1: 4, x2: 685, y2: 4 },
        },
        {
          type: "Text",
          value: "Liste des marques de véhicules",
          position: { x: 200, y: 50 },
          style: { textBrushColor: "#000000", fontSize: 20 },
        },
      ],
    },
    footer: {
      fromBottom: 10,
      height: 60,
      contents: [
        {
          type: "Line",
          style: { penColor: "#000080", penSize: 2, dashStyle: "Dot" },
          points: { x1: 0, y1: 4, x2: 685, y2: 4 },
        },
        {
          type: "PageNumber",
          pageNumberType: "Arabic",
          format: "Page {$current} sur {$total}",
          position: { x: 0, y: 25 },
          style: { textBrushColor: "#4169e1", fontSize: 15, hAlign: "Center" },
        },
      ],
    },
    exportType: "AllPages",
  };

  const ExportPdf = () => {
    (brandGrid.current as GridComponent)?.pdfExport({
      ...pdfExportProperties,
      fileName: `${exportFilename}.pdf`,
    });
  };
  const ExportExcel = () => {
    const excelExportProperties: ExcelExportProperties = {
      exportType: "AllPages",
      fileName: `${exportFilename}.xlsx`,
    };
    (brandGrid.current as GridComponent)?.excelExport({ ...excelExportProperties });
  };
  const ExportCsv = () => {
    const excelExportProperties: ExcelExportProperties = {
      exportType: "AllPages",
      fileName: `${exportFilename}.csv`,
    };
    (brandGrid.current as GridComponent)?.csvExport({ ...excelExportProperties });
  };

  return (
    <div className="h-full flex flex-col justify-start mx-auto notifications-component">

      {deleteBrandData.errors &&
        !deleteBrandData.value &&
        deleteBrandData.errors.length > 0 &&
        !deleteBrandData.pending &&
        deleteBrandData.errors.map((message, key) => {
          return (
            <div className="w-full mx-auto" id="msg_server" key={key}>
              <MessageComponent
                showCloseIcon
                id="msg_error"
                className="errorServer m-1"
                content={"Erreur lors de la suppression de l'utilisateur: " + message}
                key={key}
                severity="Error"
              ></MessageComponent>
            </div>
          );
        })}

      <ToolsbarOptions
        ToolsbarActionItem={[
          {
            icon: "user-addicon-",
            name: "Ajouter",
            handleClick: () => handleAdd(),
          },
          {
            icon: "trash-emptyicon-",
            name: "Supprimer",
            handleClick: () => handleDelete(),
            disabled: !checkRow,
          },
          {
            icon: "ccwicon-",
            name: "Rafraichir",
            handleClick: () => dispatch(getBrands()),
          },
        ]}
        allowExportPdf
        allowExportCsv
        allowExportExcel
        handleExportPdf={ExportPdf}
        handleExportExcel={ExportExcel}
        handleExportCsv={ExportCsv}
        enablePager
        pager={{ align: "right" }}
        enablePagination
        pagination={{
          currentPage: currentPage,
          rowsPerPage: rowsPerPage,
          totalPages: parseInt(getAllBrands?.value?.brands?.length.toString()),
          handleChangePage: handlePageChange,
        }}
        enableSearch
        search={{ handleSearch: handleSearch }}
      />
      <GridComponent
        dataSource={getAllBrands.value.brands}
        detailTemplate={modelTemplate}
        
        id="notifications-grid"
        cssClass="mx-2"
        loadingIndicator={{ indicatorType: "Shimmer" }}
        allowResizing={true}
        enableHover={true}
        allowSorting={false}
        allowFiltering={true}
        actionBegin={handleActionBegin}
        recordClick={handleClickRecord}
        emptyRecordTemplate={() =>
          emptyrecords(
            "Aucune marque trouvée",
            iconBrand,
            getAllBrands.pending,
            "w-1/12"
          )
        }
        resizeSettings={{ mode: "Auto" }}
        height={GridConstants.HEIGHT_VEHICLE}
        filterSettings={gridFilter}
        allowSelection={true}
        selectionSettings={select}
        enableHeaderFocus={true}
        allowPaging={true}
        autoFit={true}
        allowPdfExport={true}
        allowExcelExport={true}
        editSettings={editSettings}
        pageSettings={{ pageCount: 2, pageSize: rowsPerPage }}
        ref={brandGrid}
      >
        <ColumnsDirective>
          <ColumnDirective
            type="checkbox"
            allowSorting={false}
            allowFiltering={false}
            headerTemplate={CheckRowsTemplate}
            width="40"
          ></ColumnDirective>
          <ColumnDirective
            field="id"
            visible={false}
            headerText="Identifiant de la marque"
            isPrimaryKey={true}
            width="auto"
          ></ColumnDirective>
          <ColumnDirective
            field="title"
            headerText="Nom de la marque"
            template={nameTemplate}
            clipMode="EllipsisWithTooltip"
            width="auto"
          />
        </ColumnsDirective>
        <Inject
          services={[
            Page,
            Filter,
            Sort,
            PdfExport,
            ExcelExport,
            Resize,
            Selection,
            Edit,
            DetailRow,
          ]}
        />
      </GridComponent>

    </div>
  )
}

const modelTemplate = (props: { models: any[] }) => {
  return (
    <GridComponent dataSource={props.models} allowPaging={true} pageSettings={{ pageSize: 5 }}>
      <ColumnsDirective>
        <ColumnDirective field='title' headerText='Nom' width='150' />
        <ColumnDirective field='description' headerText='Description' width='150' />
      </ColumnsDirective>
    </GridComponent>
  );
}

export default BrandDataGridTabs