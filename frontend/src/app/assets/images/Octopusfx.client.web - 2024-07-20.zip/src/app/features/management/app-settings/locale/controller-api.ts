import { useDebounced } from "src/app/core/hooks";
import { HttpClient } from "../../../../http/http-client";

const updateAppSettings = (http: HttpClient) => async (payload: object) => {
  const response = await http.post("/v1/appsettings/save", payload);
  const result: UpdateAppSettingsResult = response.data;
  
  return response !== undefined ? (result as UpdateAppSettingsResult) : undefined;
};

const getAppSettings = (http: HttpClient) => async () => {
  const response = await http.get("/v1/appsettings/get");
  const result: GetAppSettings = response.data;

  return response !== undefined ? (result as GetAppSettings) : undefined;
};

export class ControllerApi {
  private readonly http = new HttpClient();
  public readonly updateAppSettings = Object.assign(updateAppSettings(this.http), {
    useResponse: (
      handler: (result: UpdateAppSettingsResult) => unknown,
      args: Parameters<ReturnType<typeof updateAppSettings>>[0]
    ) => useDebounced(() => this.updateAppSettings(args).then(handler), Object.values(args), 500),
  });
  
  public readonly getAppSettings = Object.assign(getAppSettings(this.http), {
    useResponse: (
      handler: (result: GetAppSettings) => unknown,
      args: Parameters<ReturnType<typeof getAppSettings>>
    ) => useDebounced(() => this.getAppSettings().then(handler), Object.values(args), 500),
  });

}