import { call, put, takeLatest } from "redux-saga/effects";
import { ControllerApi } from "src/app/features/management/audits/locale/controller-api";
import { ActionTypes } from "../actions/constants/action-types";
import { getAuditsFailure, getAuditsSuccess } from "../actions/audits/audits-actions";
import { GetAuditsFailurePayload } from "../actions/audits";

const controllerApi = new ControllerApi();

const callApiToGetAudits = async () => controllerApi.getAudits();

function* getAuditsSaga() {
  try {
    const response = yield call(callApiToGetAudits);
    if (response) {
      yield put(getAuditsSuccess(response as GetAudits));
    } else {
      let messages: string[] = [];
      response?.errorMessages.map((item) => {
        return messages.push(item.errorMessage);
      });
      yield put(getAuditsFailure({ errors: messages } as GetAuditsFailurePayload));
    }

  } catch (e) {
    let messages: string[] = [];
    messages.push(e.message);
    yield put(getAuditsFailure({ errors: messages } as GetAuditsFailurePayload));
  }
}


export function* watchAuditsSaga() {
  yield takeLatest(ActionTypes.GET_AUDITS_REQUEST, getAuditsSaga);
}
