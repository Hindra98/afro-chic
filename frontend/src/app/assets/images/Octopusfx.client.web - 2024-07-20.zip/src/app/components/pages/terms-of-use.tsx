const CominSoon = () => {
    return (<></>)
}

export default CominSoon;