
import { ActionTypes } from "../constants/action-types";
import { UpdateUserPreferencesAction, UpdateUserPreferencesFailurePayload, GetUserPreferencesAction, GetUserPreferencesFailurePayload, UpdateUserPreferencesSuccessPayload } from '.';

export const updateUserPreferences = (command: UpdateUserPreferencesCommand): UpdateUserPreferencesAction => {

    return {
        type: ActionTypes.UPDATE_USER_PREFERENCES_REQUEST,
        payload: {
            command: command,
            value: {value: false},
            errors: null
        }
    } as UpdateUserPreferencesAction
  };
  
  export const updateUserPreferencesSuccess = (payload: UpdateUserPreferencesSuccessPayload): UpdateUserPreferencesAction => {

    return {
        type: ActionTypes.UPDATE_USER_PREFERENCES_SUCCESS,
        payload: {
            command: null,
            value: payload,
            errors: null
        }
    } as UpdateUserPreferencesAction;
  };
  
  export const updateUserPreferencesFailure = (payload: UpdateUserPreferencesFailurePayload): UpdateUserPreferencesAction => {

    return {
        type: ActionTypes.UPDATE_USER_PREFERENCES_FAILURE,
        payload: {
            command: null,
            value: {value: false},
            errors: payload
        }
    } as UpdateUserPreferencesAction;
  };

  export const getUserPreferences = (command: ""): GetUserPreferencesAction => {
  
      return {
          type: ActionTypes.GET_USER_PREFERENCES_REQUEST,
          payload: {
              command: command,
              user: null,
              errors: null
          }
      } as GetUserPreferencesAction
    };
    
    export const getUserPreferencesFailure = (payload: GetUserPreferencesFailurePayload, errServer:ServerErrorMessageItem): GetUserPreferencesAction => {
  
      return {
          type: ActionTypes.GET_USER_PREFERENCES_FAILURE,
          payload: {
              command: null,
              user: null,
              errors: payload,
              errServer: errServer
          }
      } as GetUserPreferencesAction;
    };
    
    export const getUserPreferencesSuccess = (payload: GetUserPreferences): GetUserPreferencesAction => {
  
      return {
          type: ActionTypes.GET_USER_PREFERENCES_SUCCESS,
          payload: {
              command: null,
              user: payload,
              errors: null
          }
      } as GetUserPreferencesAction;
    };