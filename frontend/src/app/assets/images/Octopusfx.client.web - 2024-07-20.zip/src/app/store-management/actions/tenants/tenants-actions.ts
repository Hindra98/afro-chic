
import { AddTenantAction, AddTenantFailurePayload, AddTenantSuccessPayload, DeleteTenantAction, DeleteTenantFailurePayload, DeleteTenantSuccessPayload, ExportPdfTenantsAction, ExportPdfTenantsFailurePayload, GetTenantsAction, GetTenantsFailurePayload, TenantAction, TenantFailurePayload, UpdateTenantAction, UpdateTenantFailurePayload, UpdateTenantSuccessPayload } from ".";
import { ActionTypes } from "../constants/action-types";

  export const getTenants = (): GetTenantsAction => {
  
      return {
          type: ActionTypes.GET_TENANTS_REQUEST,
          payload: {
              command: null,
              user: null,
              errors: null
          }
      } as GetTenantsAction
    };
    
    export const getTenantsFailure = (payload: GetTenantsFailurePayload, errServer:ServerErrorMessageItem): GetTenantsAction => {
  
      return {
          type: ActionTypes.GET_TENANTS_FAILURE,
          payload: {
              command: null,
              user: null,
              errors: payload,
              errServer: errServer
          }
      } as GetTenantsAction;
    };
    
    export const getTenantsSuccess = (payload: GetTenants): GetTenantsAction => {
  
      return {
          type: ActionTypes.GET_TENANTS_SUCCESS,
          payload: {
              command: null,
              user: payload,
              errors: null
          }
      } as GetTenantsAction;
    };

  export const getTenant = (command: TenantCommand): TenantAction => {
  
    return {
        type: ActionTypes.GET_TENANT_REQUEST,
        payload: {
            command: command,
            user: null,
            errors: null
        }
    } as TenantAction
  };
  
  export const getTenantFailure = (payload: TenantFailurePayload, errServer:ServerErrorMessageItem): TenantAction => {

    return {
        type: ActionTypes.GET_TENANT_FAILURE,
        payload: {
            command: null,
            user: null,
            errors: payload
        }
    } as TenantAction;
  };
  
  export const getTenantSuccess = (payload: GetTenant): TenantAction => {

    return {
        type: ActionTypes.GET_TENANT_SUCCESS,
        payload: {
            command: null,
            user: payload,
            errors: null
        }
    } as TenantAction;
  };

  export const addTenant = (command: FormData): AddTenantAction => {

    return {
        type: ActionTypes.ADD_TENANT_REQUEST,
        payload: {
            command: command,
            value: {value: false},
            errors: null
        }
    } as AddTenantAction
  };

  export const addTenantSuccess = (payload: AddTenantSuccessPayload): AddTenantAction => {

    return {
        type: ActionTypes.ADD_TENANT_SUCCESS,
        payload: {
            command: null,
            value: payload,
            errors: null
        }
    } as AddTenantAction
  };

  export const addTenantFailure = (payload: AddTenantFailurePayload): AddTenantAction => {

    return {
        type: ActionTypes.ADD_TENANT_FAILURE,
        payload: {
            command: null,
            value: null,
            errors: payload
        }
    } as AddTenantAction
  };

  export const updateTenant = (command: FormData): UpdateTenantAction => {

    return {
        type: ActionTypes.UPDATE_TENANT_REQUEST,
        payload: {
            command: command,
            value: {value: false},
            errors: null
        }
    } as UpdateTenantAction
  };

  export const updateTenantSuccess = (payload: UpdateTenantSuccessPayload): UpdateTenantAction => {

    return {
        type: ActionTypes.UPDATE_TENANT_SUCCESS,
        payload: {
            command: null,
            value: payload,
            errors: null
        }
    } as UpdateTenantAction
  };

  export const updateTenantFailure = (payload: UpdateTenantFailurePayload): UpdateTenantAction => {

    return {
        type: ActionTypes.UPDATE_TENANT_FAILURE,
        payload: {
            command: null,
            value: null,
            errors: payload
        }
    } as UpdateTenantAction
  };

  
  export const deleteTenant = (command: DeleteTenantCommand): DeleteTenantAction => {

    return {
        type: ActionTypes.DELETE_TENANTS_REQUEST,
        payload: {
            command: command,
            value: {value: false},
            errors: null
        }
    } as DeleteTenantAction
  };

  export const deleteTenantSuccess = (payload: DeleteTenantSuccessPayload): DeleteTenantAction => {

    return {
        type: ActionTypes.DELETE_TENANTS_SUCCESS,
        payload: {
            command: null,
            value: payload,
            errors: null
        }
    } as DeleteTenantAction
  };

  export const deleteTenantFailure = (payload: DeleteTenantFailurePayload): DeleteTenantAction => {

    return {
        type: ActionTypes.DELETE_TENANTS_FAILURE,
        payload: {
            command: null,
            value: null,
            errors: payload
        }
    } as DeleteTenantAction
  };

  
  export const exportPdfTenants = (command: FormData): ExportPdfTenantsAction => {
  
    return {
        type: ActionTypes.EXPORT_PDF_TENANTS_REQUEST,
        payload: {
            command: command,
            user: null,
            errors: null
        }
    } as ExportPdfTenantsAction
  };
  
  export const exportPdfTenantsFailure = (payload: ExportPdfTenantsFailurePayload): ExportPdfTenantsAction => {

    return {
        type: ActionTypes.EXPORT_PDF_TENANTS_FAILURE,
        payload: {
            command: null,
            user: null,
            errors: payload
        }
    } as ExportPdfTenantsAction;
  };
  
  export const exportPdfTenantsSuccess = (payload: {value: boolean}): ExportPdfTenantsAction => {

    return {
        type: ActionTypes.EXPORT_PDF_TENANTS_SUCCESS,
        payload: {
            command: null,
            user: payload,
            errors: null
        }
    } as ExportPdfTenantsAction;
  };
