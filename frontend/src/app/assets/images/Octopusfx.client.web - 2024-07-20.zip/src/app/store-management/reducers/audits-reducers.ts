import { produce } from "immer";
import { ActionTypes } from "../actions/constants/action-types";
import { GetAuditsAction, getAuditsInitialState, GetAuditsStoreShape } from "../actions/audits";


export const getAuditsReducer = (state: GetAuditsStoreShape = getAuditsInitialState, args: GetAuditsAction): GetAuditsStoreShape => {

  switch (args.type) {

    case ActionTypes.GET_AUDITS_REQUEST:
      return produce(state, (draftState) => {
        draftState.pending = true;
        draftState.Errors = [];
      });

    case ActionTypes.GET_AUDITS_FAILURE:
      return produce(state, (draftState) => {
        draftState.Errors = args.payload?.errors?.errors;
        draftState.pending = false;
      });

    case ActionTypes.GET_AUDITS_SUCCESS:
      return produce(state, (draftState) => {
        draftState.Errors = [];
        draftState.value.auditItems = args?.payload?.user?.auditItems

        draftState.pending = false;
      });

    default:
      return state;
  }
};