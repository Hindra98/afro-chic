
import { ActionTypes } from "../constants/action-types";
import { UpdateAppSettingsAction, UpdateAppSettingsFailurePayload, GetAppSettingsAction, GetAppSettingsFailurePayload, UpdateAppSettingsSuccessPayload } from '.';

export const updateAppSettings = (command: UpdateAppSettingsCommand): UpdateAppSettingsAction => {

    return {
        type: ActionTypes.UPDATE_APP_SETTINGS_REQUEST,
        payload: {
            command: command,
            value: {value: false},
            errors: null
        }
    } as UpdateAppSettingsAction
  };
  
  export const updateAppSettingsSuccess = (payload: UpdateAppSettingsSuccessPayload): UpdateAppSettingsAction => {

    return {
        type: ActionTypes.UPDATE_APP_SETTINGS_SUCCESS,
        payload: {
            command: null,
            value: payload,
            errors: null
        }
    } as UpdateAppSettingsAction;
  };
  
  export const updateAppSettingsFailure = (payload: UpdateAppSettingsFailurePayload): UpdateAppSettingsAction => {

    return {
        type: ActionTypes.UPDATE_APP_SETTINGS_FAILURE,
        payload: {
            command: null,
            value: {value: false},
            errors: payload
        }
    } as UpdateAppSettingsAction;
  };

  export const getAppSettings = (command: ""): GetAppSettingsAction => {
  
      return {
          type: ActionTypes.GET_APP_SETTINGS_REQUEST,
          payload: {
              command: command,
              user: null,
              errors: null
          }
      } as GetAppSettingsAction
    };
    
    export const getAppSettingsFailure = (payload: GetAppSettingsFailurePayload): GetAppSettingsAction => {
  
      return {
          type: ActionTypes.GET_APP_SETTINGS_FAILURE,
          payload: {
              command: null,
              user: null,
              errors: payload,
          }
      } as GetAppSettingsAction;
    };
    
    export const getAppSettingsSuccess = (payload: GetAppSettings): GetAppSettingsAction => {
  
      return {
          type: ActionTypes.GET_APP_SETTINGS_SUCCESS,
          payload: {
              command: null,
              user: payload,
              errors: null
          }
      } as GetAppSettingsAction;
    };