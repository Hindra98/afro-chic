import { ActionTypes } from '../actions/constants/action-types';
import { produce } from "immer";
import { getTenantInitialState, GetTenantsAction, getTenantsInitialState, GetTenantsStoreShape, TenantAction, GetTenantStoreShape, AddTenantStoreShape, AddTenantAction, initialStateAddTenant, DeleteTenantStoreShape, initialStateDeleteTenant, DeleteTenantAction, UpdateTenantStoreShape, initialStateUpdateTenant, UpdateTenantAction, ExportPdfTenantsStoreShape, exportPdfTenantsInitialState, ExportPdfTenantsAction } from "../actions/tenants";


export const addTenantReducer = (state: AddTenantStoreShape = initialStateAddTenant, args: AddTenantAction): AddTenantStoreShape => {

  switch (args.type) {

    case ActionTypes.ADD_TENANT_REQUEST:
      return produce(state, (draftState) => {
        draftState.value = false;
        draftState.pending = true;
        draftState.Errors = [];
      });

      case ActionTypes.ADD_TENANT_FAILURE:
        return produce(state, (draftState) => {
          draftState.Errors = args.payload?.errors.errors;
          draftState.value = false;
          draftState.pending = false;
        });

        case ActionTypes.ADD_TENANT_SUCCESS:
          return produce(state, (draftState) => {
            draftState.Errors = [];
            draftState.value = true;
            draftState.pending = false;
          });

    default:
      return state;
  }
};


export const updateTenantReducer = (state: UpdateTenantStoreShape = initialStateUpdateTenant, args: UpdateTenantAction): UpdateTenantStoreShape => {

  switch (args.type) {

    case ActionTypes.UPDATE_TENANT_REQUEST:
      return produce(state, (draftState) => {
        draftState.value = false;
        draftState.pending = true;
        draftState.Errors = [];
      });

      case ActionTypes.UPDATE_TENANT_FAILURE:
        return produce(state, (draftState) => {
          draftState.Errors = args.payload?.errors.errors;
          draftState.value = false;
          draftState.pending = false;
        });

        case ActionTypes.UPDATE_TENANT_SUCCESS:
          return produce(state, (draftState) => {
            draftState.Errors = [];
            draftState.value = true;
            draftState.pending = false;
          });

    default:
      return state;
  }
};

export const deleteTenantReducer = (state: DeleteTenantStoreShape = initialStateDeleteTenant, args: DeleteTenantAction): DeleteTenantStoreShape => {

  switch (args.type) {

    case ActionTypes.DELETE_TENANTS_REQUEST:
      return produce(state, (draftState) => {
        draftState.value = false;
        draftState.pending = true;
        draftState.Errors = [];
      });

      case ActionTypes.DELETE_TENANTS_FAILURE:
        return produce(state, (draftState) => {
          draftState.Errors = args.payload?.errors.errors;
          draftState.value = false;
          draftState.pending = false;
        });

        case ActionTypes.DELETE_TENANTS_SUCCESS:
          return produce(state, (draftState) => {
            draftState.Errors = [];
            draftState.value = true;
            draftState.pending = false;
          });

    default:
      return state;
  }
};

export const getTenantsReducer = (state: GetTenantsStoreShape = getTenantsInitialState, args: GetTenantsAction): GetTenantsStoreShape => {

  switch (args.type) {

    case ActionTypes.GET_TENANTS_REQUEST:
      return produce(state, (draftState) => {
        draftState.pending = true;
        draftState.Errors = [];
      });

    case ActionTypes.GET_TENANTS_FAILURE:
      return produce(state, (draftState) => {
        draftState.Errors = args.payload?.errors?.errors;
        draftState.pending = false;
      });

    case ActionTypes.GET_TENANTS_SUCCESS:
      return produce(state, (draftState) => {
        draftState.Errors = [];
        draftState.value.tenants = args?.payload?.user?.tenants
        draftState.value.isSuperAdministrator = args?.payload?.user?.isSuperAdministrator

        draftState.pending = false;
      });

    default:
      return state;
  }
};

export const getTenantReducer = (state: GetTenantStoreShape = getTenantInitialState, args: TenantAction): GetTenantStoreShape => {

  switch (args.type) {

    case ActionTypes.GET_TENANT_REQUEST:
      return produce(state, (draftState) => {
        draftState.pending = true;
        draftState.Errors = [];
      });

    case ActionTypes.GET_TENANT_FAILURE:
      return produce(state, (draftState) => {
        draftState.Errors = args.payload?.errors?.errors;
        draftState.pending = false;
      });

    case ActionTypes.GET_TENANT_SUCCESS:
      return produce(state, (draftState) => {
        draftState.Errors = [];
        draftState.value.vendor.key = args?.payload?.user?.vendor.key
        draftState.value.vendor.databaseName = args?.payload?.user?.vendor.databaseName
        draftState.value.vendor.description = args?.payload?.user?.vendor.description
        draftState.value.vendor.detail = args?.payload?.user?.vendor.detail
        draftState.value.vendor.logoUrl = args?.payload?.user?.vendor.logoUrl
        draftState.value.vendor.language = args?.payload?.user?.vendor.language
        draftState.value.vendor.regionalFormatId = args?.payload?.user?.vendor.regionalFormatId
        draftState.value.vendor.timeZoneId = args?.payload?.user?.vendor.timeZoneId
        draftState.value.vendor.isEnable = args?.payload?.user?.vendor.isEnable
        draftState.value.vendor.isDeletable = args?.payload?.user?.vendor.isDeletable
        draftState.value.vendor.statusWording = args?.payload?.user?.vendor.statusWording
        draftState.value.vendor.name = args?.payload?.user?.vendor.name
        draftState.value.vendor.subscriptionID = args?.payload?.user?.vendor.subscriptionID
        draftState.value.vendor.status = args?.payload?.user?.vendor?.status

        draftState.value.vendor.defaultAdministrator.id = args?.payload?.user?.vendor.defaultAdministrator.id
        draftState.value.vendor.defaultAdministrator.userName = args?.payload?.user?.vendor?.defaultAdministrator?.userName
        draftState.value.vendor.defaultAdministrator.password = args?.payload?.user?.vendor?.defaultAdministrator?.password
        draftState.value.vendor.defaultAdministrator.firstName = args?.payload?.user?.vendor?.defaultAdministrator?.firstName
        draftState.value.vendor.defaultAdministrator.lastName = args?.payload?.user?.vendor?.defaultAdministrator?.lastName
        draftState.value.vendor.defaultAdministrator.middleName = args?.payload?.user?.vendor?.defaultAdministrator?.middleName
        draftState.value.vendor.defaultAdministrator.emailAddress = args?.payload?.user?.vendor?.defaultAdministrator?.emailAddress
        draftState.value.vendor.defaultAdministrator.phoneNumber = args?.payload?.user?.vendor?.defaultAdministrator?.phoneNumber
        draftState.value.vendor.defaultAdministrator.idCardNumber = args?.payload?.user?.vendor?.defaultAdministrator?.idCardNumber
        draftState.value.vendor.defaultAdministrator.isUserConsentEmailNotification = args?.payload?.user?.vendor?.defaultAdministrator?.isUserConsentEmailNotification
        draftState.value.vendor.defaultAdministrator.isUserConsentSmsNotification = args?.payload?.user?.vendor?.defaultAdministrator?.isUserConsentSmsNotification
        draftState.value.vendor.defaultAdministrator.preferedCommunicationChannel = args?.payload?.user?.vendor?.defaultAdministrator?.preferedCommunicationChannel
        draftState.value.vendor.defaultAdministrator.identityDocumentType = args?.payload?.user?.vendor?.defaultAdministrator?.identityDocumentType
        
        draftState.value.languages = args?.payload?.user?.languages
        draftState.value.regionalFormats = args?.payload?.user?.regionalFormats
        draftState.value.timeZones = args?.payload?.user?.timeZones
        draftState.value.idDocumentTypes = args?.payload?.user?.idDocumentTypes

        draftState.pending = false;
      });

    default:
      return state;
  }
};

export const exportPdfTenantReducer = (state: ExportPdfTenantsStoreShape = exportPdfTenantsInitialState, args: ExportPdfTenantsAction): ExportPdfTenantsStoreShape => {

  switch (args.type) {

    case ActionTypes.EXPORT_PDF_TENANTS_REQUEST:
      return produce(state, (draftState) => {
        draftState.value = false;
        draftState.pending = true;
        draftState.Errors = [];
      });

      case ActionTypes.EXPORT_PDF_TENANTS_FAILURE:
        return produce(state, (draftState) => {
          draftState.Errors = args.payload?.errors.errors;
          draftState.value = false;
          draftState.pending = false;
        });

        case ActionTypes.EXPORT_PDF_TENANTS_SUCCESS:
          return produce(state, (draftState) => {
            draftState.Errors = [];
            draftState.value = true;
            draftState.pending = false;
          });

    default:
      return state;
  }
};