import { SwitchComponent } from "@syncfusion/ej2-react-buttons";
import { DropDownListComponent } from "@syncfusion/ej2-react-dropdowns";
import {
  SidebarComponent,
  TabAnimationSettingsModel,
  TabComponent,
  TabItemDirective,
  TabItemsDirective,
} from "@syncfusion/ej2-react-navigations";
import { MessageComponent } from "@syncfusion/ej2-react-notifications";
import { MutableRefObject, useRef, useState } from "react";
import Button from "src/app/components/form/Button";
import InputWithIcon from "src/app/components/form/Input";
import OperationResultComponent from "src/app/components/shared/operation-result-component";
import { ShimmerText } from "src/app/components/shared/shimmer";
import { useAppDispatch, useAppSelector } from "src/app/core/hooks/core-hooks";
import {
  validateFormData,
  ValidationType,
  Validator,
} from "src/app/core/text/regex";
import { addAgency } from "src/app/store-management/actions/agencies/agencies-actions";

type DataAgency = {
  handleSave?;
  title?: string;
  isEditing?: boolean;
  func: FuncAgency;
};

type FuncAgency = {
  sidebarInstance: MutableRefObject<SidebarComponent>;
  sidebarClose: () => void;
  isShowBackdrop: boolean;
};
type ItemFields = {
  text: string;
  value: string;
  iconCss: string;
};

export interface FieldAgency {
  value?: string | boolean | number;
  error?: string;
}
export interface FormAgency {
  name?: FieldAgency;
  description?: FieldAgency;
  isHeadQuarter?: FieldAgency;
  language?: FieldAgency;
  regionalFormat?: FieldAgency;
  timeZone?: FieldAgency;
  currencyPosition?: FieldAgency;

  latitude?: FieldAgency;
  longitude?: FieldAgency;
  radius?: FieldAgency;
  order?: FieldAgency;
}

export interface FormAgencyValidation {
  name?: Validator;
  description?: Validator;
  currencyPosition?: Validator;
  language?: Validator;
  regionalFormat?: Validator;
  timeZone?: Validator;
  isHeadQuarter?: Validator;

  latitude?: Validator;
  longitude?: Validator;
  radius?: Validator;
  order?: Validator;
}

export default function CreateUpdateAgenciesSidebar(data: DataAgency) {
  const getAgencyData = useAppSelector((state) => state.getAgency);
  const addAgencyData = useAppSelector((state) => state.addAgency);
  const dispatch = useAppDispatch();
  let tabInstance = useRef<TabComponent>(null);
  const [showServerErrorMessage, setShowServerErrorMessage] = useState(false);

  let closefailedMsg = document?.getElementById("msg_error")?.getElementsByClassName("e-msg-close-icon");
  for (var i = 0; i < closefailedMsg?.length; i++) {
    closefailedMsg[i]?.addEventListener("click", () => {
      setShowServerErrorMessage(false);
      document.getElementById("msg_error")?.setAttribute("class", "h-0 hidden");
      document
        .getElementById("msg_server")
        ?.setAttribute("class", "h-0 hidden");
    });
  }

  let closefailedMsgGet = document
    ?.getElementById("msg_error_get")
    ?.getElementsByClassName("e-msg-close-icon");
  for (var j = 0; j < closefailedMsgGet?.length; j++) {
    closefailedMsgGet[j]?.addEventListener("click", () => {
      setShowServerErrorMessage(false);
      document.getElementById("msg_error_get")?.setAttribute("class", "h-0 hidden");
      document
        .getElementById("msg_server_get")
        ?.setAttribute("class", "h-0 hidden");
    });
  }

  const [agencyModel, setAgencyModel] = useState<FormAgency>({});

  const agencyModelValidation: FormAgencyValidation = {
    name: {
      validatorType: ValidationType.REQUIRED,
      message: "Nom vide",
    },
    description: {
      validatorType: ValidationType.REQUIRED,
      message: "description vide",
    },
    currencyPosition: {
      validatorType: ValidationType.REQUIRED,
      message: "Position monétaire vide",
    },
    language: {
      validatorType: ValidationType.REQUIRED,
      message: "Langue vide",
    },
    regionalFormat: {
      validatorType: ValidationType.REQUIRED,
      message: "Formatage regional vide",
    },
    timeZone: {
      validatorType: ValidationType.REQUIRED,
      message: "Fuseau horaire vide",
    },
    latitude: {
      validatorType: ValidationType.REQUIRED,
      message: "latitude vide",
    },
    longitude: {
      validatorType: ValidationType.REQUIRED,
      message: "longitude vide",
    },
    radius: {
      validatorType: ValidationType.REQUIRED,
      message: "Rayon vide",
    },
    order: {
      validatorType: ValidationType.REQUIRED,
      message: "Numéro d'ordre vide",
    }
  };

  const [actu, setActu] = useState(false);
  const [showServerSuccessMessage, setShowServerSuccessMessage] = useState(false);

  const initialData = () => {
    setAgencyModel({});
    setShowServerSuccessMessage(false);
    setActu(false);
    tabInstance?.current?.select(0);
    tabInstance?.current?.select(1);
    tabInstance?.current?.select(0);
  };

  if (data?.isEditing && !actu && !getAgencyData?.pending) {
    setAgencyModel({
      name: {
        value: getAgencyData?.value?.branch?.name?.toString(),
        error: "",
      },
      isHeadQuarter: {
        value: getAgencyData?.value?.branch?.isHeadQuarter?.valueOf(),
        error: "",
      },
      currencyPosition: {
        value:
          getAgencyData?.value?.branch?.settings?.currencyPosition?.toString(),
        error: "",
      },
      language: {
        value: getAgencyData?.value?.branch?.settings?.language?.toString(),
        error: "",
      },
      regionalFormat: {
        value:
          getAgencyData?.value?.branch?.settings?.regionalFormat?.toString(),
        error: "",
      },
      timeZone: {
        value: getAgencyData?.value?.branch?.settings?.timeZone?.toString(),
        error: "",
      },
      description: {
        value: getAgencyData?.value?.branch?.description?.toString(),
        error: "",
      },

      latitude: {
        value: getAgencyData?.value?.branch?.latitude?.toString(),
        error: "",
      },
      longitude: {
        value: getAgencyData?.value?.branch?.longitude?.toString(),
        error: "",
      },
      radius: {
        value: getAgencyData?.value?.branch?.radius?.toString(),
        error: "",
      },
      order: {
        value: getAgencyData?.value?.branch?.order?.toString(),
        error: "",
      },
    });
    setActu(true);
  }

  const handleSubmit = (e) => {
    e.preventDefault();
    const agencyForm = document.querySelector("form");
    const formData = new FormData(agencyForm);

    const nameErr: Validator = validateFormData(
      formData.get("name"),
      agencyModelValidation.name
    ).errors;
    const currencyPositionErr: Validator = validateFormData(
      formData.get("currencyPosition"),
      agencyModelValidation.currencyPosition
    ).errors;
    const languageErr: Validator = validateFormData(
      formData.get("language"),
      agencyModelValidation.language
    ).errors;
    const regionalFormatErr: Validator = validateFormData(
      formData.get("regionalFormat"),
      agencyModelValidation.regionalFormat
    ).errors;
    const timeZoneErr: Validator = validateFormData(
      formData.get("timeZone"),
      agencyModelValidation.timeZone
    ).errors;
    const latitudeErr: Validator = validateFormData(
      formData.get("latitude"),
      agencyModelValidation.latitude
    ).errors;
    const longitudeErr: Validator = validateFormData(
      formData.get("longitude"),
      agencyModelValidation.longitude
    ).errors;
    const radiusErr: Validator = validateFormData(
      formData.get("radius"),
      agencyModelValidation.radius
    ).errors;
    const orderErr: Validator = validateFormData(
      formData.get("order"),
      agencyModelValidation.order
    ).errors;

    setAgencyModel({
      name: {
        value: formData.get("name")?.toString(),
        error: nameErr?.message ?? "",
      },
      isHeadQuarter: {
        value: formData.get("isHeadQuarter")?.toString(),
        error: "",
      },
      currencyPosition: {
        value: formData.get("currencyPosition")?.toString(),
        error: currencyPositionErr?.message ?? "",
      },
      language: {
        value: formData.get("language")?.toString(),
        error: languageErr?.message ?? "",
      },
      regionalFormat: {
        value: formData.get("regionalFormat")?.toString(),
        error: regionalFormatErr?.message ?? "",
      },
      timeZone: {
        value: formData.get("timeZone")?.toString(),
        error: timeZoneErr?.message ?? "",
      },
      description: {
        value: formData.get("description")?.toString(),
        error: timeZoneErr?.message ?? "",
      },
      latitude: {
        value: formData.get("latitude")?.toString(),
        error: latitudeErr?.message ?? "",
      },
      longitude: {
        value: formData.get("longitude")?.toString(),
        error: longitudeErr?.message ?? "",
      },
      radius: {
        value: formData.get("radius")?.toString(),
        error: radiusErr?.message ?? "",
      },
      order: {
        value: formData.get("order")?.toString(),
        error: orderErr?.message ?? "",
      },
    });

    if (
      !(
        nameErr?.message ||
        currencyPositionErr?.message ||
        languageErr?.message ||
        regionalFormatErr?.message ||
        timeZoneErr?.message ||
        latitudeErr?.message ||
        longitudeErr?.message ||
        radiusErr?.message ||
        orderErr?.message
      )
    ) {
      dispatch(
        addAgency({
          key: getAgencyData?.value?.branch?.id?.toString(),
          name: formData.get("name")?.toString(),
          description: formData.get("description")?.toString(),
          latitude: parseInt(formData.get("latitude")?.toString()),
          longitude: parseInt(formData.get("longitude")?.toString()),
          radius: parseInt(formData.get("radius")?.toString()),
          order: parseInt(formData.get("order")?.toString()),
          isHeadQuarter: formData.get("isHeadQuarter")?.toString() === 'true',
          currencyPosition: formData.get("currencyPosition")?.toString(),
          language: formData.get("language")?.toString(),
          regionalFormat: formData.get("regionalFormat")?.toString(),
          timeZone: formData.get("timeZone")?.toString(),
        } as BranchCommand)
      );
      setShowServerErrorMessage(true);
      setShowServerSuccessMessage(true)
    } else {
      if (
        !(
          nameErr?.message ||
          currencyPositionErr?.message ||
          languageErr?.message ||
          regionalFormatErr?.message ||
          timeZoneErr?.message
        )
      ) {
        tabInstance?.current?.select(1);
      }
      if (
        !(
          latitudeErr?.message ||
          longitudeErr?.message ||
          radiusErr?.message ||
          orderErr?.message
        )
      ) {
        tabInstance?.current?.select(0);
      }
    }
  };

  const animateSidebar: TabAnimationSettingsModel = {
    previous: { effect: "None", duration: 600, easing: "ease" },
    next: { effect: "None", duration: 600, easing: "ease" },
  };

  const allLanguage = (): { [key: string]: Object }[] => {
    let newLang: { [key: string]: Object }[] = [];
    getAgencyData.value.languages.map((item) =>
      newLang.push({
        value: item.twoLetterISOLanguageName,
        langue: item.displayName,
        iconLang: "",
      })
    );
    return newLang;
  };

  const allTimeZone = (): { [key: string]: Object }[] => {
    let newTime: { [key: string]: Object }[] = [];
    getAgencyData.value.timeZones.map((item) =>
      newTime.push({
        value: item.id,
        timeZone: item.displayName,
        iconTime: "",
      })
    );
    return newTime;
  };

  const allRegionalFormat = (): { [key: string]: Object }[] => {
    let newTime: { [key: string]: Object }[] = [];
    getAgencyData.value.regionalFormats.map((item) =>
      newTime.push({
        value: item.id,
        regionalFormat: item.displayName,
        iconRegionalFormat: "",
      })
    );
    return newTime;
  };

  const language: { [key: string]: Object }[] = allLanguage();
  const languageFields: ItemFields = {
    text: "langue",
    value: "value",
    iconCss: "iconLang",
  };

  const timeZone: { [key: string]: Object }[] = allTimeZone();
  const timeZoneFields: ItemFields = {
    text: "timeZone",
    value: "value",
    iconCss: "iconTime",
  };

  const regionalFormat: { [key: string]: Object }[] = allRegionalFormat();
  const regionalFormatFields: ItemFields = {
    text: "regionalFormat",
    value: "value",
    iconCss: "iconRegionalFormat",
  };

  const currencyPosition: { [key: string]: Object }[] = [
    { value: "RIGHT", position: "DROITE", iconchan: "" },
    { value: "LEFT", position: "GAUCHE", iconchan: "" },
  ];
  const currencyPositionFields: ItemFields = {
    text: "position",
    value: "value",
    iconCss: "iconchan",
  };

  let headertext: any = [
    { text: "Général", iconCss: "icon" },
    { text: "Coordonnées géographiques", iconCss: "icon" },
  ];

  const GeneralTab = () => {
    return getAgencyData.pending ? (
      <div className="flex flex-col w-full h-full gap-0 mx-auto">
        <div className="latitude w-full mx-auto">
          <ShimmerText />
        </div>
        <div className="latitude w-full mx-auto">
          <ShimmerText />
        </div>
        <div className="latitude w-full mx-auto">
          <ShimmerText />
        </div>
      </div>
    ) : (
      <div className="flex flex-col justify-between items-center gap-4 w-full my-4 px-4 form">
        <div className="flex flex-row gap-3 items-start justify-between names w-full">
          <div className="flex flex-col gap-3 nom w-full">
            <label htmlFor="name">Nom de l'agence</label>
            <InputWithIcon
              type={"text"}
              name={"name"}
              id={"name"}
              placeholder={"Nom de l'agence"}
              defaultValue={agencyModel?.name?.value?.toString()}
              className="w-full"
            />
            {agencyModel.name?.error && (
              <div className="error">{agencyModel.name?.error}</div>
            )}
          </div>

          <div className="flex flex-col gap-3 currencyPosition w-full">
            <label htmlFor="currencyPosition">
              Position du symbole monétaire
            </label>
            <DropDownListComponent
              cssClass="w-full border px-2 py-1 input-notify bg-white disabled"
              id="currencyPosition"
              dataSource={currencyPosition}
              fields={currencyPositionFields}
              value={agencyModel?.currencyPosition?.value?.toString() ?? "0"}
              name="currencyPosition"
              placeholder={"Choisissez votre position monetaire"}
              popupHeight="220px"
            />
          </div>
        </div>

        <div className="flex flex-row justify-between items-center gap-3 isHeadQuarter w-full mt-3">
          <label htmlFor="isHeadQuarte">
            Définir comme siège social de l'entreprise
          </label>
          <SwitchComponent
            id="isHeadQuarter"
            checked={agencyModel?.isHeadQuarter?.value as boolean || false}
            value="true"
            name="isHeadQuarter"
            cssClass=""
          ></SwitchComponent>
        </div>

        <div className="language flex flex-col gap-3 w-full">
          <label htmlFor="language">Langue</label>
          <DropDownListComponent
            cssClass="w-full border px-2 py-1 input-notify bg-white"
            id="language"
            name="language"
            dataSource={language}
            fields={languageFields}
            value={agencyModel?.language?.value?.toString()}
            placeholder={"Choisissez votre langue"}
            popupHeight="220px"
          />
          {agencyModel.language?.error && (
            <div className="error">{agencyModel.language?.error}</div>
          )}
        </div>
        <div className="flex flex-row gap-3 items-start justify-between contact w-full">
          <div className="regionalFormat flex flex-col gap-3 w-full">
            <label htmlFor="regionalFormat">Formatage régional</label>
            <DropDownListComponent
              cssClass="w-full border px-2 py-1 input-notify bg-white"
              id="regionalFormat"
              name="regionalFormat"
              dataSource={regionalFormat}
              fields={regionalFormatFields}
              value={agencyModel?.regionalFormat?.value?.toString()}
              placeholder={"Choisissez votre formatage régional"}
              popupHeight="220px"
            />
            {agencyModel.regionalFormat?.error && (
              <div className="error">{agencyModel.regionalFormat?.error}</div>
            )}
          </div>
          <div className="timeZone flex flex-col gap-3 w-full">
            <label htmlFor="timeZone">Fuseau horaire</label>
            <DropDownListComponent
              cssClass="w-full border px-2 py-1 input-notify bg-white"
              id="timeZone"
              name="timeZone"
              dataSource={timeZone}
              fields={timeZoneFields}
              value={agencyModel?.timeZone?.value?.toString()}
              placeholder={"Choisissez votre fuseau horaire"}
              popupHeight="220px"
            />
            {agencyModel.timeZone?.error && (
              <div className="error">{agencyModel.timeZone?.error}</div>
            )}
          </div>
        </div>
        <div className="description flex flex-col gap-3 w-full">
          <label htmlFor="description">Description</label>
          <textarea
            name="description"
            id="description"
            defaultValue={agencyModel?.description?.value?.toString()}
            cols={30}
            rows={9}
            className="w-full border px-2 py-1 input-sidebar bg-white"
          ></textarea>
        </div>
      </div>
    );
  };

  const geographicDataTab = () =>
    getAgencyData.pending ? (
      <div className="flex flex-col w-full h-full gap-0 mx-auto">
        <div className="latitude w-full mx-auto">
          <ShimmerText />
        </div>
        <div className="latitude w-full mx-auto">
          <ShimmerText />
        </div>
        <div className="latitude w-full mx-auto">
          <ShimmerText />
        </div>
      </div>
    ) : (
      <div className="flex flex-col justify-between items-center gap-4 w-full my-4 px-4 form">
        <div className="flex flex-col gap-3 latitude w-full">
          <label htmlFor="latitude">Latitude</label>
          <InputWithIcon
            type={"text"}
            name={"latitude"}
            id={"latitude"}
            placeholder={"Latitude"}
            defaultValue={agencyModel?.latitude?.value?.toString()}
            className="w-full"
          />
          {agencyModel.latitude?.error && (
            <div className="error">{agencyModel.latitude?.error}</div>
          )}
        </div>

        <div className="flex flex-col gap-3 longitude w-full">
          <label htmlFor="longitude">Longitude</label>
          <InputWithIcon
            type={"text"}
            name={"longitude"}
            id={"longitude"}
            placeholder={"Longitude"}
            defaultValue={agencyModel?.longitude?.value?.toString()}
            className="w-full"
          />
          {agencyModel.longitude?.error && (
            <div className="error">{agencyModel.longitude?.error}</div>
          )}
        </div>

        <div className="flex flex-row gap-3 items-start justify-between name w-full">
          <div className="flex flex-col gap-3 radius w-full">
            <label htmlFor="radius">Rayon</label>
            <InputWithIcon
              type={"text"}
              name={"radius"}
              id={"radius"}
              placeholder={"Rayon"}
              defaultValue={agencyModel?.radius?.value?.toString()}
              className="w-full"
            />
            {agencyModel.radius?.error && (
              <div className="error">{agencyModel.radius?.error}</div>
            )}
          </div>

          <div className="flex flex-col gap-3 order w-full">
            <label htmlFor="order">Numéro d'ordre du point</label>
            <InputWithIcon
              type={"text"}
              name={"order"}
              id={"order"}
              placeholder={"Numéro d'ordre du point"}
              defaultValue={agencyModel?.order?.value?.toString()}
              className="w-full"
            />
            {agencyModel.order?.error && (
              <div className="error">{agencyModel.order?.error}</div>
            )}
          </div>
        </div>
      </div>
    );

  return (
    <SidebarComponent
      ref={data?.func?.sidebarInstance}
      closeOnDocumentClick={false}
      showBackdrop={data?.func?.isShowBackdrop}
      width="700px"
      target=".apimaincontent"
      id="apiSidebar"
      className="tenant-sidebar"
      type={"Over"}
      enableGestures={false}
      position={"Right"}
      open={() => initialData()}
    >
      <div className="flex flex-col justify-start items-center h-full py-7 relative">
        <div className="flex flex-row justify-between w-full px-9 mt- mb-2">
          <h2 className="text-3xl title">
            {data?.isEditing
              ? "Modification de l'agence"
              : "Ajouter une agence"}
          </h2>
          <span
            className="icon cursor-pointer cancelicon- text-2xl"
            onClick={data?.func?.sidebarClose?.bind(this)}
          ></span>
        </div>
        {addAgencyData.value && showServerSuccessMessage && !addAgencyData.pending ? (
          <div className="absolut mt-[25vh] h-[30vh] w-3/4 mx-auto">
            <OperationResultComponent
              message={data?.isEditing? "Agence modifiée avec success":"Agence ajoutée avec success"}
              title={data?.isEditing ? "Modification de l'agence" : "Ajout de l'agence"}
              titleButton={"Fermez cette page et consultez la liste"}
            />
          </div>
        ) : (
          <form
            className="flex flex-col justify-start items-center content py-4 px-8 w-full h-full"
            onSubmit={handleSubmit}
          >
            {addAgencyData.Errors &&
              showServerErrorMessage &&
              addAgencyData.Errors.length > 0 &&
              !addAgencyData.pending &&
              addAgencyData.Errors.map((message, key) => {
                return (
                  <div className="w-full mx-auto" id="msg_server" key={key}>
                    <MessageComponent
                      showCloseIcon
                      id="msg_error"
                      className="errorServer m-1"
                      content={message}
                      key={key}
                      severity="Error"
                    ></MessageComponent>
                  </div>
                );
              })}
            {getAgencyData.Errors &&
              showServerErrorMessage &&
              getAgencyData.Errors.length > 0 &&
              !getAgencyData.pending &&
              getAgencyData.Errors.map((message, key) => {
                return (
                  <div className="w-full mx-auto" id="msg_server_get" key={key}>
                    <MessageComponent
                      showCloseIcon
                      id="msg_error_get"
                      className="errorServer m-1"
                      content={message}
                      key={key}
                      severity="Error"
                    ></MessageComponent>
                  </div>
                );
              })}
            <TabComponent
              id="tenantSidebarTab"
              cssClass="border-0 border-transparent h-full mb-auto"
              animation={animateSidebar}
              ref={tabInstance}
            >
              <TabItemsDirective>
                <TabItemDirective
                  header={headertext[0]}
                  content={() => GeneralTab()}
                />
                <TabItemDirective
                  header={headertext[1]}
                  content={() => geographicDataTab()}
                />
              </TabItemsDirective>
            </TabComponent>

            <div className="flex flex-row gap-4 justify-end footer px-4 py-4 ms-auto">
              <Button
                param={{
                  type: "button",
                  name: "Annuler",
                  handleClick: data?.func?.sidebarClose?.bind(this),
                  css: (addAgencyData?.pending ? "disabled": "") + " cancelBtn w-full",
                  disabled: addAgencyData?.pending,
                }}
              />
              <Button
                param={{
                  type: "button",
                  name: "Valider",
                  handleClick: handleSubmit,
                  css: (addAgencyData?.pending ? "disabled": "") + " okBtn w-full",
                  disabled: addAgencyData?.pending,
                }}
              />
            </div>
          </form>
        )}
      </div>
    </SidebarComponent>
  );
}
