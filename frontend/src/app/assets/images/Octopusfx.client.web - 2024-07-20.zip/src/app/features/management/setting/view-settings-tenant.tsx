import { MessageComponent } from "@syncfusion/ej2-react-notifications";
import { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { ShimmerText } from "src/app/components/shared/shimmer";
import { useAppDispatch, useAppSelector } from "src/app/core/hooks/core-hooks";
import { getUserPreferences } from 'src/app/store-management/actions/user-preferences/user-preferences-actions';
import UpdateSettings from "./update-settings-tenant";
import "../../../styles/_settings.scss";

const ViewSettingsTenant = () => {

  const navigate = useNavigate();
  const { display } = useParams();
  const dispatch = useAppDispatch();
  const getUserPreference = useAppSelector((state) => state.getUserPreferences);
  const [getUne, setGetUne] = useState(false);

  const getDataUser = async () => {
    dispatch(await getUserPreferences(""));
  };

  const returnPreviousPage = () => {
    navigate(-1);
  };

  const editPreferences = () => {
    navigate("./../edit");
  };
  if (!getUne && !getUserPreference.pending && getUserPreference.Errors.length === 0) {
    getDataUser();
    setGetUne(true);
  }

  window.document.title = "Preferences de l'abonnement";

  if (display === "edit")
    return (
      <><UpdateSettings /></>
    );

  return (
    <div className="h-full flex flex-col justify-between settings">
      <div className="form-fields w-full h-full px-3 py-5 bg-white xl:px-5 2xl:px-12 md:px-8">
        
        <div className="w-full">
          {getUserPreference.Errors &&
            getUserPreference.Errors.length > 0 &&
            getUserPreference.Errors.map((message, key) => {
              return (
                <MessageComponent
                  showCloseIcon
                  id="msg_error"
                  className="errorServer m-1"
                  content={message}
                  key={key}
                  severity="Error"
                ></MessageComponent>
              );
            })
          }
        </div>

        <h1 className="text-3xl align-top text-center mb-4">
          Preferences de l'abonnement
        </h1>
        <div className="user-mid-help w-full text-left flex flex-col gap-5">
          {false ? (
            <div className="grid grid-cols-1 gap-5 mx-auto mt-12 w-full">
              <div className="username">
                <ShimmerText />
              </div>
            </div>
          ) : (
            <div className="flex flex-col gap-5 md:grid-cols-2 xxs:grid-cols-1">
              <div className="flex flex-row justify-between w-full gap-2 mx-auto">
                <div className="flex flex-col gap-2">
                  <div className="nameTenant">
                    <span>
                    Nom du tenant
                    </span>
                    : DefaultVendor
                  </div>
                  <div className="twofactauth">
                    <span>
                    Deuxieme facteur d'authentification
                    </span>
                    : Activée
                  </div>
                </div>

                <div className="flex flex-col gap-2">
                  
                    <div className="langue">
                      <span>
                        Langue
                      </span>
                      : fr
                    </div>
                  <div className="pinLength">
                    <span>
                    Longueur du code pin
                    </span>
                    : 6
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
        
          <div className="accept-change-password flex justify-end gap-3 mt-20 mb-5">
            <button
              className="p-2 rounded-md"
              type="button"
              onClick={returnPreviousPage}
            >
              Annuler
            </button>
            <button
              className="p-2 rounded-md"
              type="button"
              onClick={editPreferences}
            >
              Editer
            </button>
          </div>
        
      </div>
    </div>
  );
};

export default ViewSettingsTenant;
