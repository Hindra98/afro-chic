import { SwitchComponent } from "@syncfusion/ej2-react-buttons";

type Props = {
  title?: string;
  description?: string;
  checked?: boolean;
  disabled?: boolean;
  name?: string;
  change?
};

const SwitchSettingsLine = (props: Props) => {

  return (
    <div className={`${props?.name} flex flex-row justify-between gap-5 w-full switch-settings`}>
      <div className="w-1/3">
        <SwitchComponent
          id={props?.name}
          checked={props?.checked}
          value="false"
          name={props?.name}
          cssClass={props?.disabled ? "label-disabled" : ""}
          readOnly={props?.disabled}
          disabled={props?.disabled}
          change={props?.change}
        ></SwitchComponent></div>
      <label htmlFor={props?.name} className={`flex flex-col gap-1 w-3/4 ${props?.disabled ? " label-disabled" : ""} `}>
        <h2 className="font-bold">{props?.title}</h2>
        {props.description && <p className="font-normal text-sm user-help" title={props?.description}>{props?.description}</p>}

      </label>
    </div>
  );
};

export default SwitchSettingsLine
