import { SwitchComponent } from "@syncfusion/ej2-react-buttons";
import { DropDownListComponent } from "@syncfusion/ej2-react-dropdowns";
import {
  SidebarComponent,
  TabAnimationSettingsModel,
  TabComponent,
  TabItemDirective,
  TabItemsDirective,
} from "@syncfusion/ej2-react-navigations";
import { MessageComponent } from "@syncfusion/ej2-react-notifications";
import { MutableRefObject, useRef, useState } from "react";
import Button from "src/app/components/form/Button";
import FileInput from "src/app/components/form/file-input";
import InputWithIcon from "src/app/components/form/Input";
import TextArea from "src/app/components/form/TextArea";
import OperationResultComponent from "src/app/components/shared/operation-result-component";
import { ShimmerText } from "src/app/components/shared/shimmer";
import { useAppDispatch, useAppSelector } from "src/app/core/hooks/core-hooks";
import { validateFormData, ValidationType, Validator } from "src/app/core/text/regex";
import { addTenant } from "src/app/store-management/actions/tenants/tenants-actions";

type DataTenant = {
  handleSave?;
  isEditing?: boolean;
  func: TenantFunctions;
};

type TenantFunctions = {
  sidebarInstance: MutableRefObject<SidebarComponent>;
  sidebarClose: () => void;
  isShowBackdrop: boolean;
};
type ItemFields = {
  text: string;
  value: string;
  iconCss: string;
};

export interface TenantField {
  value?: string | boolean | number;
  error?: string;
}
export interface TenantForm {
  name?: TenantField;
  subscriptionId?: TenantField;
  databaseName?: TenantField;
  language?: TenantField;
  regionalFormat?: TenantField;
  timeZone?: TenantField;
  description?: TenantField;
  logo?: TenantField;
  detail?: TenantField;
  isEnable?: TenantField;

  username?: TenantField;
  emailAddress?: TenantField;
  phoneNumber?: TenantField;
  password?: TenantField;
  firstName?: TenantField;
  lastName?: TenantField;
  middleName?: TenantField;
  idCardNumber?: TenantField;
  identityDocumentType?: TenantField;
  isUserConsentEmailNotification?: TenantField;
  isUserConsentSmsNotification?: TenantField;
  preferedCommunicationChannel?: TenantField;
}

export interface TenantFormValidation {
  name?: Validator;
  subscriptionId?: Validator;
  databaseName?: Validator;
  language?: Validator;
  regionalFormat?: Validator;
  timeZone?: Validator;

  username?: Validator;
  emailAddress?: Validator;
  phoneNumber?: Validator;
  password?: Validator;
  firstName?: Validator;
  lastName?: Validator;
}

export default function CreateUpdateTenantSidebar(data: DataTenant) {
  const getTenantData = useAppSelector((state) => state.getTenant);
  const addTenantData = useAppSelector((state) => state.addTenant);
  const dispatch = useAppDispatch();
  let tabInstance = useRef<TabComponent>(null);
  const [showServerErrorMessage, setShowServerErrorMessage] = useState(false);
  const [showServerSuccessMessage, setShowServerSuccessMessage] = useState(false);
  const [actu, setActu] = useState(false);

  let closefailedMsg = document?.getElementById("msg_error")?.getElementsByClassName("e-msg-close-icon")
  for (var i = 0; i < closefailedMsg?.length; i++) {
    closefailedMsg[i]?.addEventListener("click", () => {
      setShowServerErrorMessage(false);
      setShowServerSuccessMessage(false);
      document?.getElementById("msg_error")?.setAttribute("class", "h-0 hidden");
      document?.getElementById("msg_server")?.setAttribute("class", "h-0 hidden");
    })
  }

  let closefailedMsgGet = document
    ?.getElementById("msg_error_get")
    ?.getElementsByClassName("e-msg-close-icon");
  for (var j = 0; j < closefailedMsgGet?.length; j++) {
    closefailedMsgGet[j]?.addEventListener("click", () => {
      setShowServerErrorMessage(false);
      document.getElementById("msg_error_get")?.setAttribute("class", "h-0 hidden");
      document
        .getElementById("msg_server_get")
        ?.setAttribute("class", "h-0 hidden");
    });
  }

  const [tenantModel, setTenantModel] = useState<TenantForm>({});

  const tenantModelValidation: TenantFormValidation = {
    name: {
      validatorType: ValidationType.REQUIRED,
      message: "Nom vide"
    },
    subscriptionId: {
      validatorType: ValidationType.REQUIRED,
      message: "Identifiant d'abonnement vide"
    },
    databaseName: {
      validatorType: ValidationType.REQUIRED,
      message: "Base de donnees vide"
    },
    language: {
      validatorType: ValidationType.REQUIRED,
      message: "Langue vide"
    },
    regionalFormat: {
      validatorType: ValidationType.REQUIRED,
      message: "Formatage regional vide"
    },
    timeZone: {
      validatorType: ValidationType.REQUIRED,
      message: "Fuseau horaire vide"
    },
    username: {
      validatorType: ValidationType.REQUIRED,
      message: "Nom d'utilisateur vide"
    },
    emailAddress: {
      validatorType: ValidationType.EMAIL,
      message: "Adresse e-mail non conforme"
    },
    phoneNumber: {
      validatorType: ValidationType.PHONE_NUMBER,
      message: "Numero de téléphone non conforme avec votre region"
    },
    password: {
      validatorType: ValidationType.REQUIRED,
      message: "mot de passe vide"
    },
    firstName: {
      validatorType: ValidationType.REQUIRED,
      message: "Prenom d'administrateur vide"
    },
    lastName: {
      validatorType: ValidationType.REQUIRED,
      message: "Nom d'administrateur vide"
    }
  }

  const initialData = () => {
    setTenantModel({})
    setShowServerErrorMessage(false);
    setShowServerSuccessMessage(false);
    setActu(false);
    tabInstance?.current?.select(0);
    tabInstance?.current?.select(1);
    tabInstance?.current?.select(0);
  }

  if (data?.isEditing && !actu && !getTenantData?.pending) {
    
    setTenantModel({
      name: { value: getTenantData?.value?.vendor?.name?.toString(), error: '' },
      subscriptionId: { value: getTenantData?.value?.vendor?.subscriptionID?.toString(), error: '' },
      databaseName: { value: getTenantData?.value?.vendor?.databaseName?.toString(), error: '' },
      language: { value: getTenantData?.value?.vendor?.language?.toString(), error: '' },
      regionalFormat: { value: getTenantData?.value?.vendor?.regionalFormatId?.toString(), error: '' },
      timeZone: { value: getTenantData?.value?.vendor?.timeZoneId?.toString(), error: '' },
      description: { value: getTenantData?.value?.vendor?.description?.toString(), error: '' },
      logo: { value: getTenantData?.value?.vendor?.logoUrl?.toString(), error: '' },
      detail: { value: getTenantData?.value?.vendor?.detail?.toString(), error: '' },
      isEnable: { value: getTenantData?.value?.vendor?.isEnable?.valueOf(), error: '' },

      username: { value: getTenantData?.value?.vendor?.defaultAdministrator?.userName?.toString(), error: '' },
      password: { value: getTenantData?.value?.vendor?.defaultAdministrator?.password?.toString(), error: '' },
      firstName: { value: getTenantData?.value?.vendor?.defaultAdministrator?.firstName?.toString(), error: '' },
      lastName: { value: getTenantData?.value?.vendor?.defaultAdministrator?.lastName?.toString(), error: '' },
      middleName: { value: getTenantData?.value?.vendor?.defaultAdministrator?.middleName?.toString(), error: '' },
      emailAddress: { value: getTenantData?.value?.vendor?.defaultAdministrator?.emailAddress?.toString(), error: '' },
      phoneNumber: { value: getTenantData?.value?.vendor?.defaultAdministrator?.phoneNumber?.toString(), error: '' },
      idCardNumber: { value: getTenantData?.value?.vendor?.defaultAdministrator?.idCardNumber?.toString(), error: '' },
      identityDocumentType: { value: parseInt(getTenantData?.value?.vendor?.defaultAdministrator?.identityDocumentType?.toString()), error: '' },
      isUserConsentEmailNotification: { value: getTenantData?.value?.vendor?.defaultAdministrator?.isUserConsentEmailNotification?.valueOf(), error: '' },
      isUserConsentSmsNotification: { value: getTenantData?.value?.vendor?.defaultAdministrator?.isUserConsentSmsNotification?.valueOf(), error: '' },
      preferedCommunicationChannel: { value: parseInt(getTenantData?.value?.vendor?.defaultAdministrator?.preferedCommunicationChannel.toString()), error: '' },
    });
    setActu(true);
  }

  const handleSubmit = (e) => {
    e.preventDefault();
    const tenantForm = document.querySelector("form");
    const formData = new FormData(tenantForm);
    if (data?.isEditing) {
      formData.append("databaseName", getTenantData?.value?.vendor?.databaseName?.toString())
      formData.append("subscriptionID", getTenantData?.value?.vendor?.subscriptionID?.toString())
      formData.append("DefaultAdministrator.Password", "Pa$$w0rd")
      // formData.append("DefaultAdministrator.Password", getTenantData?.value?.vendor?.defaultAdministrator?.password?.toString())
      formData.append("DefaultAdministrator.IsUserConsentEmailNotification", getTenantData?.value?.vendor?.defaultAdministrator?.isUserConsentEmailNotification ? 'true' : 'false')
      formData.append("DefaultAdministrator.IsUserConsentSmsNotification", getTenantData?.value?.vendor?.defaultAdministrator?.isUserConsentSmsNotification ? 'true' : 'false')
    }
    const valueIsEnable: boolean = formData.get("isEnable")?.toString() === 'true'
    formData.delete("isEnable")
    formData.append("isEnable", !valueIsEnable ? 'true' : 'false')
    formData.append("Status", !valueIsEnable ? 'ENABLED' : 'DISABLED ')

    const nameErr: Validator = validateFormData(formData.get("name"), tenantModelValidation.name).errors
    const subscriptionIdErr: Validator = validateFormData(formData.get("subscriptionID"), tenantModelValidation.subscriptionId).errors
    const databaseNameErr: Validator = validateFormData(formData.get("databaseName"), tenantModelValidation.databaseName).errors
    const languageErr: Validator = validateFormData(formData.get("languageId"), tenantModelValidation.language).errors
    const regionalFormatErr: Validator = validateFormData(formData.get("regionalFormatId"), tenantModelValidation.regionalFormat).errors
    const timeZoneErr: Validator = validateFormData(formData.get("timeZoneId"), tenantModelValidation.timeZone).errors
    const usernameErr: Validator = validateFormData(formData.get("DefaultAdministrator.UserName"), tenantModelValidation.username).errors
    const passwordErr: Validator = validateFormData(formData.get("DefaultAdministrator.Password"), tenantModelValidation.password).errors
    const firstNameErr: Validator = validateFormData(formData.get("DefaultAdministrator.FirstName"), tenantModelValidation.firstName).errors
    const lastNameErr: Validator = validateFormData(formData.get("DefaultAdministrator.LastName"), tenantModelValidation.lastName).errors
    const emailAddressErr: Validator = validateFormData(formData.get("DefaultAdministrator.EmailAddress"), tenantModelValidation.emailAddress).errors
    const phoneNumberErr: Validator = validateFormData(formData.get("DefaultAdministrator.PhoneNumber"), tenantModelValidation.phoneNumber, formData.get("regionalFormatId")?.toString().split('-')[1]).errors

    setTenantModel({
      name: { value: formData.get("name")?.toString(), error: nameErr?.message ?? '' },
      subscriptionId: { value: formData.get("subscriptionID")?.toString(), error: subscriptionIdErr?.message ?? '' },
      databaseName: { value: formData.get("databaseName")?.toString(), error: databaseNameErr?.message ?? '' },
      language: { value: formData.get("languageId")?.toString(), error: languageErr?.message ?? '' },
      regionalFormat: { value: formData.get("regionalFormatId")?.toString(), error: regionalFormatErr?.message ?? '' },
      timeZone: { value: formData.get("timeZoneId")?.toString(), error: timeZoneErr?.message ?? '' },
      description: { value: formData.get("description")?.toString(), error: timeZoneErr?.message ?? '' },
      logo: { value: formData.get("logoUrl")?.toString(), error: timeZoneErr?.message ?? '' },
      detail: { value: formData.get("detail")?.toString(), error: timeZoneErr?.message ?? '' },
      isEnable: { value: formData.get("isEnable")?.toString() === 'true', error: "" },

      username: { value: formData.get("DefaultAdministrator.UserName")?.toString(), error: usernameErr?.message ?? '' },
      password: { value: formData.get("DefaultAdministrator.Password")?.toString(), error: passwordErr?.message ?? '' },
      firstName: { value: formData.get("DefaultAdministrator.FirstName")?.toString(), error: firstNameErr?.message ?? '' },
      lastName: { value: formData.get("DefaultAdministrator.LastName")?.toString(), error: lastNameErr?.message ?? '' },
      emailAddress: { value: formData.get("DefaultAdministrator.EmailAddress")?.toString(), error: emailAddressErr?.message ?? '' },
      phoneNumber: { value: formData.get("DefaultAdministrator.PhoneNumber")?.toString(), error: phoneNumberErr?.message ?? '' },
      middleName: { value: formData.get("DefaultAdministrator.MiddleName")?.toString(), error: '' },
      idCardNumber: { value: formData.get("DefaultAdministrator.IdCardNumber")?.toString(), error: '' },
      identityDocumentType: { value: formData.get("DefaultAdministrator.IdentityDocumentType")?.toString(), error: '' },
      isUserConsentEmailNotification: { value: formData.get("DefaultAdministrator.IsUserConsentEmailNotification")?.toString() === "true", error: '' },
      isUserConsentSmsNotification: { value: formData.get("DefaultAdministrator.IsUserConsentSmsNotification")?.toString() === "true", error: '' },
      preferedCommunicationChannel: { value: formData.get("DefaultAdministrator.PreferedCommunicationChannel")?.toString(), error: '' }
    })


    if (!(nameErr?.message || subscriptionIdErr?.message || databaseNameErr?.message || languageErr?.message ||
      regionalFormatErr?.message || timeZoneErr?.message || usernameErr?.message || passwordErr?.message || firstNameErr?.message ||
      lastNameErr?.message || emailAddressErr?.message || phoneNumberErr?.message)) {
      formData.append("key", getTenantData?.value?.vendor?.key);
      dispatch(addTenant(formData));
      setShowServerErrorMessage(true);
      setShowServerSuccessMessage(true);
    } else {
      if (!(nameErr?.message || subscriptionIdErr?.message || databaseNameErr?.message || languageErr?.message ||
        regionalFormatErr?.message || timeZoneErr?.message)) {
        tabInstance?.current?.select(1);
      }
      if (!(usernameErr?.message || passwordErr?.message || firstNameErr?.message ||
        lastNameErr?.message || emailAddressErr?.message || phoneNumberErr?.message)) {
        tabInstance?.current?.select(0);
      }
    }
  };

  const animateSidebar: TabAnimationSettingsModel = {
    previous: { effect: "None", duration: 600, easing: "ease" },
    next: { effect: "None", duration: 600, easing: "ease" },
  };

  const allLanguage = (): { [key: string]: Object }[] => {
    let newLang: { [key: string]: Object }[] = [];
    getTenantData.value.languages.map((item) =>
      newLang.push({
        value: item.twoLetterISOLanguageName,
        langue: item.displayName,
        iconLang: "",
      })
    );
    return newLang;
  };

  const allTimeZone = (): { [key: string]: Object }[] => {
    let newTime: { [key: string]: Object }[] = [];
    getTenantData.value.timeZones.map((item) =>
      newTime.push({
        value: item.id,
        timeZone: item.displayName,
        iconTime: "",
      })
    );
    return newTime;
  };

  const allDocumentTypes = (): { [key: string]: Object }[] => {
    let newDocumentTypes: { [key: string]: Object }[] = [];
    getTenantData.value.idDocumentTypes.map((item) =>
      newDocumentTypes.push({
        value: item.id,
        iddocumenttype: item.displayName,
        icontype: "",
      })
    );
    return newDocumentTypes;
  };

  const allRegionalFormat = (): { [key: string]: Object }[] => {
    let newTime: { [key: string]: Object }[] = [];
    getTenantData.value.regionalFormats.map((item) =>
      newTime.push({
        value: item.id,
        regionalFormat: item.displayName,
        iconRegionalFormat: "",
      })
    );
    return newTime;
  };

  // idDocumentTypes
  const language: { [key: string]: Object }[] = allLanguage();
  const languageFields: ItemFields = {
    text: "langue",
    value: "value",
    iconCss: "iconLang",
  };

  const timeZone: { [key: string]: Object }[] = allTimeZone();
  const timeZoneFields: ItemFields = {
    text: "timeZone",
    value: "value",
    iconCss: "iconTime",
  };

  const regionalFormat: { [key: string]: Object }[] = allRegionalFormat();
  const regionalFormatFields: ItemFields = {
    text: "regionalFormat",
    value: "value",
    iconCss: "iconRegionalFormat",
  };

  const preferedCommunicationChannel: { [key: string]: Object }[] = [
    { value: '0', channel: "E-MAIL", iconchan: "" },
    { value: '1', channel: "SMS", iconchan: "" },
  ];
  const preferedCommunicationChannelFields: ItemFields = {
    text: "channel",
    value: "value",
    iconCss: "iconchan",
  };

  const identityDocumentType: { [key: string]: Object }[] = allDocumentTypes();
  const identityDocumentTypeFields: ItemFields = {
    text: "iddocumenttype",
    value: "value",
    iconCss: "icontype",
  };

  let headertext: any = [
    { text: "Général", iconCss: "icon" },
    { text: "Administrateur", iconCss: "icon" },
  ];

  const GeneralTab = () => {
    return (
      getTenantData.pending ? (
        <div className="flex flex-col w-full h-full gap-0 mx-auto">
          <div className="username w-full mx-auto"><ShimmerText /></div>
          <div className="username w-full mx-auto"><ShimmerText /></div>
          <div className="username w-full mx-auto"><ShimmerText /></div>
        </div>
      ) :
        (<div className="flex flex-col justify-between items-center gap-4 w-full my-4 px-4 form">
          <div className="flex flex-row gap-3 items-start justify-between names w-full">
            <div className="flex flex-col gap-3 nom w-full">
              <label htmlFor="name">Nom du locataire</label>
              <InputWithIcon
                type={"text"}
                name={"name"}
                id={"name"}
                placeholder={"Nom du locataire"}
                defaultValue={tenantModel?.name?.value?.toString()}
                className="w-full"
              />
              {tenantModel.name?.error && <div className="error">{tenantModel.name?.error}</div>}
            </div>
            <div className="flex flex-col gap-3 subscriptionId w-full">
              <label htmlFor="subscriptionId">Identifiant d'abonnement</label>
              <InputWithIcon
                type={"text"}
                name={"subscriptionID"}
                id={"subscriptionId"}
                placeholder={"Identifiant d'abonnement"}
                defaultValue={tenantModel?.subscriptionId?.value?.toString()}
                className="w-full"
                disabled={data?.isEditing}
              />{tenantModel.subscriptionId?.error && <div className="error">{tenantModel.subscriptionId?.error}</div>}
            </div>
          </div>
          <div className="flex flex-col gap-3 databaseName w-full">
            <label htmlFor="databaseName">Nom de base données</label>
            <InputWithIcon
              type={"text"}
              name={"databaseName"}
              id={"databaseName"}
              placeholder={"Nom de base données"}
              defaultValue={tenantModel?.databaseName?.value?.toString()}
              className="w-full bg-white"
              disabled={data?.isEditing}
            />
            {tenantModel.databaseName?.error && <div className="error">{tenantModel.databaseName?.error}</div>}
          </div>

          <div className="flex flex-col gap-3 logo w-full">
            <label htmlFor="logo">Logo</label>
            <FileInput error={false}
              name={"logoUrl"}
              id={"logo"}
              placeholder={"Logo"} />
            {tenantModel.logo?.error && <div className="error">{tenantModel.logo?.error}</div>}
          </div>
          <div className="flex flex-row justify-between items-center gap-3 status w-full mt-2">
            <label htmlFor="Statu">
              Désactiver le locataire
            </label>
            <SwitchComponent
              id="isEnable"
              checked={!(tenantModel?.isEnable?.value)}
              value="true"
              name="isEnable"
              cssClass=""
            ></SwitchComponent>
          </div>

          <div className="language flex flex-col gap-3 w-full">
            <label htmlFor="language">Langue</label>
            <DropDownListComponent
              cssClass="w-full border px-2 py-1 input-notify bg-white"
              id="language"
              name="languageId"
              dataSource={language}
              fields={languageFields}
              value={tenantModel?.language?.value?.toString()}
              placeholder={"Choisissez votre langue"}
              popupHeight="220px"
            />
            {tenantModel.language?.error && <div className="error">{tenantModel.language?.error}</div>}
          </div>
          <div className="flex flex-row gap-3 items-start justify-between contact w-full">
            <div className="regionalFormat flex flex-col gap-3 w-full">
              <label htmlFor="regionalFormat">Formatage régional</label>
              <DropDownListComponent
                cssClass="w-full border px-2 py-1 input-notify bg-white"
                id="regionalFormatId"
                dataSource={regionalFormat}
                fields={regionalFormatFields}
                value={tenantModel?.regionalFormat?.value?.toString()}
                placeholder={"Choisissez votre formatage régional"}
                popupHeight="220px"
              />
              {tenantModel.regionalFormat?.error && <div className="error">{tenantModel.regionalFormat?.error}</div>}
            </div>
            <div className="timeZone flex flex-col gap-3 w-full">
              <label htmlFor="timeZone">Fuseau horaire</label>
              <DropDownListComponent
                cssClass="w-full border px-2 py-1 input-notify bg-white"
                id="timeZoneId"
                name="timeZoneId"
                dataSource={timeZone}
                fields={timeZoneFields}
                value={tenantModel?.timeZone?.value?.toString()}
                placeholder={"Choisissez votre fuseau horaire"}
                popupHeight="220px"
              />
              {tenantModel.timeZone?.error && <div className="error">{tenantModel.timeZone?.error}</div>}
            </div>
          </div>
          <div className="description flex flex-col gap-3 w-full">
            <label htmlFor="description">Description</label>
            <TextArea
              name="description"
              id="description"
              defaultValue={tenantModel?.description?.value?.toString()}
              cols={30}
              rows={9}
              className="w-full border px-2 py-1 input-sidebar bg-white"
            ></TextArea>
          </div>
        </div>)
    );
  };

  const adminTab = () => (
    getTenantData.pending ? (
      <div className="flex flex-col w-full h-full gap-0 mx-auto">
        <div className="username w-full mx-auto"><ShimmerText /></div>
        <div className="username w-full mx-auto"><ShimmerText /></div>
        <div className="username w-full mx-auto"><ShimmerText /></div>
      </div>
    ) :
      (<div className="flex flex-col justify-between items-center gap-4 w-full my-4 px-4 form">
        <div className="flex flex-row gap-3 items-start justify-between login w-full">
          <div className="flex flex-col gap-3 userName w-full">
            <label htmlFor="userName">Nom d'utilisateur</label>
            <InputWithIcon
              type={"text"}
              name={"DefaultAdministrator.UserName"}
              id={"userName"}
              placeholder={"Nom d'utilisateur"}
              defaultValue={tenantModel?.username?.value?.toString()}
              readOnly={
                getTenantData?.value?.vendor?.defaultAdministrator?.id !== ""
              }
              className="w-full"
            />
            {tenantModel.username?.error && <div className="error">{tenantModel.username?.error}</div>}
          </div>
          {getTenantData?.value?.vendor?.defaultAdministrator?.id === "" ? (
            <div className="flex flex-col gap-3 password w-full">
              <label htmlFor="password">Mot de passe</label>
              <InputWithIcon
                type={"password"}
                name={"DefaultAdministrator.Password"}
                id={"password"}
                placeholder={"Mot de passe"}
                defaultValue={tenantModel?.password?.value?.toString()}
                readOnly={
                  getTenantData?.value?.vendor?.defaultAdministrator?.id !== ""
                }
                className="w-full bg-white"
              />
              {tenantModel.password?.error && <div className="error">{tenantModel.password?.error}</div>}
            </div>
          ) : ("")}
        </div>
        <div className="flex flex-row gap-3 items-start justify-between name w-full">
          <div className="flex flex-col gap-3 lastName w-full">
            <label htmlFor="lastName">Noms</label>
            <InputWithIcon
              type={"text"}
              name={"DefaultAdministrator.LastName"}
              id={"lastName"}
              placeholder={"Noms"}
              defaultValue={tenantModel?.lastName?.value?.toString()}
              readOnly={
                getTenantData?.value?.vendor?.defaultAdministrator?.id !== ""
              }
              className="w-full"
            />
            {tenantModel.lastName?.error && <div className="error">{tenantModel.lastName?.error}</div>}
          </div>
          <div className="flex flex-col gap-3 middleName w-full">
            <label htmlFor="middleName">Deuxième nom</label>
            <InputWithIcon
              type={"text"}
              name={"DefaultAdministrator.MiddleName"}
              id={"middleName"}
              placeholder={"Deuxième nom"}
              defaultValue={tenantModel?.middleName?.value?.toString()}
              readOnly={
                getTenantData?.value?.vendor?.defaultAdministrator?.id !== ""
              }
              className="w-full bg-white"
            />
          </div>
        </div>
        <div className="flex flex-col gap-3 firstName w-full">
          <label htmlFor="firstName">Prénoms</label>
          <InputWithIcon
            type={"text"}
            name={"DefaultAdministrator.FirstName"}
            id={"firstName"}
            placeholder={"Prénoms"}
            defaultValue={tenantModel?.firstName?.value?.toString()}
            readOnly={
              getTenantData?.value?.vendor?.defaultAdministrator?.id !== ""
            }
            className="w-full"
          />
          {tenantModel.firstName?.error && <div className="error">{tenantModel.firstName?.error}</div>}
        </div>
        <div className="flex flex-row gap-3 items-start justify-between name w-full">
          <div className="flex flex-col gap-3 identityDocumentType w-full">
            <label htmlFor="identityDocumentType">Type de pièce d'identité</label>
            <DropDownListComponent
              cssClass="w-full border px-2 py-1 input-notify bg-white disabled"
              disabled={getTenantData?.value?.vendor?.defaultAdministrator?.id !== ""}
              readonly={getTenantData?.value?.vendor?.defaultAdministrator?.id !== ""}
              id="identityDocumentType"
              dataSource={identityDocumentType}
              fields={identityDocumentTypeFields}
              value={parseInt(tenantModel?.identityDocumentType?.value?.toString()) ?? 0}
              name="DefaultAdministrator.IdentityDocumentType"
              placeholder={"Choisissez votre type de pièce d'identité"}
              popupHeight="220px"
            />
          </div>
          <div className="flex flex-col gap-3 idCardNumber w-full">
            <label htmlFor="idCardNumber">Numéro de pièce d'identité</label>
            <InputWithIcon
              type={"text"}
              name={"DefaultAdministrator.IdCardNumber"}
              id={"idCardNumber"}
              placeholder={"Numéro de pièce d'identité"}
              defaultValue={tenantModel?.idCardNumber?.value?.toString()}
              readOnly={
                getTenantData?.value?.vendor?.defaultAdministrator?.id !== ""
              }
              className="w-full"
            />
          </div>
        </div>

        <div className="flex flex-row gap-3 items-start justify-between contact w-full">
          <div className="flex flex-col gap-3 emailAddress w-full">
            <label htmlFor="emailAddress">Adresse e-mail</label>
            <InputWithIcon
              type={"text"}
              name={"DefaultAdministrator.EmailAddress"}
              id={"emailAddress"}
              placeholder={"Adresse e-mail"}
              defaultValue={tenantModel?.emailAddress?.value?.toString()}
              readOnly={
                getTenantData?.value?.vendor?.defaultAdministrator?.id !== ""
              }
              className="w-full"
            />
            {tenantModel.emailAddress?.error && <div className="error">{tenantModel.emailAddress?.error}</div>}
          </div>
          <div className="flex flex-col gap-3 phoneNumber w-full">
            <label htmlFor="phoneNumber">Numéro de téléphone</label>
            <InputWithIcon
              type={"text"}
              name={"DefaultAdministrator.PhoneNumber"}
              id={"phoneNumber"}
              placeholder={"Numéro de téléphone"}
              defaultValue={tenantModel?.phoneNumber?.value?.toString()}
              readOnly={
                getTenantData?.value?.vendor?.defaultAdministrator?.id !== ""
              }
              className="w-full bg-white"
            />
            {tenantModel.phoneNumber?.error && <div className="error">{tenantModel.phoneNumber?.error}</div>}
          </div>
        </div>
        <div className="flex flex-row justify-between items-center gap-3 isUserConsentEmailNotification w-full mt-4">
          <label htmlFor="isUserConsentEmailNotification">
            Recevoir les notifications par e-mail
          </label>
          <SwitchComponent
            id="isUserConsentEmailNotificatio"
            checked={!data?.isEditing ||
              getTenantData?.value?.vendor?.defaultAdministrator
                ?.isUserConsentEmailNotification
            }
            value="true"
            name="DefaultAdministrator.IsUserConsentEmailNotification"
            cssClass=""
            disabled={
              getTenantData?.value?.vendor?.defaultAdministrator?.id !== ""
            }
            readOnly={
              getTenantData?.value?.vendor?.defaultAdministrator?.id !== ""
            }
          ></SwitchComponent>
        </div>
        <div className="flex flex-row justify-between items-center gap-3 isUserConsentSmsNotification w-full">
          <label htmlFor="isUserConsentSmsNotificatio">
            Recevoir les notifications par sms
          </label>
          <SwitchComponent
            id="isUserConsentSmsNotification"
            checked={!data?.isEditing ||
              getTenantData?.value?.vendor?.defaultAdministrator
                ?.isUserConsentSmsNotification
            }
            value="true"
            name="DefaultAdministrator.IsUserConsentSmsNotification"
            cssClass=""
            disabled={
              getTenantData?.value?.vendor?.defaultAdministrator?.id !== ""
            }
            readOnly={
              getTenantData?.value?.vendor?.defaultAdministrator?.id !== ""
            }
          ></SwitchComponent>
        </div>
        <div className="flex flex-col gap-3 preferedCommunicationChannel w-full">
          <label htmlFor="preferedCommunicationChanne">
            Choisissez votre canal de notification préférée
          </label>
          <DropDownListComponent
            cssClass="w-full border px-2 py-1 input-notify bg-white disabled"
            disabled={getTenantData?.value?.vendor?.defaultAdministrator?.id !== ""}
            readonly={getTenantData?.value?.vendor?.defaultAdministrator?.id !== ""}
            id="preferedCommunicationChannel"
            dataSource={preferedCommunicationChannel}
            fields={preferedCommunicationChannelFields}
            value={tenantModel?.preferedCommunicationChannel?.value?.toString() ?? '0'}
            name="DefaultAdministrator.PreferedCommunicationChannel"
            placeholder={"Choisissez votre canal de notification préférée"}
            popupHeight="220px"
          />
        </div>
      </div>)
  );

  return (
    <SidebarComponent
      ref={data?.func?.sidebarInstance}
      closeOnDocumentClick={false}
      showBackdrop={data?.func?.isShowBackdrop}
      width="700px"
      target=".apimaincontent"
      id="apiSidebar"
      className="tenant-sidebar"
      type={"Over"}
      enableGestures={false}
      position={"Right"}
      open={() => initialData()}
    >
      <div className="flex flex-col justify-start items-center h-full py-7 relative">
        <div className="flex flex-row justify-between w-full px-9 mt- mb-2">
          <h2 className="text-3xl title">{data?.isEditing ? "Modification du locataire" : "Ajouter un locataire"}</h2>
          <span
            className="icon cursor-pointer cancelicon- text-2xl"
            onClick={data?.func?.sidebarClose?.bind(this)}
          ></span>
        </div>
        {addTenantData.value && !addTenantData.pending && showServerSuccessMessage ? (
          <div className="absolut mt-[25vh] h-[30vh] w-3/4 mx-auto">
            <OperationResultComponent
              message={data?.isEditing ? "Locataire modifié avec success" : "Locataire ajouté avec success"}
              title={data?.isEditing ? 'Modification du locataire' : 'Ajout de locataire'}
              titleButton={'Fermez cette page et consultez la liste'}
            />
          </div>
        ) : (
          <form
            className="flex flex-col justify-start items-center content py-4 px-8 w-full h-full"
            onSubmit={handleSubmit}
            encType="multipart/form-data"
          >
            {addTenantData.Errors && showServerErrorMessage &&
              addTenantData.Errors.length > 0 &&
              !addTenantData.pending &&
              addTenantData.Errors.map((message, key) => {
                return (
                  <div className="w-full mx-auto" id="msg_server" key={key}>
                    <MessageComponent
                      showCloseIcon
                      id="msg_error"
                      className="errorServer m-1"
                      content={message}
                      key={key}
                      severity="Error"
                    ></MessageComponent>
                  </div>
                );
              })}
            {getTenantData.Errors && showServerErrorMessage &&
              getTenantData.Errors.length > 0 &&
              !getTenantData.pending &&
              getTenantData.Errors.map((message, key) => {
                return (
                  <div className="w-full mx-auto" id="msg_server_get" key={key}>
                    <MessageComponent
                      showCloseIcon
                      id="msg_error_get"
                      className="errorServer m-1"
                      content={message}
                      key={key}
                      severity="Error"
                    ></MessageComponent>
                  </div>
                );
              })}
            <TabComponent
              id="tenantSidebarTab"
              cssClass="border-0 border-transparent h-full mb-auto"
              animation={animateSidebar}
              ref={tabInstance}
            >
              <TabItemsDirective>
                <TabItemDirective header={headertext[0]} content={() => GeneralTab()} />
                <TabItemDirective header={headertext[1]} content={() => adminTab()} />
              </TabItemsDirective>
            </TabComponent>

            <div className="flex flex-row gap-4 justify-end footer px-4 py-4 ms-auto">
              <Button
                param={{
                  type: "button",
                  name: "Annuler",
                  handleClick: data?.func?.sidebarClose?.bind(this),
                  css: (addTenantData?.pending ? "disabled": "") + " cancelBtn w-full",
                  disabled: addTenantData?.pending,
                }}
              />
              <Button
                param={{
                  type: "button",
                  name: "Valider",
                  handleClick: handleSubmit,
                  css: (addTenantData?.pending ? "disabled": "") + " okBtn w-full",
                  disabled: addTenantData?.pending,
                }}
              />
            </div>
          </form>
        )}
      </div>
    </SidebarComponent>
  );
}
