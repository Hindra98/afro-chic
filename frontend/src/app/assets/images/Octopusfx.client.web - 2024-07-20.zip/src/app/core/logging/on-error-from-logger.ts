export const onErrorFromLoggerHandler = () => {

    console.log("Error occurs while sending logs to the server.");

}