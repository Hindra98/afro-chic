import { DeleteBrandAction, DeleteBrandFailurePayload, DeleteBrandSuccessPayload, GetBrandAction, GetBrandFailurePayload, GetBrandsAction, GetBrandsFailurePayload, UpdateBrandAction, UpdateBrandFailurePayload, UpdateBrandSuccessPayload } from ".";
import { ActionTypes } from "../constants/action-types";



export const getBrands = (): GetBrandsAction => {
  return {
      type: ActionTypes.BRANDS_REQUEST,
      payload : {
          command: null,
          value: null,
          errors: null
      }
  } as GetBrandsAction
};
export const getBrandsFailure = (payload: GetBrandsFailurePayload): GetBrandsAction => {
  return {
      type: ActionTypes.BRANDS_FAILURE,
      payload : {
          command: null,
          value: null,
          errors: payload
      }
  } as GetBrandsAction
};
export const getBrandsSuccess = (payload: GetBrands): GetBrandsAction => {
  return {
      type: ActionTypes.BRANDS_SUCCESS,
      payload : {
          command: null,
          value: payload,
          errors: null
      }
  } as GetBrandsAction
};


export const getBrand = (command: BrandCommand): GetBrandAction => {
  return {
      type: ActionTypes.BRAND_REQUEST,
      payload : {
          command: command,
          value: null,
          errors: null
      }
  } as GetBrandAction
};
export const getBrandFailure = (payload: GetBrandFailurePayload): GetBrandAction => {
  return {
      type: ActionTypes.BRAND_FAILURE,
      payload : {
          command: null,
          value: null,
          errors: payload
      }
  } as GetBrandAction
};
export const getBrandSuccess = (payload: GetBrand): GetBrandAction => {
  return {
      type: ActionTypes.BRAND_SUCCESS,
      payload : {
          command: null,
          value: payload,
          errors: null
      }
  } as GetBrandAction
};


export const updateBrand = (command: UpdateBrandCommand): UpdateBrandAction => {
  return {
      type: ActionTypes.UPDATE_BRAND_REQUEST,
      payload : {
          command: command,
          value: null,
          errors: null
      }
  } as UpdateBrandAction
};
export const updateBrandFailure = (payload: UpdateBrandFailurePayload): UpdateBrandAction => {
  return {
      type: ActionTypes.UPDATE_BRAND_FAILURE,
      payload : {
          command: null,
          value: null,
          errors: payload
      }
  } as UpdateBrandAction
};
export const updateBrandSuccess = (payload: UpdateBrandSuccessPayload): UpdateBrandAction => {
  return {
      type: ActionTypes.UPDATE_BRAND_SUCCESS,
      payload : {
          command: null,
          value: payload,
          errors: null
      }
  } as UpdateBrandAction
};


export const deleteBrand = (command: DeleteBrandCommand): DeleteBrandAction => {
  return {
      type: ActionTypes.DELETE_BRAND_REQUEST,
      payload : {
          command: command,
          value: null,
          errors: null
      }
  } as DeleteBrandAction
};
export const deleteBrandFailure = (payload: DeleteBrandFailurePayload): DeleteBrandAction => {
  return {
      type: ActionTypes.DELETE_BRAND_FAILURE,
      payload : {
          command: null,
          value: null,
          errors: payload
      }
  } as DeleteBrandAction
};
export const deleteBrandSuccess = (payload: DeleteBrandSuccessPayload): DeleteBrandAction => {
  return {
      type: ActionTypes.DELETE_BRAND_SUCCESS,
      payload : {
          command: null,
          value: payload,
          errors: null
      }
  } as DeleteBrandAction
};
