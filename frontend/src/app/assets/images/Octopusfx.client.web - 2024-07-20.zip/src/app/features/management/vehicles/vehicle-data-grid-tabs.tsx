import {
  ColumnDirective,
  ColumnsDirective,
  Edit,
  ExcelExport,
  ExcelExportProperties,
  Filter,
  Sort,
  GridComponent,
  Inject,
  Page,
  PdfExport,
  PdfExportProperties,
  Resize,
  Selection,
  RecordClickEventArgs,
} from "@syncfusion/ej2-react-grids";
import { useEffect, useRef, useState } from "react";
import { useAppDispatch, useAppSelector } from "src/app/core/hooks/core-hooks";
import "src/app/styles/_notifications.scss";
import ToolsbarOptions from "src/app/components/shared/grid-components/toolsbar-options";
import emptyrecords from "src/app/components/shared/grid-components/empty-records";
import iconVehicle from "src/app/assets/image-octopusfx/user.png";
import { GridConstants } from "src/app/core/constants/data-grid";
import { deleteVehicle, getVehicle, getVehicles } from "src/app/store-management/actions/vehicles/vehicles-actions";
import { MessageComponent } from "@syncfusion/ej2-react-notifications";

function statusTemplate(props: Vehicle) {
  return (
    <span className={`status rounded-xl text-center py-1 px-3 font-bold ${parseInt(props.status) === 8 ?  "inactive" : parseInt(props.status) === 16 ? "active" : parseInt(props.status) === 2 ? "on-road" : parseInt(props.status) === 4 ? "out-of-service" : "sold" }`}>
      {props.statusWording}
    </span>
  );
}
function nameTemplate(props: Vehicle) {
  return (
    <span
      className={`name-link cursor-pointer hover:text-blue-900 hover:underline hover:font-bold`}
    >
      {props.name}
    </span>
  );
}

type Props = {
  isShowBackdrop?
  isEditing?
  setIsEditing?
  sidebarInstance?
  sidebarClose?
  setShowBackdrop?
  setTiltleDialog?
  setBtnDialog?
  setMessageDialog?
  openDialog?
}

const VehicleDataGridTabs = (props: Props) => {

  let grid = useRef<GridComponent>(null);
  const dispatch = useAppDispatch();

  const getAllVehicles = useAppSelector((state) => state.getVehicles);
  const deleteVehicleData = useAppSelector((state) => state.deleteVehicle);

  const [getRefresh, setGetRefresh] = useState(false);
  const [checkRow, setCheckRow] = useState(false);
  const exportFilename = "vehicule";
  const rowsPerPage = 5;
  const [currentPage, setCurrentPage] = useState(1);

  const getVehiclesData = () => {
    dispatch(getVehicles());
  };
  const getVehicleInfos = (id: string) => {
    dispatch(getVehicle({ SearchCriteria: id } as VehicleCommand));
  };

  function CheckRowsTemplate() {
    const [check, setCheck] = useState(false)
    const handleSelectAllRows = () => {
      let tabs: number[] = [];
      for (let key = 0; key < rowsPerPage; key++) { tabs.push(key) }
      if (grid?.current?.getAllDataRows().length > 0) {
        (check) ? grid?.current?.selectRows([]) : grid?.current?.selectRows(tabs);
        setCheck(!check);
        setCheckRow(!check);
      }
    }
    return (
      <div className="ms-[8px]" onClick={handleSelectAllRows}>
        <span className={`cursor-pointer icon ${check ? "checkicon- text-blue-900" : "check-emptyicon-"} text-[19px]`}></span>
      </div>
    );
  }

  useEffect(() => {
    setCheckRow(grid?.current?.getSelectedRecords()?.length > 0);
  }, [grid]);

  if (
    !getRefresh &&
    !getAllVehicles?.pending &&
    !getAllVehicles?.value?.hasAlreadyCalled &&
    getAllVehicles?.errors?.length === 0
  ) {
    getVehiclesData();
    setGetRefresh(true);
  }

  const [tenantViewModel, setVehicleViewModel] = useState<any>({});

  const handleActionBegin = (args: any) => {
    if (args.requestType === "add" || args.requestType === "beginEdit") {
      props.sidebarInstance?.current?.toggle();
      props.setShowBackdrop(true);
      args.cancel = true;
    }
  };


  const handleAdd = () => {
    if (grid.current) {
      props.setIsEditing(false);
      getVehicleInfos("");
      grid.current.addRecord();
    }
  };

  const handleClickRecord = (e: RecordClickEventArgs) => {
    if (grid.current) {
      const index = e.cellIndex;
      let keyRecord = e.rowData as Vehicle;

      const selectedRecordsLength =
        grid.current.getSelectedRecords() as Vehicle[];
      if (
        selectedRecordsLength.length > 1 ||
        selectedRecordsLength.length === 0
      )
        setCheckRow(true);
      else {
        if (selectedRecordsLength[0].id === keyRecord.id)
          setCheckRow(false);
        else setCheckRow(true);
      }
      if (index > 0) {
        getVehicleInfos(keyRecord.id);
        props.setIsEditing(true);
        setVehicleViewModel({ ...tenantViewModel, id: keyRecord.id });
        grid.current.addRecord();
      }
    }
  };

  const handleDelete = () => {
    if (grid.current) {
      const selectedRecords =
        grid.current.getSelectedRecords() as Vehicle[];
      if (selectedRecords.length === 1) {
        const delValue = { key: selectedRecords[0].id }
        props.setTiltleDialog(`Suppression d'un vehicule: ${selectedRecords[0]?.name}`);
        props.setMessageDialog(
          <p>
            Voulez-vous vraiment supprimer ce vehicule : <b>{selectedRecords[0]?.engineNumber}</b> ?<br />
            Modèle: <b>{selectedRecords[0]?.modelYear}</b><br />
            Boite de vitesse: <b>{selectedRecords[0]?.gearBoxTypeWording}</b><br />
            Status: <b>{selectedRecords[0]?.statusWording}</b><br />
            Energie utilisée: <b>{selectedRecords[0]?.energyTypeWording}</b>
          </p>
        );
        props.setBtnDialog([
          {
            type: "button",
            name: "Annuler",
            css: "cancelBtn",
            handleClick: () => props?.openDialog[1](false),
          },
          {
            type: "button",
            name: "Confirmer",
            css: "okBtn",
            handleClick: () => { dispatch(deleteVehicle(delValue as DeleteVehicleCommand)); props?.openDialog[1](false) }
          },
        ]);
        props?.openDialog[1](true);

      } else {
        props.setTiltleDialog(`Erreur!!!`);
        props.setMessageDialog(<p>Vous devez selectionner au moins un vehicule pour cette opération</p>);
        props.setBtnDialog([
          {
            type: "button",
            name: "Ok",
            css: "okBtn",
            handleClick: () => props?.openDialog[1](false),
          }
        ]);
        props?.openDialog[1](true);
      }
    }
  };


  const editSettings: any = {
    allowEditing: true,
    allowAdding: true,
    allowDeleting: true,
    mode: "Normal",
    allowEditOnDblClick: false,
  };
  const handlePageChange = (page: number) => {
    grid.current.pageSettings.currentPage = page;
    setCurrentPage(page);
  };
  const handleSearch = (searchText: string) => {
    console.log("handle", searchText);
  };

  const select: any = {
    persistSelection: true,
    type: "Single",
    checkboxOnly: false,
    mode: "Both",
    checkboxMode: "ResetOnRowClick",
  };

  const gridFilter: any = { type: "Menu" };
  const pdfExportProperties: PdfExportProperties = {
    header: {
      fromTop: 0,
      height: 130,
      contents: [
        {
          type: "Line",
          style: { penColor: "#000080", penSize: 2, dashStyle: "Solid" },
          points: { x1: 0, y1: 4, x2: 685, y2: 4 },
        },
        {
          type: "Text",
          value: "Liste des vehicules ",
          position: { x: 200, y: 50 },
          style: { textBrushColor: "#000000", fontSize: 20 },
        },
      ],
    },
    footer: {
      fromBottom: 10,
      height: 60,
      contents: [
        {
          type: "Line",
          style: { penColor: "#000080", penSize: 2, dashStyle: "Dot" },
          points: { x1: 0, y1: 4, x2: 685, y2: 4 },
        },
        {
          type: "PageNumber",
          pageNumberType: "Arabic",
          format: "Page {$current} sur {$total}", //optional
          position: { x: 0, y: 25 },
          style: { textBrushColor: "#4169e1", fontSize: 15, hAlign: "Center" },
        },
      ],
    },
    exportType: "AllPages",
  };

  const ExportPdf = () => {
    (grid.current as GridComponent)?.pdfExport({
      ...pdfExportProperties,
      fileName: `${exportFilename}.pdf`,
    });
  };
  const ExportExcel = () => {
    const excelExportProperties: ExcelExportProperties = {
      exportType: "AllPages",
      fileName: `${exportFilename}.xlsx`,
    };
    (grid.current as GridComponent)?.excelExport({ ...excelExportProperties });
  };
  const ExportCsv = () => {
    const excelExportProperties: ExcelExportProperties = {
      exportType: "AllPages",
      fileName: `${exportFilename}.csv`,
    };
    (grid.current as GridComponent)?.csvExport({ ...excelExportProperties });
  };

  window.document.title = "Véhicules";


  return (
    <div className="h-full flex flex-col justify-start mx-auto notifications-component">

      {deleteVehicleData.errors &&
        !deleteVehicleData.value &&
        deleteVehicleData.errors.length > 0 &&
        !deleteVehicleData.pending &&
        deleteVehicleData.errors.map((message, key) => {
          return (
            <div className="w-full mx-auto" id="msg_server" key={key}>
              <MessageComponent
                showCloseIcon
                id="msg_error"
                className="errorServer m-1"
                content={"Erreur lors de la suppression du véhicule: " + message}
                key={key}
                severity="Error"
              ></MessageComponent>
            </div>
          );
        })}

      {!deleteVehicleData.errors &&
        deleteVehicleData.value &&
        !(deleteVehicleData.errors.length > 0) &&
        !deleteVehicleData.pending &&

        <div className="w-full mx-auto" id="msg_server">
          <MessageComponent
            showCloseIcon
            id="msg_error"
            className="errorServer m-1"
            content={"Suppresssion du véhicule éffective"}
            severity="Success"
          ></MessageComponent>
        </div>}

      <ToolsbarOptions
        ToolsbarActionItem={[
          {
            icon: "user-addicon-",
            name: "Ajouter",
            handleClick: () => handleAdd(),
          },
          {
            icon: "trash-emptyicon-",
            name: "Supprimer",
            handleClick: () => handleDelete(),
            disabled: !checkRow,
          },
          {
            icon: "ccwicon-",
            name: "Rafraichir",
            handleClick: () => dispatch(getVehicles()),
          },
        ]}
        allowExportPdf
        allowExportCsv
        allowExportExcel
        handleExportPdf={ExportPdf}
        handleExportExcel={ExportExcel}
        handleExportCsv={ExportCsv}
        enablePager
        pager={{ align: "right" }}
        enablePagination
        pagination={{
          currentPage: currentPage,
          rowsPerPage: rowsPerPage,
          totalPages: parseInt(getAllVehicles?.value?.vehicles?.length.toString()),
          handleChangePage: handlePageChange,
        }}
        enableSearch
        search={{ handleSearch: handleSearch }}
      />
      <GridComponent
        dataSource={getAllVehicles.value.vehicles}
        id="notifications-grid"
        cssClass="mx-2"
        loadingIndicator={{ indicatorType: "Shimmer" }}
        allowResizing={true}
        enableHover={true}
        allowSorting={false}
        allowFiltering={true}
        actionBegin={handleActionBegin}
        recordClick={handleClickRecord}
        emptyRecordTemplate={() =>
          emptyrecords(
            "Aucun véhicule trouvé",
            iconVehicle,
            getAllVehicles.pending,
            "w-1/12"
          )
        }
        resizeSettings={{ mode: "Auto" }}
        rowHeight={38}
        height={GridConstants.HEIGHT_VEHICLE}
        filterSettings={gridFilter}
        allowSelection={true}
        selectionSettings={select}
        enableHeaderFocus={true}
        allowPaging={true}
        autoFit={true}
        allowPdfExport={true}
        allowExcelExport={true}
        editSettings={editSettings}
        pageSettings={{ pageCount: 2, pageSize: rowsPerPage }}
        ref={grid}
      >
        <ColumnsDirective>
          <ColumnDirective
            type="checkbox"
            allowSorting={false}
            allowFiltering={false}
            headerTemplate={CheckRowsTemplate}
            width="40"
          ></ColumnDirective>
          <ColumnDirective
            field="id"
            visible={false}
            headerText="Vehicle Id"
            isPrimaryKey={true}
            width="auto"
          ></ColumnDirective>
          <ColumnDirective
            field="name"
            headerText="Nom du véhicule"
            template={nameTemplate}
            clipMode="EllipsisWithTooltip"
            width="auto"
          />
          <ColumnDirective
            field="registrationNumber"
            headerText="Numérod d'immatriculation"
            clipMode="EllipsisWithTooltip"
            width="auto"
          />
          <ColumnDirective
            field="vehicleTypeWording"
            headerText="Type de véhicule"
            clipMode="EllipsisWithTooltip"
            width="auto"
          />
          <ColumnDirective
            field="brand"
            headerText="Marque"
            clipMode="EllipsisWithTooltip"
            width="auto"
          />
          <ColumnDirective
            field="model"
            headerText="Modèle"
            clipMode="EllipsisWithTooltip"
            width="auto"
          />
          <ColumnDirective
            field="gearBoxTypeWording"
            headerText="Type de boîte de vitesses"
            clipMode="EllipsisWithTooltip"
            width="auto"
          />
          <ColumnDirective
            field="energyTypeWording"
            headerText="Type d'énergie"
            clipMode="EllipsisWithTooltip"
            width="auto"
          />
          <ColumnDirective
            field="statusWording"
            headerText="Etat"
            clipMode="EllipsisWithTooltip"
            template={statusTemplate}
            width="110px"
          />
        </ColumnsDirective>
        <Inject
          services={[
            Page,
            Filter,
            Sort,
            PdfExport,
            ExcelExport,
            Resize,
            Selection,
            Edit,
          ]}
        />
      </GridComponent>

    </div>
  )
}

export default VehicleDataGridTabs