import { useState } from "react";
import InputWithIcon from "src/app/components/form/Input";
import { v4 as uuidv4 } from "uuid";

type Props = {
  label?: string;
  name?: string;
  id?: string;
  accept?: string;
  updateImages?: (id: string, data?: string, add?: boolean) => void;
  data?: DocumentVehicle[];
  className?: string;
};
type DocumentVehicle = {
  id: string;
  document: string;
};

const VehicleDocuments = (props: Props) => {
  const [images, setImages] = useState<string[]>([]);
  const [documents, setDocuments] = useState<File[]>([]);

  const handleDocumentChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const filesArray = Array.from(e.target.files);
      const imageFiles = filesArray.filter((file) =>
        file.type.startsWith("image/")
      );
      const docFiles = filesArray.filter(
        (file) => !file.type.startsWith("image/")
      );

      const imagesArray = imageFiles.map((file) => URL.createObjectURL(file));
      setImages((prevImages) => prevImages.concat(imagesArray));
      setDocuments((prevDocs) => prevDocs.concat(docFiles));

      // filesArray.map((fileData) => (props?.updateImages(fileData, uuidv4())));
    }
  };

  const handleRemoveImage = (index: number) => {
    const newImages = [...images];
    newImages.splice(index, 1);
    setImages(newImages);
  };

  return (
    <div
      className={`flex flex-col justify-between items-center gap-4 w-full my-4 px-4 form ${props?.className}`}
    >
      <div className="flex flex-col gap-3 imageUrls w-full">
        <label htmlFor={props?.id} className="text-base">
          {props?.label}
        </label>
        <InputWithIcon
          type="file"
          name={props?.name}
          placeholder={props?.label}
          id={props?.id}
          accept={props?.accept}
          multiple
          capture="environment"
          onChange={handleDocumentChange}
          className={`w-full`}
        />
      </div>

      <div className="gallery border border-gray-300 min-h-[calc(100vh-325px)] w-full p-2">
        <div className="grid grid-cols-4 gap-3 justify-between">
          {images?.map((image, index) => (
            <div className="relative border rounded-md p-2" key={index}>
              <img
                src={image}
                alt={props?.label}
                className="w-full h-32 object-cover"
              />
              <span
                className="close-button cursor-pointer flex items-center justify-center rounded-full w-6 h-6 bg-red-500 absolute top-2 right-2"
                onClick={() => handleRemoveImage(index)}
              >
                &times;
              </span>
            </div>
          ))}

          {/* {props?.data?.map((image, index) => (
          <div className="" key={index}>
            <img
              src={image.document}
              alt={props?.label}
              className="w-full h-32 object-cover"
            />
            <button
              className="close-button"
              onClick={() => props?.updateImages(image.id, "", false)}
            >
              &#10006;
            </button>
          </div>
        ))} */}

        </div>

        {documents.length > 0 && (
          <div className="flex flex-col mt-2">
            <h2 className="font-bold text-lg">Vos documents sélectionnés</h2>
            <div className="gallery grid grid-cols-3 gap-3 justify-between">
              {documents?.map((doc, index) => (
                <div
                  className="border rounded-md p-2 w-full h-36 bg-slate-400 relative"
                  key={index}
                >
                  <a
                    href={URL.createObjectURL(doc)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-white font-normal absolute bottom-0 left-1/2 -translate-x-1/2 select-none overflow-hidden text-ellipsis"
                  >
                    {doc.name.split(".").at(0)}
                  </a>
                  <span className="text-5xl text-black font-black -rotate-45 absolute top-1/4 left-1/4 translate-x-1/4 translate-y-1/4 opacity-10 select-none">
                    {doc.name.split(".").at(-1)}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default VehicleDocuments;
