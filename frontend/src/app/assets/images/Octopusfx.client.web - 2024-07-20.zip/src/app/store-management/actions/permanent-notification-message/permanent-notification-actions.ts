import { DataStateChangeEventArgs } from "@syncfusion/ej2-react-grids";
import { CountPermanentNotificationAction, PermanentNotificationAction, PermanentNotificationFailurePayload, UpdatePermanentNotificationAction, UpdatePermanentNotificationFailurePayload } from ".";
import { ActionTypes } from "../constants/action-types";
import { Query } from "@syncfusion/ej2/data";

export const setNotificationItemStatus = (command: SetNotificationStatusCommand) => {
  return {
    type: ActionTypes.SET_NOTIFICATION_STATUS,
    payload: {
      id: command.id,
      checked: command.checked
    },
  };
};

export const countPermanentNotificationMessages = (): CountPermanentNotificationAction => {
  
  return {
      type: ActionTypes.COUNT_PERMANENT_NOTIFICATION,
      payload: {
          user: null,
          errors: null
      }
  } as CountPermanentNotificationAction
};
export const countPermanentNotificationMessagesSuccess = (command: CountPermanentNotification): CountPermanentNotificationAction => {
  
  return {
      type: ActionTypes.COUNT_PERMANENT_NOTIFICATION_SUCCESS,
      payload: {
          user: command,
          errors: null
      }
  } as CountPermanentNotificationAction
};

export const permanentNotificationMessages = (): PermanentNotificationAction => {
  
  return {
      type: ActionTypes.GET_NOTIFICATIONS_REQUEST,
      payload: {
          user: null,
          errors: null
      }
  } as PermanentNotificationAction
};
export const permanentNotificationMessagesFailure = (command: PermanentNotificationFailurePayload): PermanentNotificationAction => {
  
  return {
      type: ActionTypes.GET_NOTIFICATIONS_FAILURE,
      payload: {
          user: null,
          errors: command
      }
  } as PermanentNotificationAction
};
export const permanentNotificationMessagesSuccess = (command: PermanentNotificationUser): PermanentNotificationAction => {
  
  return {
      type: ActionTypes.GET_NOTIFICATIONS_SUCCESS,
      payload: {
          user: command,
          errors: null
      }
  } as PermanentNotificationAction
};

export const markAsReadPermanentNotificationMessages = (command: UpdatePermanentNotificationCommand): UpdatePermanentNotificationAction => {
  
  return {
      type: ActionTypes.MARK_READ_NOTIFICATIONS_REQUEST,
      payload: {
        command: command,
          value: null,
          errors: null
      }
  } as UpdatePermanentNotificationAction
};
export const deletePermanentNotificationMessages = (command: UpdatePermanentNotificationCommand): UpdatePermanentNotificationAction => {
  
  return {
      type: ActionTypes.DELETE_NOTIFICATIONS_REQUEST,
      payload: {
        command: command,
          value: null,
          errors: null
      }
  } as UpdatePermanentNotificationAction
};
export const UpdatePermanentNotificationMessagesSuccess = (command: UpdatePermanentNotificationSuccessPayload): UpdatePermanentNotificationAction => {
  
  return {
      type: ActionTypes.MARK_READ_NOTIFICATIONS_SUCCESS || ActionTypes.DELETE_NOTIFICATIONS_SUCCESS,
      payload: {
        command: null,
          value: command,
          errors: null
      }
  } as UpdatePermanentNotificationAction
};
export const UpdatePermanentNotificationMessagesFailure = (command: UpdatePermanentNotificationFailurePayload): UpdatePermanentNotificationAction => {
  
  return {
      type: ActionTypes.MARK_READ_NOTIFICATIONS_FAILURE || ActionTypes.DELETE_NOTIFICATIONS_FAILURE,
      payload: {
        command: null,
          value: null,
          errors: command
      }
  } as UpdatePermanentNotificationAction
};


export const FilterPermanentNotificationMessages = (state: DataStateChangeEventArgs, query: Query) => {
  
  return {
      type: ActionTypes.GRID_NOTIFICATIONS_FILTER,
      payload: state,
      gridQuery: query
  }
};

export const SortPermanentNotificationMessages = (state: DataStateChangeEventArgs, query: Query) => {
  
  return {
      type: ActionTypes.GRID_NOTIFICATIONS_SORTING,
      payload: state,
      gridQuery: query
  }
};

export const PagePermanentNotificationMessages = (state: DataStateChangeEventArgs, query: Query) => {
  
  return {
      type: ActionTypes.GRID_NOTIFICATIONS_PAGER,
      payload: state,
      gridQuery: query
  }
};