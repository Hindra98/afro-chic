export { log } from './log';
