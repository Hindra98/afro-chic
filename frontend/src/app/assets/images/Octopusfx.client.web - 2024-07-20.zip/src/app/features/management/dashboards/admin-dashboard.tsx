import Breadcrumb from "src/app/components/shared/breadcrumb";
import { useLocalizer } from "src/app/core/Localization";
import "src/app/styles/components/_dashboard.scss";
import welcome from "src/app/assets/image-octopusfx/dashbg.png";
import { NavLink } from "react-router-dom";
import DashboardCard from "./dashboard-card";
import { ColorConstants } from "src/app/core/constants/common-constants";
import Performances from "./performances";

const AdminDashboard = () => {
  const commonLocalizer = useLocalizer("Common-ResCommon");

  const handleDetail = (link: string) => {
    window.location.href = link;
  };

  window.document.title = commonLocalizer("MODULE_COMMON_SIDEBAR_DASHBOARD");
  return (
    <div className="h-full flex flex-col justify-start mx-auto dashboard">
      <div
        className={` text-3xl align-top flex flex-col justify-start ps-10 pt-4 flex-wrap my-5 gap-0 `}
      >
        <h1 className="">
          {commonLocalizer("MODULE_COMMON_SIDEBAR_DASHBOARD")}
        </h1>
        <Breadcrumb items={[{ title: "Home ", link: "module" }]} />
      </div>
      <div className="px-10 pb-8">
        <div className="welcome flex md:flex-row xs:flex-col xs:mx-auto justify-between gap-4">
          <div className="welcome-image md:w-2/5 xs:w-full relative">
            <img src={welcome} alt="Welcome" className="xs:w-3/5 mx-auto " />{" "}
            <div className="FadeAway"></div>
          </div>
          <div className="welcome-text md:w-1/2 xs:w-full flex flex-col me-auto gap-4 justify-between">
            <h1>Bienvenue chez OctopusFX</h1>
            <div className="navbar flex flex-row gap-4">
              <NavLink
                to={"/propos"}
                className={({ isActive }) =>
                  isActive ? "border-b-blue-800 pb-2 font-bold" : ""
                }
              >
                A propos de nous
              </NavLink>
              <NavLink
                to={"/contact"}
                className={({ isActive }) =>
                  isActive ? "border-b-blue-800 pb-2 font-bold" : ""
                }
              >
                Contact
              </NavLink>
            </div>
            <p className="message">
              Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias
              odit enim quasi, illo inventore minus aspernatur molestiae? Rem
              explicabo obcaecati possimus culpa? Harum quam iusto dignissimos
              culpa aliquam dolor sapiente! molestiae? Rem explicabo obcaecati
              possimus culpa? Harum quam iusto dignissimos culpa aliquam dolor
              sapiente! Lorem ipsum dolor sit amet consectetur adipisicing elit.
              Alias odit enim quasi, illo inventore minus aspernatur molestiae?
              Rem explicabo obcaecati possimus culpa? Harum quam iusto
              dignissimos culpa aliquam dolor sapiente!
            </p>
            <footer className="flex flex-row gap-4 ms-auto">
              <span className="cursor-pointer text-blue-800">
                <i className="icon mapicon-"></i>Visite guidée
              </span>
              <span className="cursor-pointer text-blue-800">
                <i className="icon flash-2icon-"></i>Nouvelles
              </span>
              <span className="cursor-pointer text-blue-800">
                <i className="icon usersicon-"></i>Communauté
              </span>
            </footer>
          </div>
        </div>

        <hr className="my-4 bg-gray-400 h-[1px]" />
        <div className="flex flex-row flex-wrap justify-start gap-5 py-5">
          <DashboardCard
            header={{
              title: " Locataires",
              options: [
                { label: "Ouvrir un navigateur" },
                { label: "Fermer un onglet" },
              ],
            }}
            hasTitle={true}
            title="Vos données d'optimisation"
            activeIndicator={{
              label: "Actifs",
              value: 120,
              color: ColorConstants.GREEN,
            }}
            inactiveIndicator={{
              label: "inactifs",
              value: 32,
              color: ColorConstants.ORANGE,
            }}
            deleteIndicator={{
              label: "Supprimés",
              value: 15,
              color: ColorConstants.RED,
            }}
            buttons={[
              {
                type: "button",
                name: "Details",
                handleClick: () => handleDetail("/tenants"),
              },
            ]}
          >
            
            
            <Performances
              title="Abonnement actuel"
              performances={[
                {
                  label: "Authentification à deux facteurs",
                  value: "Activé",
                },
                {
                  label: "Langues",
                  value: "Français",
                },
                {
                  label: "Region",
                  value: "Cameroun",
                },
                {
                  label: "Fuseau horaire",
                  value: "Afrique centrale",
                },
              ]}
            />
          </DashboardCard>

          <DashboardCard
            header={{
              title: "Agences",
              options: [
                { label: "Ouvrir un navigateur" },
                { label: "Fermer un onglet" },
              ],
            }}
            hasTitle={true}
            title="Toutes vos agences"
            activeIndicator={{
              label: "Opérationnelles",
              value: 21,
              color: ColorConstants.BLUE,
            }}
          >
            
            <Performances
              title="Répartition géographique"
              performances={[
                {
                  label: "Nombre de villes installées",
                  value: "07",
                },
                {
                  label: "Nombres de régions",
                  value: "04",
                },
              ]}
            />
          </DashboardCard>

          <DashboardCard
            header={{
              title: "Utilisateurs",
              options: [
                { label: "Ouvrir un navigateur" },
                { label: "Fermer un onglet" },
              ],
            }}
            hasTitle={true}
            title="Etat des utilisateurs"
            activeIndicator={{
              label: "Actifs",
              value: 120,
              color: ColorConstants.GREEN,
            }}
            inactiveIndicator={{
              label: "inactifs",
              value: 32,
              color: ColorConstants.ORANGE,
            }}
          >
            
            <Performances
              title="Activité récente"
              performances={[
                {
                  label: "Nombre d'utilisateurs crées",
                  value: "26",
                },
                {
                  label: "Désactivé récemment",
                  value: "01",
                },
              ]}
            />
          </DashboardCard>

          <DashboardCard
            header={{
              title: "Notifications",
              options: [
                { label: "Ouvrir un navigateur" },
                { label: "Fermer un onglet" },
              ],
            }}
            hasTitle={true}
            title="Vos notifications"
            activeIndicator={{
              label: "Toutes",
              value: 187,
              color: ColorConstants.GREEN,
            }}
            inactiveIndicator={{
              label: "Lues",
              value: 132,
              color: ColorConstants.ORANGE,
            }}
            deleteIndicator={{
              label: "Non lues",
              value: 55,
              color: ColorConstants.BLUE_SEA,
            }}
            hr={false}
          >
            
            <Performances
              title="Types"
              performances={[
                {
                  label: "Importants",
                  value: "115",
                  color: 'text-red-500'
                },
                {
                  label: "Standards",
                  value: "65",
                },
              ]}
            />

          </DashboardCard>

          <DashboardCard
            header={{
              title: "Etat de santé",
              options: [
                { label: "Ouvrir un navigateur" },
                { label: "Fermer un onglet" },
              ],
            }}
            hasTitle={true}
            title="Vérifiez vos performances"
            deleteIndicator={{
              label: "Nombre de base de données",
              value: 3,
              color: ColorConstants.BLUE_SEA,
            }}
            hr={false}
          >
            <Performances
              title="Activité sur la base de données"
              performances={[
                {
                  label: "Système d'exploitation",
                  value: "Sain",
                },
                {
                  label: "Services d'arrière plan",
                  value: "Dégradé",
                  color: "text-orange-600",
                },
                {
                  label: "Serveur de base de données",
                  value: "Sain",
                },
              ]}
            />
          </DashboardCard>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
