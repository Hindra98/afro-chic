import { call, put, takeLatest } from "redux-saga/effects";
import { ActionTypes } from "../actions/constants/action-types";
import { ControllerApi } from "src/app/features/management/app-settings/locale/controller-api";
import { GetAppSettingsAction, GetAppSettingsFailurePayload, UpdateAppSettingsAction, UpdateAppSettingsFailurePayload, UpdateAppSettingsSuccessPayload } from "../actions/app-settings";
import { getAppSettingsFailure, getAppSettingsSuccess, updateAppSettingsFailure, updateAppSettingsSuccess } from "../actions/app-settings/app-settings-actions";
import { setStorage } from "src/app/core/storage/storage";

const controllerApi = new ControllerApi();

const callApiToUpdateAppSettings = async (command: UpdateAppSettingsCommand) => controllerApi.updateAppSettings(command);
const callApiToGetAppSettings = async () => controllerApi.getAppSettings();

function* updateAppSettingsSaga(action: UpdateAppSettingsAction) {
  try {
    const response = yield call(callApiToUpdateAppSettings, action.payload.command);
    if (response) {
      if (response?.hasSucceeded) {
        setStorage("pin_length", action.payload.command.multiFactorAuthenticationSettings.pinLength.toString());
        yield put(updateAppSettingsSuccess({ value: true } as UpdateAppSettingsSuccessPayload));
      } else {
        let messages: string[] = [];
        response?.errorMessages.map((item) => {
          return messages.push(item.errorMessage);
        });
        yield put(updateAppSettingsFailure({ errors: messages } as UpdateAppSettingsFailurePayload));
      }
    } else {
      let messages: string[] = [];
      messages.push("Erreur lors de la connexion au serveur");
      yield put(updateAppSettingsFailure({ errors: messages } as UpdateAppSettingsFailurePayload));
    }
  } catch (e) {
    let messages: string[] = [];
    messages.push(e?.message);
    yield put(updateAppSettingsFailure({ errors: messages } as UpdateAppSettingsFailurePayload));
  }
}


function* getAppSettingsSaga(action: GetAppSettingsAction) {
  try {
    const response = yield call(callApiToGetAppSettings);
    if (response) {
      yield put(getAppSettingsSuccess(response as GetAppSettings));
    } else {
      let messages: string[] = [];
      response?.errorMessages.map((item) => {
        return messages.push(item.errorMessage);
      });
      yield put(getAppSettingsFailure({ errors: messages } as GetAppSettingsFailurePayload));
    }

  } catch (e) {
    let messages: string[] = [];
    messages.push(e.message);
    yield put(getAppSettingsFailure({ errors: messages } as GetAppSettingsFailurePayload));
  }
}

export function* watchAppSettingsSaga() {
  yield takeLatest(ActionTypes.UPDATE_APP_SETTINGS_REQUEST, updateAppSettingsSaga);
  yield takeLatest(ActionTypes.GET_APP_SETTINGS_REQUEST, getAppSettingsSaga);
}
