import { call, put, takeLatest } from "redux-saga/effects";
import { ActionTypes } from "../actions/constants/action-types";
import { ControllerApi } from "src/app/features/management/tenants/locale/controller-api";
import { addTenantFailure, addTenantSuccess, deleteTenantFailure, deleteTenantSuccess, exportPdfTenantsFailure, exportPdfTenantsSuccess, getTenantFailure, getTenantsFailure, getTenantsSuccess, getTenantSuccess, updateTenantFailure, updateTenantSuccess } from "../actions/tenants/tenants-actions";
import { AddTenantAction, AddTenantFailurePayload, AddTenantSuccessPayload, DeleteTenantAction, DeleteTenantFailurePayload, DeleteTenantSuccessPayload, ExportPdfTenantsAction, ExportPdfTenantsFailurePayload, GetTenantsFailurePayload, TenantAction, TenantFailurePayload, UpdateTenantAction, UpdateTenantFailurePayload, UpdateTenantSuccessPayload } from "../actions/tenants";


const controllerApi = new ControllerApi();

const callApiToAddTenant = async (command: FormData) => controllerApi.addTenant(command);
const callApiToUpdateTenants = async (command: FormData) => controllerApi.updateTenant(command);
const callApiToDeleteTenant = async (command: DeleteTenantCommand) => controllerApi.deleteTenant(command);
const callApiToGetTenants = async () => controllerApi.getTenants();
const callApiToGetTenant = async (command: TenantCommand) => controllerApi.getTenant(command);

const callApiToExportPdfTenant = async (command: FormData) => controllerApi.exportTenantDataInPdfFile(command);

function* addTenantSaga(action: AddTenantAction) {
  try {
    const response = yield call(callApiToAddTenant, action.payload.command);
    if (response) {
      if (response?.hasSucceeded) {
        yield put(addTenantSuccess({ value: true } as AddTenantSuccessPayload));

        const responseGetTenant = yield call(callApiToGetTenants);
        if (responseGetTenant) {
          yield put(getTenantsSuccess(responseGetTenant as GetTenants));
        } else {
          let messages: string[] = [];
          responseGetTenant?.errorMessages.map((item) => {
            return messages.push(item.errorMessage);
          });
          yield put(getTenantsFailure({ errors: messages } as GetTenantsFailurePayload, null));
        }

      } else {
        let messages: string[] = [];
        response.errorMessages.map((item) => {
          return messages.push(item.errorMessage);
        });
        yield put(addTenantFailure({ errors: messages } as AddTenantFailurePayload));
      }
    } else {
      let messages: string[] = [];
      messages.push("Erreur lors de la connexion au serveur");
      yield put(addTenantFailure({ errors: messages } as AddTenantFailurePayload));
    }
  } catch (e) {
    let messages: string[] = [];
    messages.push(e.message);
    yield put(addTenantFailure({ errors: messages } as AddTenantFailurePayload));
  }
}

function* updateTenantsSaga(action: UpdateTenantAction) {
  try {
    const response = yield call(callApiToUpdateTenants, action.payload.command);
    if (response) {
      if (response?.hasSucceeded) {
        yield put(updateTenantSuccess({ value: true } as UpdateTenantSuccessPayload));

        const responseGetTenant = yield call(callApiToGetTenants);
        if (responseGetTenant) {
          yield put(getTenantsSuccess(responseGetTenant as GetTenants));
        } else {
          let messages: string[] = [];
          responseGetTenant?.errorMessages.map((item) => {
            return messages.push(item.errorMessage);
          });
          yield put(getTenantsFailure({ errors: messages } as GetTenantsFailurePayload, null));
        }
      } else {
        let messages: string[] = [];
        response.errorMessages.map((item) => {
          return messages.push(item.errorMessage);
        });
        yield put(updateTenantFailure({ errors: messages } as UpdateTenantFailurePayload));
      }
    } else {
      let messages: string[] = [];
      messages.push("Erreur lors de la connexion au serveur");
      yield put(updateTenantFailure({ errors: messages } as UpdateTenantFailurePayload));
    }
  } catch (e) {
    let messages: string[] = [];
    messages.push(e.message);
    yield put(updateTenantFailure({ errors: messages } as UpdateTenantFailurePayload));
  }
}

function* deleteTenantSaga(action: DeleteTenantAction) {
  try {
    const response = yield call(callApiToDeleteTenant, action.payload.command);
    if (response) {
      if (response?.hasSucceeded) {
        yield put(deleteTenantSuccess({ value: true } as DeleteTenantSuccessPayload));

        const responseGetTenant = yield call(callApiToGetTenants);
        if (responseGetTenant) {
          yield put(getTenantsSuccess(responseGetTenant as GetTenants));
        } else {
          let messages: string[] = [];
          responseGetTenant?.errorMessages.map((item) => {
            return messages.push(item.errorMessage);
          });
          yield put(getTenantsFailure({ errors: messages } as GetTenantsFailurePayload, null));
        }
      } else {
        let messages: string[] = [];
        response.errorMessages.map((item) => {
          return messages.push(item.errorMessage);
        });
        yield put(deleteTenantFailure({ errors: messages } as DeleteTenantFailurePayload));
      }
    } else {
      let messages: string[] = [];
      messages.push("Erreur lors de la connexion au serveur");
      yield put(deleteTenantFailure({ errors: messages } as DeleteTenantFailurePayload));
    }
  } catch (e) {
    let messages: string[] = [];
    messages.push(e.message);
    yield put(deleteTenantFailure({ errors: messages } as DeleteTenantFailurePayload));
  }
}

function* getTenantsSaga() {
  try {
    const response = yield call(callApiToGetTenants);
    if (response) {
      yield put(getTenantsSuccess(response as GetTenants));
    } else {
      let messages: string[] = [];
      response?.errorMessages.map((item) => {
        return messages.push(item.errorMessage);
      });
      yield put(getTenantsFailure({ errors: messages } as GetTenantsFailurePayload, null));
    }

  } catch (e) {
    let messages: string[] = [];
    messages.push(e.message);
    yield put(getTenantsFailure({ errors: messages } as GetTenantsFailurePayload, e?.response));
  }
}

function* getTenantSaga(action: TenantAction) {
  try {
    const response = yield call(callApiToGetTenant, action.payload.command);
    if (response) {
      yield put(getTenantSuccess(response as GetTenant));
    } else {
      let messages: string[] = [];
      response?.errorMessages.map((item) => {
        return messages.push(item.errorMessage);
      });
      yield put(getTenantFailure({ errors: messages } as TenantFailurePayload, null));
    }

  } catch (e) {
    let messages: string[] = [];
    messages.push(e.message);
    yield put(getTenantFailure({ errors: messages } as TenantFailurePayload, e?.response));
  }
}


function* exportPdfTenantSaga(action: ExportPdfTenantsAction) {
  try {
    const response = yield call(callApiToExportPdfTenant, action.payload.command);
    if (response) {
        yield put(exportPdfTenantsSuccess({ value: true }));
    } else {
      let messages: string[] = [];
      messages.push("Erreur lors de la connexion au serveur");
      yield put(exportPdfTenantsFailure({ errors: messages } as ExportPdfTenantsFailurePayload));
    }
  } catch (e) {
    let messages: string[] = [];
    messages.push(e.message);
    yield put(exportPdfTenantsFailure({ errors: messages } as ExportPdfTenantsFailurePayload));
  }
}


export function* watchTenantsSaga() {
  yield takeLatest(ActionTypes.ADD_TENANT_REQUEST, addTenantSaga);
  yield takeLatest(ActionTypes.DELETE_TENANTS_REQUEST, deleteTenantSaga);
  yield takeLatest(ActionTypes.UPDATE_TENANT_REQUEST, updateTenantsSaga);
  yield takeLatest(ActionTypes.GET_TENANTS_REQUEST, getTenantsSaga);
  yield takeLatest(ActionTypes.GET_TENANT_REQUEST, getTenantSaga);
  yield takeLatest(ActionTypes.EXPORT_PDF_TENANTS_REQUEST, exportPdfTenantSaga);
}
