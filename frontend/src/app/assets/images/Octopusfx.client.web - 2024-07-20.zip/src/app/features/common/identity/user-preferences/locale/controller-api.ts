import { useDebounced } from "src/app/core/hooks";
import { HttpClient } from "../../../../../http/http-client";

const updateUserPreferences = (http: HttpClient) => async (payload: object) => {
  const response = await http.post("/v1/userpreferences/save", payload);
  const result: UpdateUserPreferencesResult = response.data;
  
  return response !== undefined ? (result as UpdateUserPreferencesResult) : undefined;
};

const getUserPreferences = (http: HttpClient) => async (payload: string) => {
  const response = await http.get("/v1/userpreferences/get");
  const result: GetUserPreferences = response.data;

  return response !== undefined ? (result as GetUserPreferences) : undefined;
};

export class ControllerApi {
  private readonly http = new HttpClient();
  public readonly updateUserPreferences = Object.assign(updateUserPreferences(this.http), {
    useResponse: (
      handler: (result: UpdateUserPreferencesResult) => unknown,
      args: Parameters<ReturnType<typeof updateUserPreferences>>[0]
    ) => useDebounced(() => this.updateUserPreferences(args).then(handler), Object.values(args), 500),
  });
  
  public readonly getUserPreferences = Object.assign(getUserPreferences(this.http), {
    useResponse: (
      handler: (result: GetUserPreferences) => unknown,
      args: Parameters<ReturnType<typeof getUserPreferences>>[0]
    ) => useDebounced(() => this.getUserPreferences(args).then(handler), Object.values(args), 500),
  });

}