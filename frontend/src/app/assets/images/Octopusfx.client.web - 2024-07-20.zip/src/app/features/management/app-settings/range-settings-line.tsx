import { SliderComponent } from "@syncfusion/ej2-react-inputs";

type Props = {
  title?: string;
  name?: string;
  description?: string;
  value?: number;
  min?: number;
  max?: number;
  css?: string;
  isRange?: boolean;
  disabled?: boolean;
  change?;
};

const RangeSettingsLine = (props: Props) => {
  let defaultTicks: object = {
    placement: "Before",
    largeStep: 2,
  };
  const tooltip: object = {
    placement: "Before",
    isVisible: true,
    showOn: "Focus",
  };
  return (
    <div
      className={`${props?.name} flex flex-row justify-between items-center gap-5 w-full range-settings ${props?.css}`}
    >
      <label htmlFor={props?.name} className={`flex flex-col gap-1 w-1/3 ${props.disabled? "label-disabled":""} `}>
        <h2 className="font-bold">{props?.title}</h2>
        <p className="font-normal text-sm text-gray-500 user-help">
          {props?.description}
        </p>
      </label>
      <div className="w-3/4">
        {props?.isRange ? (
          <SliderComponent
            id={props?.name}
            value={props?.value}
            min={props?.min}
            step={1}
            ticks={defaultTicks}
            name={props?.name}
            change={props?.change}
            readOnly={props?.disabled}
            disabled={props?.disabled}
            cssClass={`slider-component ${props.disabled? "label-disabled":""}`}
            showButtons={true}
            tooltip={tooltip}
          />
        ) : (
          <div className={`text-md flex flex-row gap-0 items-center border px-2 py-1 input-dashboard w-full mx-auto`}>
            <input
              type={"number"}
              id={props?.name}
              name={props?.name}
              min={props?.min}
              placeholder={props?.title}
              className={`login-input w-full outline-none border-none bg-transparent ${props.disabled? "label-disabled":""}`}
              value={props?.value}
              disabled={props?.disabled}
              onChange={props?.change}
              autoComplete="off"
            />
          </div>
        )}
      </div>
    </div>
  );
};

export default RangeSettingsLine;
