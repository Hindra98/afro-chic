import React, { Dispatch, SetStateAction } from 'react'
import InputWithIcon from 'src/app/components/form/Input'
import RangeSettingsLine from '../range-settings-line'
import SwitchSettingsLine from '../switch-settings-line'
import CardSettings from '../card-settings'
import { useAppSelector } from 'src/app/core/hooks/core-hooks'
import { ShimmerText } from 'src/app/components/shared/shimmer'
import { useLocalizer } from 'src/app/core/Localization'

type Props = {
  viewModel?: {
    cookieConsentTimeFrame: number;
    domainCookiesSettings: string;
    httpOnlyCookiesSettings: boolean;
  }
  setViewModel?: Dispatch<SetStateAction<{
    cookieConsentTimeFrame: number;
    domainCookiesSettings: string;
    httpOnlyCookiesSettings: boolean;
  }>>
  errorsAppSettings?
}

const CookiesSettings = ({ errorsAppSettings = null, setViewModel, viewModel }: Props) => {
  const commonLocalizer = useLocalizer("Common-ResCommon");

  const getAppSettingsData = useAppSelector((state) => state.getAppSettings);

  const handleChangeSwitch = (e, text: string) => {
    const value = e.checked;
    setViewModel({
      ...viewModel,
      [text]: value,
    });
  }
  const handleChangeInput = (e) => {
    const { name, value } = e.target;
    setViewModel({
      ...viewModel,
      [name]: value,
    });
  }
  const handleChangeRange = (e, text: string): void => { // With number input option
    const { name, value } = e.target;
    setViewModel({
      ...viewModel,
      [name]: value,
    });
  }


  return (
    <>
      {getAppSettingsData.pending ? (<div className="p-0 m-0 w-full mx-auto"><ShimmerText /><ShimmerText /><ShimmerText /></div>) : (
        <CardSettings title={commonLocalizer("MODULE_COMMON_WEB_SETTINGS_SUBGROUP_COOKIES_TITLE")}>

          <SwitchSettingsLine change={(e) => handleChangeSwitch(e, "httpOnlyCookiesSettings")} title={commonLocalizer("MODULE_COMMON_WEB_SETTINGS_SUBGROUP_COOKIES_HTTP_ONLY")} name="httpOnlyCookiesSettings" description={commonLocalizer("MODULE_COMMON_WEB_SETTINGS_SUBGROUP_COOKIES_HTTP_ONLY_HELP")} checked={viewModel.httpOnlyCookiesSettings} />

          <RangeSettingsLine disabled={!viewModel.httpOnlyCookiesSettings} value={viewModel.cookieConsentTimeFrame} min={1} max={9} change={(e) => handleChangeRange(e, "cookieConsentTimeFrame")} css="mt-4" title={commonLocalizer("MODULE_COMMON_WEB_SETTINGS_SUBGROUP_COOKIES_DELAI")} name="cookieConsentTimeFrame" />

          <div className="domainCookiesSettings flex flex-col gap-2 justify-between w-full p-0 m-0">
            <div className="flex flex-row gap-5 justify-between items-center w-full p-0 m-0">
              <label htmlFor="domainCookiesSettings" className={`w-1/3 ${!viewModel.httpOnlyCookiesSettings ? "label-disabled" : ""}`}>{commonLocalizer("MODULE_COMMON_WEB_SETTINGS_SUBGROUP_COOKIES_DOMAIN_LABEL")}</label>
              <div className="w-3/4">
                <InputWithIcon
                  type="text"
                  id='domainCookiesSettings'
                  name='domainCookiesSettings'
                  icon={``}
                  placeholder={commonLocalizer("MODULE_COMMON_WEB_SETTINGS_SUBGROUP_COOKIES_DOMAIN_PLACEHOLDER")}
                  className={`"w-full mx-auto ${!viewModel.httpOnlyCookiesSettings ? "label-disabled" : ""}`}
                  value={viewModel.domainCookiesSettings}
                  onChange={handleChangeInput}
                  disabled={!viewModel.httpOnlyCookiesSettings}
                  eye={false}
                />
              </div>
            </div>
            {errorsAppSettings?.domainCookiesSettings &&
              (<div className="error">{errorsAppSettings?.domainCookiesSettings.toString()}</div>)}
          </div>

        </CardSettings>
      )}
    </>
  )
}

export default CookiesSettings