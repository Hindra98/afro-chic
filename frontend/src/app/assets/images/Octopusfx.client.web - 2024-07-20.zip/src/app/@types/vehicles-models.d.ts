
interface GetVehicles {
  hasAlreadyCalled?: boolean;
  isAdministrator: boolean;
  vehicles: Vehicle[];
  brands: Brand[];
}

interface GetVehicle {
  isAdministrator: boolean;
  vehicle: Vehicle;
  brands: Brand[];
  gearBoxes: GearBoxes[];
  vehicleTypes: VehicleTypes[];
  models: Model[];
  energyTypes: EnergyTypes[];
  availabilityStatus: AvailabilityStatus[]

}

interface Vehicle {
  id: string;
  vin: string;
  engineNumber: string;
  registrationNumber: string;
  gearNumber: string;
  name: string;
  gearBoxType: string;
  gearBoxTypeWording: string;
  commissionStartingDate: string;
  commissionStartingDateWording: string;
  commissionEndDate: string;
  commissionEndDateWording: string;
  modelYear: number;
  cO2Emissions: number;
  description: string;
  modelId: string;
  model: string;
  brandId: string;
  brand: string;
  status: string;
  statusWording: string;
  energyType: string;
  energyTypeWording: string;
  vehicleType: string;
  vehicleTypeWording: string;
  imageUrls: string[];
  documentUrls: string[];

}

interface VehicleTypes {
  id: number;
  displayName: string;
  nativeName: string;
}

interface GearBoxes {
  id: number;
  displayName: string;
  nativeName: string;
}

interface EnergyTypes {
  id: number;
  displayName: string;
  nativeName: string;
}

interface AvailabilityStatus {
  id: number;
  displayName: string;
  nativeName: string;
}

interface VehicleCommand {
  SearchCriteria: string;
}
interface UpdateVehicleCommand {
  key: string;
  vin: string;
  engineNumber: string;
  gearNumber: string;
  name: string;
  gearBoxType: string;
  commissionStartingDate: string;
  commissionEndDate: string;
  modelYear: number;
  cO2Emissions: number;
  description: string;
  modelId: string;
  status: string;
  energyType: string;
  vehicleType: string;
  imageUrls: string[];
  documentUrls: string[];

}
interface UpdateVehicleResult {
  hasSucceeded: boolean;
  errorMessages: ErrorMessageItem[];
}
interface DeleteVehicleCommand {
  key: string;
}
interface DeleteVehicleResult {
  hasSucceeded: boolean;
  errorMessages: ErrorMessageItem[];
}