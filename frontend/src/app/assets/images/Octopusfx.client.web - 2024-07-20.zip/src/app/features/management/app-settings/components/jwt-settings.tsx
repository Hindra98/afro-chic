import React, { Dispatch, SetStateAction } from "react";
import InputWithIcon from "src/app/components/form/Input";
import RangeSettingsLine from "../range-settings-line";
import SwitchSettingsLine from "../switch-settings-line";
import CardSettings from "../card-settings";
import { useAppSelector } from "src/app/core/hooks/core-hooks";
import { ShimmerText } from "src/app/components/shared/shimmer";
import { useLocalizer } from "src/app/core/Localization";

type Props = {
  viewModel?: {
    secret: string;
    issuer: string;
    audience: string;
    subject: string;
    expiration: number;
    refreshTokenTTL: number;
    validateIssuer: boolean;
    validateAudience: boolean;
    validateLifetime: boolean;
    validateIssuerSigningKey: boolean;
    resetTokenTTL: number;
    cookiesTTL: number;
  };
  setViewModel?: Dispatch<
    SetStateAction<{
      secret: string;
      issuer: string;
      audience: string;
      subject: string;
      expiration: number;
      refreshTokenTTL: number;
      validateIssuer: boolean;
      validateAudience: boolean;
      validateLifetime: boolean;
      validateIssuerSigningKey: boolean;
      resetTokenTTL: number;
      cookiesTTL: number;
    }>
  >;
  errorsAppSettings?;
};

const JwtSettings = ({
  errorsAppSettings = null,
  setViewModel,
  viewModel,
}: Props) => {
  const commonLocalizer = useLocalizer("Common-ResCommon");
  const getAppSettingsData = useAppSelector((state) => state.getAppSettings);

  const handleChangeSwitch = (e, text: string) => {
    const value = e.checked;
    setViewModel({
      ...viewModel,
      [text]: value,
    });
  };
  const handleChangeInput = (e) => {
    const { name, value } = e.target;
    setViewModel({
      ...viewModel,
      [name]: value,
    });
  };
  const handleChangeRange = (e, text: string): void => {
    const { name, value } = e.target;
    setViewModel({
      ...viewModel,
      [name]: value,
    });
  };

  return (
    <>
      {getAppSettingsData.pending ? (<div className="p-0 m-0 w-full mx-auto"><ShimmerText /><ShimmerText /><ShimmerText /></div>) : (
        <CardSettings title={commonLocalizer("MODULE_COMMON_WEB_SETTINGS_JWT_TITLE")}>
          <div className="flex flex-row justify-between gap-10 w-full">
            <div className="flex flex-col gap-5 items-start justify-start w-full">
              <SwitchSettingsLine
                change={(e) => handleChangeSwitch(e, "validateIssuer")}
                title={commonLocalizer(
                  "MODULE_COMMON_WEB_SETTINGS_JWT_VALIDATE_ISSUER"
                )}
                name="validateIssuer"
                description={commonLocalizer(
                  "MODULE_COMMON_WEB_SETTINGS_JWT_VALIDATE_ISSUER_HELP"
                )}
                checked={viewModel.validateIssuer}
              />

              <SwitchSettingsLine
                change={(e) => handleChangeSwitch(e, "validateAudience")}
                title={commonLocalizer(
                  "MODULE_COMMON_WEB_SETTINGS_JWT_VALIDATE_PUBLIC"
                )}
                name="validateAudience"
                description={commonLocalizer(
                  "MODULE_COMMON_WEB_SETTINGS_JWT_VALIDATE_PUBLIC_HELP"
                )}
                checked={viewModel.validateAudience}
              />

              <SwitchSettingsLine
                change={(e) => handleChangeSwitch(e, "validateLifetime")}
                title={commonLocalizer(
                  "MODULE_COMMON_WEB_SETTINGS_JWT_VALIDATE_LIFE_CYCLE"
                )}
                name="validateLifetime"
                description={commonLocalizer(
                  "MODULE_COMMON_WEB_SETTINGS_JWT_VALIDATE_LIFE_CYCLE_HELP"
                )}
                checked={viewModel.validateLifetime}
              />

              <SwitchSettingsLine
                change={(e) =>
                  handleChangeSwitch(e, "validateIssuerSigningKey")
                }
                title={commonLocalizer(
                  "MODULE_COMMON_WEB_SETTINGS_JWT_VALIDATE_SIGNATURE"
                )}
                name="validateIssuerSigningKey"
                description={commonLocalizer(
                  "MODULE_COMMON_WEB_SETTINGS_JWT_VALIDATE_SIGNATURE_HELP"
                )}
                checked={viewModel.validateIssuerSigningKey}
              />

              <RangeSettingsLine
                value={viewModel.expiration}
                min={1}
                max={9}
                change={(e) => handleChangeRange(e, "expiration")}
                css="mt-4"
                title={commonLocalizer(
                  "MODULE_COMMON_WEB_SETTINGS_JWT_ACCESS_TOKEN_EXPIRES"
                )}
                name="expiration"
              />

              <RangeSettingsLine
                value={viewModel.refreshTokenTTL}
                min={1}
                max={9}
                change={(e) => handleChangeRange(e, "refreshTokenTTL")}
                css=""
                title={commonLocalizer(
                  "MODULE_COMMON_WEB_SETTINGS_JWT_REFRESH_TOKEN_EXPIRES"
                )}
                name="refreshTokenTTL"
              />
            </div>

            <div className="flex flex-col gap-5 items-start justify-start w-full">
              <RangeSettingsLine
                value={viewModel.cookiesTTL}
                min={1}
                max={9}
                change={(e) => handleChangeRange(e, "cookiesTTL")}
                css="mt-4"
                title={commonLocalizer(
                  "MODULE_COMMON_WEB_SETTINGS_JWT_COOKIES_EXPIRES"
                )}
                name="cookiesTTL"
              />

              <RangeSettingsLine
                value={viewModel.resetTokenTTL}
                min={1}
                max={9}
                change={(e) => handleChangeRange(e, "resetTokenTTL")}
                css=""
                title={commonLocalizer(
                  "MODULE_COMMON_WEB_SETTINGS_JWT_RESET_TOKEN_EXPIRES"
                )}
                name="resetTokenTTL"
              />

              <div className="secret flex flex-col gap-2 justify-between w-full p-0 m-0">
                <div className="flex flex-row gap-5 justify-between items-center w-full p-0 m-0">
                  <label htmlFor="secret" className="w-1/3 flex flex-col gap-1">
                    {commonLocalizer("MODULE_COMMON_WEB_SETTINGS_JWT_SECRET")}
                    <p
                      className="font-normal text-sm user-help"
                      title={commonLocalizer(
                        "MODULE_COMMON_WEB_SETTINGS_JWT_SECRET_HELP"
                      )}
                    >
                      {commonLocalizer(
                        "MODULE_COMMON_WEB_SETTINGS_JWT_SECRET_HELP"
                      )}
                    </p>
                  </label>
                  <div className="w-3/4">
                    <InputWithIcon
                      type="text"
                      id="secret"
                      name="secret"
                      icon={``}
                      placeholder={commonLocalizer(
                        "MODULE_COMMON_WEB_SETTINGS_JWT_SECRET"
                      )}
                      className="w-full mx-auto"
                      value={viewModel.secret}
                      onChange={handleChangeInput}
                      eye={false}
                    />
                  </div>
                </div>
                {errorsAppSettings.secret && (
                  <div className="error">
                    {errorsAppSettings.secret.toString()}
                  </div>
                )}
              </div>

              <div className="issuer flex flex-col gap-2 justify-between w-full p-0 m-0">
                <div className="flex flex-row gap-5 justify-between items-center w-full p-0 m-0">
                  <label htmlFor="issuer" className="w-1/3 flex flex-col gap-1">
                    {commonLocalizer("MODULE_COMMON_WEB_SETTINGS_JWT_ISSUER")}
                    <p
                      className="font-normal text-sm user-help"
                      title={commonLocalizer(
                        "MODULE_COMMON_WEB_SETTINGS_JWT_ISSUER_HELP"
                      )}
                    >
                      {commonLocalizer(
                        "MODULE_COMMON_WEB_SETTINGS_JWT_ISSUER_HELP"
                      )}
                    </p>
                  </label>
                  <div className="w-3/4">
                    <InputWithIcon
                      type="text"
                      id="issuer"
                      name="issuer"
                      icon={``}
                      placeholder={commonLocalizer(
                        "MODULE_COMMON_WEB_SETTINGS_JWT_ISSUER"
                      )}
                      className="w-full mx-auto"
                      value={viewModel.issuer}
                      onChange={handleChangeInput}
                      eye={false}
                    />
                  </div>
                </div>
                {errorsAppSettings.issuer && (
                  <div className="error">
                    {errorsAppSettings.issuer.toString()}
                  </div>
                )}
              </div>

              <div className="audience flex flex-col gap-2 justify-between w-full p-0 m-0">
                <div className="flex flex-row gap-5 justify-between items-center w-full p-0 m-0">
                  <label htmlFor="audience" className="w-1/3">
                    {commonLocalizer("MODULE_COMMON_WEB_SETTINGS_JWT_PUBLIC")}
                    <p
                      className="font-normal text-sm user-help"
                      title={commonLocalizer(
                        "MODULE_COMMON_WEB_SETTINGS_JWT_PUBLIC_HELP"
                      )}
                    >
                      {commonLocalizer(
                        "MODULE_COMMON_WEB_SETTINGS_JWT_PUBLIC_HELP"
                      )}
                    </p>
                  </label>
                  <div className="w-3/4">
                    <InputWithIcon
                      type="text"
                      id="audience"
                      name="audience"
                      icon={``}
                      placeholder={commonLocalizer(
                        "MODULE_COMMON_WEB_SETTINGS_JWT_PUBLIC"
                      )}
                      className="w-full mx-auto"
                      value={viewModel.audience}
                      onChange={handleChangeInput}
                      eye={false}
                    />
                  </div>
                </div>
                {errorsAppSettings.audience && (
                  <div className="error">
                    {errorsAppSettings.audience.toString()}
                  </div>
                )}
              </div>

              <div className="subject flex flex-col gap-2 justify-between w-full p-0 m-0">
                <div className="flex flex-row gap-5 justify-between items-center w-full p-0 m-0">
                  <label htmlFor="subject" className="w-1/3">
                    {commonLocalizer("MODULE_COMMON_WEB_SETTINGS_JWT_SUJECT")}
                    <p
                      className="font-normal text-sm user-help"
                      title={commonLocalizer(
                        "MODULE_COMMON_WEB_SETTINGS_JWT_SUBJECT_HELP"
                      )}
                    >
                      {commonLocalizer(
                        "MODULE_COMMON_WEB_SETTINGS_JWT_SUBJECT_HELP"
                      )}
                    </p>
                  </label>
                  <div className="w-3/4">
                    <InputWithIcon
                      type="text"
                      id="subject"
                      name="subject"
                      icon={``}
                      placeholder={commonLocalizer(
                        "MODULE_COMMON_WEB_SETTINGS_JWT_SUJECT"
                      )}
                      className="w-full mx-auto"
                      value={viewModel.subject}
                      onChange={handleChangeInput}
                      eye={false}
                    />
                  </div>
                </div>
                {errorsAppSettings.subject && (
                  <div className="error">
                    {errorsAppSettings.subject.toString()}
                  </div>
                )}
              </div>
            </div>
          </div>
        </CardSettings>
      )}
    </>
  );
};

export default JwtSettings;
