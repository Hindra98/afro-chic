import { call, put, takeLatest } from "redux-saga/effects";
import { ActionTypes } from "../actions/constants/action-types";
import { ControllerApi } from "src/app/features/management/agencies/locale/controller-api";
import { AddAgencyAction, AddAgencyFailurePayload, AddAgencySuccessPayload, AgencyAction, AgencyFailurePayload, DeleteAgencyAction, DeleteAgencyFailurePayload, DeleteAgencySuccessPayload, GetAgenciesFailurePayload, UpdateAgencyAction, UpdateAgencyFailurePayload, UpdateAgencySuccessPayload } from "../actions/agencies";
import { addAgencyFailure, addAgencySuccess, deleteAgencyFailure, deleteAgencySuccess, getAgenciesFailure, getAgenciesSuccess, getAgencyFailure, getAgencySuccess, updateAgencyFailure, updateAgencySuccess } from "../actions/agencies/agencies-actions";


const controllerApi = new ControllerApi();

const callApiToAddAgency = async (command: BranchCommand) => controllerApi.addAgency(command);
const callApiToUpdateAgencies = async (command: BranchCommand) => controllerApi.updateAgency(command);
const callApiToDeleteAgency = async (command: DeleteAgencyCommand) => controllerApi.deleteAgency(command);
const callApiToGetAgencies = async () => controllerApi.getAgencies();
const callApiToGetAgency = async (command: AgencyCommand) => controllerApi.getAgency(command);


function* addAgencySaga(action: AddAgencyAction) {
  try {
    const response = yield call(callApiToAddAgency, action.payload.command);
    if (response) {
      if (response?.hasSucceeded) {
        yield put(addAgencySuccess({ value: true } as AddAgencySuccessPayload));

        const responseGetAgency = yield call(callApiToGetAgencies);
        if (responseGetAgency) {
          yield put(getAgenciesSuccess(responseGetAgency as GetAgencies));
        } else {
          let messages: string[] = [];
          responseGetAgency?.errorMessages.map((item) => {
            return messages.push(item.errorMessage);
          });
          yield put(getAgenciesFailure({ errors: messages } as GetAgenciesFailurePayload, null));
        }

      } else {
        let messages: string[] = [];
        response.errorMessages.map((item) => {
          return messages.push(item.errorMessage);
        });
        yield put(addAgencyFailure({ errors: messages } as AddAgencyFailurePayload));
      }
    } else {
      let messages: string[] = [];
      messages.push("Erreur lors de la connexion au serveur");
      yield put(addAgencyFailure({ errors: messages } as AddAgencyFailurePayload));
    }
  } catch (e) {
    let messages: string[] = [];
    messages.push(e.message);
    yield put(addAgencyFailure({ errors: messages } as AddAgencyFailurePayload));
  }
}

function* updateAgenciesSaga(action: UpdateAgencyAction) {
  try {
    const response = yield call(callApiToUpdateAgencies, action.payload.command);
    if (response) {
      if (response?.hasSucceeded) {
        yield put(updateAgencySuccess({ value: true } as UpdateAgencySuccessPayload));
        const responseGetAgency = yield call(callApiToGetAgencies);
        if (responseGetAgency) {
          yield put(getAgenciesSuccess(responseGetAgency as GetAgencies));
        } else {
          let messages: string[] = [];
          responseGetAgency?.errorMessages.map((item) => {
            return messages.push(item.errorMessage);
          });
          yield put(getAgenciesFailure({ errors: messages } as GetAgenciesFailurePayload, null));
        }
      } else {
        let messages: string[] = [];
        response.errorMessages.map((item) => {
          return messages.push(item.errorMessage);
        });
        yield put(updateAgencyFailure({ errors: messages } as UpdateAgencyFailurePayload));
      }
    } else {
      let messages: string[] = [];
      messages.push("Erreur lors de la connexion au serveur");
      yield put(updateAgencyFailure({ errors: messages } as UpdateAgencyFailurePayload));
    }
  } catch (e) {
    let messages: string[] = [];
    messages.push(e.message);
    yield put(updateAgencyFailure({ errors: messages } as UpdateAgencyFailurePayload));
  }
}

function* deleteAgencySaga(action: DeleteAgencyAction) {
  try {
    const response = yield call(callApiToDeleteAgency, action.payload.command);
    if (response) {
      if (response?.hasSucceeded) {
        yield put(deleteAgencySuccess({ value: true } as DeleteAgencySuccessPayload));
        const responseGetAgency = yield call(callApiToGetAgencies);
        if (responseGetAgency) {
          yield put(getAgenciesSuccess(responseGetAgency as GetAgencies));
        } else {
          let messages: string[] = [];
          responseGetAgency?.errorMessages.map((item) => {
            return messages.push(item.errorMessage);
          });
          yield put(getAgenciesFailure({ errors: messages } as GetAgenciesFailurePayload, null));
        }
      } else {
        let messages: string[] = [];
        response.errorMessages.map((item) => {
          return messages.push(item.errorMessage);
        });
        yield put(deleteAgencyFailure({ errors: messages } as DeleteAgencyFailurePayload));
      }
    } else {
      let messages: string[] = [];
      messages.push("Erreur lors de la connexion au serveur");
      yield put(deleteAgencyFailure({ errors: messages } as DeleteAgencyFailurePayload));
    }
  } catch (e) {
    let messages: string[] = [];
    messages.push(e.message);
    yield put(deleteAgencyFailure({ errors: messages } as DeleteAgencyFailurePayload));
  }
}

function* getAgenciesSaga() {
  try {
    const response = yield call(callApiToGetAgencies);
    if (response) {
      yield put(getAgenciesSuccess(response as GetAgencies));
    } else {
      let messages: string[] = [];
      response?.errorMessages.map((item) => {
        return messages.push(item.errorMessage);
      });
      yield put(getAgenciesFailure({ errors: messages } as GetAgenciesFailurePayload, null));
    }

  } catch (e) {
    let messages: string[] = [];
    messages.push(e.message);
    yield put(getAgenciesFailure({ errors: messages } as GetAgenciesFailurePayload, e?.response));
  }
}

function* getAgencySaga(action: AgencyAction) {
  try {
    const response = yield call(callApiToGetAgency, action.payload.command);
    if (response) {
      yield put(getAgencySuccess(response as GetAgency));
    } else {
      let messages: string[] = [];
      response?.errorMessages.map((item) => {
        return messages.push(item.errorMessage);
      });
      yield put(getAgencyFailure({ errors: messages } as AgencyFailurePayload, null));
    }

  } catch (e) {
    let messages: string[] = [];
    messages.push(e.message);
    yield put(getAgencyFailure({ errors: messages } as AgencyFailurePayload, e?.response));
  }
}

export function* watchAgenciesSaga() {
  yield takeLatest(ActionTypes.ADD_AGENCY_REQUEST, addAgencySaga);
  yield takeLatest(ActionTypes.DELETE_AGENCIES_REQUEST, deleteAgencySaga);
  yield takeLatest(ActionTypes.UPDATE_AGENCY_REQUEST, updateAgenciesSaga);
  yield takeLatest(ActionTypes.GET_AGENCIES_REQUEST, getAgenciesSaga);
  yield takeLatest(ActionTypes.GET_AGENCY_REQUEST, getAgencySaga);
}
