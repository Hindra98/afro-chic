import { useDebounced } from "src/app/core/hooks";
import { HttpClient } from "../../../../../http/http-client";

const countPermanentNotificationMessages = (http: HttpClient) => async () => {
  const response = await http.get("/v1/permanentnotificationmessages/get-count");
  const result: CountPermanentNotification = response.data;

  return response !== undefined ? (result as CountPermanentNotification) : undefined;
};
const getPermanentNotificationMessages = (http: HttpClient) => async () => {
  const response = await http.get("/v1/permanentnotificationmessages/get-all");
  const result: PermanentNotificationUser = response.data;

  return response !== undefined ? (result as PermanentNotificationUser) : undefined;
};

const markReadNotification = (http: HttpClient) => async (payload: object) => {
  const response = await http.put("/v1/permanentnotificationmessages/mark-as-read", payload);
  const result: PermanentNotificationUpdateResult = response.data;
  
  return response !== undefined ? (result as PermanentNotificationUpdateResult) : undefined;
};

const deleteNotifications = (http: HttpClient) => async (payload: object) => {
  const response = await http.delete("/v1/permanentnotificationmessages/delete", payload);
  const result: PermanentNotificationUpdateResult = response.data;
  
  return response !== undefined ? (result as PermanentNotificationUpdateResult) : undefined;
};

export class ControllerApi {
  private readonly http = new HttpClient();
  
  public readonly countPermanentNotificationMessages = Object.assign(countPermanentNotificationMessages(this.http), {
    useResponse: (
      handler: (result: CountPermanentNotification) => unknown,
      args: Parameters<ReturnType<typeof countPermanentNotificationMessages>>
    ) => useDebounced(() => this.countPermanentNotificationMessages().then(handler), Object.values(args), 500),
  });
  
  public readonly getPermanentNotificationMessages = Object.assign(getPermanentNotificationMessages(this.http), {
    useResponse: (
      handler: (result: PermanentNotificationUser) => unknown,
      args: Parameters<ReturnType<typeof getPermanentNotificationMessages>>
    ) => useDebounced(() => this.getPermanentNotificationMessages().then(handler), Object.values(args), 500),
  });
  
  public readonly markReadNotification = Object.assign(markReadNotification(this.http), {
    useResponse: (
      handler: (result: PermanentNotificationUpdateResult) => unknown,
      args: Parameters<ReturnType<typeof markReadNotification>>[0]
    ) => useDebounced(() => this.markReadNotification(args).then(handler), Object.values(args), 500),
  });
  
  public readonly deleteNotifications = Object.assign(deleteNotifications(this.http), {
    useResponse: (
      handler: (result: PermanentNotificationUpdateResult) => unknown,
      args: Parameters<ReturnType<typeof deleteNotifications>>[0]
    ) => useDebounced(() => this.deleteNotifications(args).then(handler), Object.values(args), 500),
  });

}