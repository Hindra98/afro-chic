/// <reference types="react-scripts" />
HTTPS = "true";
DEV_MODE = "true";
