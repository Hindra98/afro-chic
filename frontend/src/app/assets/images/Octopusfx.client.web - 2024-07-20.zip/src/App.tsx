import "./App.css";
import "./app/assets/fontello/css/fontello.css";
import { createBrowserRouter, createRoutesFromElements, Route } from "react-router-dom";
import { RouteErrorBoundary } from "./app/core/error-handling/error-boundary";
import Authentication from "./app/features/common/identity/oauth/login";
import OpenRouteLayout from "./app/components/layouts/open-route-layout";
import { RootComponent } from "./app/components/layouts/root-component";
import { lazy } from "react";
import { PrivateRoute } from "./app/components/routes/private-route";

const AdminDashboard = lazy(() => import("./app/features/management/dashboards/admin-dashboard"));
const VerifyIdentity = lazy(() => import("./app/features/common/identity/accounts/verify-identity"));
const ForgotPassword = lazy(() => import("./app/features/common/identity/accounts/forgot-password"));
const ResetPassword = lazy(() => import("./app/features/common/identity/accounts/reset-password"));
const ChangePassword = lazy(() => import("./app/features/common/identity/accounts/change-password/change-password"));
const UpdateUserPreferences = lazy(() => import("./app/features/common/identity/user-preferences/update-user-preferences"));
const MyProfile = lazy(() => import("./app/features/common/identity/my-profile/my-profile/my-profile"));
const AppSettings = lazy(() => import("./app/features/management/app-settings/app-settings"));
const Notifications = lazy(() => import("./app/features/common/identity/permanent-notifications/notifications"));
const Tenant = lazy(() => import("./app/features/management/tenants/tenant-data-grid"));
const Agencies = lazy(() => import("./app/features/management/agencies/agencies-data-grid"));
const Audits = lazy(() => import("./app/features/management/audits/audits-data-grid"));
const Vehicles = lazy(() => import("./app/features/management/vehicles/vehicle-data-grid"));
const Users = lazy(() => import("./app/features/common/identity/users/user-data-grid"));
const PageNotFound = lazy(() => import("./app/components/pages/page-not-found"));
const AppCoreLayout = lazy(() => import("./app/components/layouts/app-core-layout"));

 export const router = createBrowserRouter( 
  createRoutesFromElements(
  <>
    <Route element={<RootComponent/>} lazy = {() => import("./app/core/startup/load-initial-data")} errorElement = {<RouteErrorBoundary/>}>
      <Route path='*' element={<PageNotFound />}/>
      <Route element={<OpenRouteLayout />} errorElement = {<RouteErrorBoundary/>}>
        <Route index element={<Authentication/>} />
        <Route path="/login" element={<Authentication />} />
        <Route path="/verify-identity" element={<VerifyIdentity />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/reset-password" element={<ResetPassword />} />
      </Route>
      
      <Route element={<AppCoreLayout />} errorElement={<RouteErrorBoundary />}>
        <Route path="/my-settings" element={<PrivateRoute children={<UpdateUserPreferences />}/>}/>
        <Route path="/dashboard" element={<PrivateRoute children={<AdminDashboard />}/>}/>
        <Route path="/my-profile" element={<PrivateRoute children={<MyProfile />}/>}/>
        <Route path="/change-password" element={<PrivateRoute children={<ChangePassword />}/>} />
        <Route path="/app-settings" element={<PrivateRoute children={<AppSettings />}/>}/>
        <Route path="/notifications" element={<PrivateRoute children={<Notifications />}/>}/>
        <Route path="/tenants" element={<PrivateRoute children={<Tenant />}/>}/>
        <Route path="/agencies" element={<PrivateRoute children={<Agencies />}/>}/>
        <Route path="/audits" element={<PrivateRoute children={<Audits />}/>}/>
        <Route path="/users" element={<PrivateRoute children={<Users />}/>}/>
        <Route path="/vehicle" element={<PrivateRoute children={<Vehicles />}/>}/>
      </Route>
    </Route>
  </>
));
