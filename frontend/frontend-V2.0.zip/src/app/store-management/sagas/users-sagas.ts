import { put, takeLatest } from "redux-saga/effects";
import { ActionTypes } from "../actions/constants/action-types";
import { setUser } from "../actions/users/users-actions";
import { getAuth } from "firebase/auth";
import { app_firebase } from "../../http/firebase/config";
function* fetchUser() {
  try {
    const auth = getAuth(app_firebase);
const user = auth.currentUser;
    if (user) {
      yield put(setUser(user));
    }
  } catch (error) {
    console.error('Failed to fetch user:', error);
  }
}

function* signOutSaga() {

}

//Watcher: Authenticate user
export function* watchFetchUserSaga() {
  yield takeLatest(ActionTypes.AUTHENTICATE_USER_REQUEST, fetchUser);
  yield takeLatest(ActionTypes.LOGOUT_USER_REQUEST, signOutSaga);
}