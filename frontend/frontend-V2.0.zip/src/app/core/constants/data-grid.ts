export const GridConstants = {
  HEIGHT: 'calc(100vh - 265px)',
  ETAT: 100,
  DATE_CREATED: 200,
};
