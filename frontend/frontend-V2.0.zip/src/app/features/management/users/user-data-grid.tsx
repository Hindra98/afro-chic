
import "../../../styles/_notifications.scss";
import Breadcrumb from "../../../components/shared/breadcrumb";
import { useTranslation } from "react-i18next";


const UsersDataGrid = () => {
  const { t } = useTranslation();

  window.document.title = "Utilisateurs";
  return (
    <div className="h-full flex flex-col justify-start mx-auto notifications-component">
      <div
        className={` text-3xl align-top flex flex-col justify-start ps-10 pt-4 flex-wrap my-2 gap-0 `}
      >
        <h1 className="">{"Utilisateurs"}</h1>
        <Breadcrumb
          items={[
            {
              title: t("MODULE_COMMON_SIDEBAR_DASHBOARD"),
              link: "/dashboard",
            },
            { title: "Utilisateurs" },
          ]}
        />
      </div>
    </div>
  );
};

export default UsersDataGrid;
