import "../../styles/_spinner.scss"

const UILoader = () => {
    return(
      <div className="loader"></div>
    )
}

export default UILoader;