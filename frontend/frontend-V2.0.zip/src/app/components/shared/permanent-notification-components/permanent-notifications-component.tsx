import "../../../styles/layouts/_notifications-core-layout.scss";

const PermanentNotificationsComponent = () => {


  return (
    <>
      <div className={"notifications"}>
      </div>
    </>
  );
};
export default PermanentNotificationsComponent;
