
/// <reference types="vite-plugin-svgr/client" />
/// <reference types="vite/client" />
